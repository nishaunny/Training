package dequesample.program;


//Java program to demonstrate the
//creation of deque object using the
//ArrayDeque class in Java

import java.util.*;
public class dequeinteger {
	public static void main(String[] args)
	{
		// Initializing an deque
		Deque<Integer> de_que
		= new ArrayDeque<Integer>(10);
		
		// add() method to insert
		de_que.add(10);
		System.out.println("Sample to understand Deque methods.");

		de_que.offerFirst(20);
		//offers to the first element in queue.
		System.out.println("20 to be the first element...>"+de_que);

		de_que.add(30);
		de_que.add(40);
		System.out.println("After adding 20 in 1st, 10, 30, 40--->" +de_que);

		de_que.offerLast(50);//to be the last element in queue.

		System.out.println("First set of integers 20,10,30,40,50 in deque--->"+de_que);

		// clear() method, removes all the elements of the collection, it will be empty.
		de_que.clear();

		// addFirst() method to insert the
		// elements at the head
		de_que.addFirst(564);
		de_que.add(10);

		de_que.addLast(50);
		System.out.println("Deque after adding 564 & 50(head,tail)....>"+de_que);

		//Pop will remove the head of the queue.
		//Peek wil retrieve but not remove the head of the queue
		System.out.println("Pop the head:-->"+de_que.pop());
		System.out.println(de_que);
		de_que.addFirst(291);
		System.out.println(de_que);
		System.out.println("Peeking retrieves the head, but does not remove-->"+de_que.peek());

		// addLast() method to insert the
		// elements at the tail
		de_que.addLast(24);
		de_que.addLast(14);

		System.out.println("Second double queue with elements, other operations--->"+de_que);
	}
}
