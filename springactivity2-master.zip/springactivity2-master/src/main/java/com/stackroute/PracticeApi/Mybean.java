package com.stackroute.PracticeApi;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.stackroute.foodapp.Bill;
import com.stackroute.foodapp.FoodItem;
import com.stackroute.foodapp.Hotel;

@Configuration
public class Mybean {
	
	@Bean("fooditembean")
	public FoodItem getFoodItem() {
		
		FoodItem obj1 = new FoodItem();
		obj1.setItemname("Jalebi");
		obj1.setPrice(100);
		return obj1;
		
	}
	@Bean("hotelbean")
	public Hotel getHotel() {
		
		Hotel obj2 = new Hotel();
		obj2.setHotelname("Anna hotel");
		obj2.setLocation("Erode");
		return obj2;
		
	}
	@Bean("billybean")
	public Bill getBill() {
		
		Bill obj3 = new Bill();
		obj3.setBillno(123);
		this.getFoodItem().setItemname("Rasagula");
		return obj3;
		
	}
}
