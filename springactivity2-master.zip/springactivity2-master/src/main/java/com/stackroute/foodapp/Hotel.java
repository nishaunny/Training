package com.stackroute.foodapp;

import org.springframework.beans.factory.annotation.Autowired;

public class Hotel {
	
	private String Hotelname, location;
	@Autowired
	FoodItem fooditem;
	
	public String getHotelname() {
		return Hotelname;
	}
	public void setHotelname(String hotelname) {
		Hotelname = hotelname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public FoodItem getFooditem() {
		return fooditem;
	}
	public void setFooditem(FoodItem fooditem) {
		this.fooditem = fooditem;
	}

	
	

}
