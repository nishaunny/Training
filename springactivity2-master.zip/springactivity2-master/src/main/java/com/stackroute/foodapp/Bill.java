package com.stackroute.foodapp;

import org.springframework.beans.factory.annotation.Autowired;

public class Bill {
	
	private int Billno;
	@Autowired
	FoodItem fooditem2;

	public int getBillno() {
		return Billno;
	}

	public void setBillno(int billno) {
		Billno = billno;
	}

	public FoodItem getFooditem2() {
		return fooditem2;
	}

	public void setFooditem2(FoodItem fooditem2) {
		this.fooditem2 = fooditem2;
	}

}
