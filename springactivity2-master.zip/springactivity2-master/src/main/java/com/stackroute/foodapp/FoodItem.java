package com.stackroute.foodapp;

public class FoodItem {
	
	private String Itemname;
	private int Price;
	public String getItemname() {
		return Itemname;
	}
	public void setItemname(String itemname) {
		Itemname = itemname;
	}
	public int getPrice() {
		return Price;
	}
	public void setPrice(int price) {
		Price = price;
	} 

}
