package com.stackroute.foodapp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.stackroute.PracticeApi.Mybean;

public class FoodMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext appcontext = new ClassPathXmlApplicationContext("mybeans.xml");
		
		Hotel hoteobj = appcontext.getBean("hotelbean", Hotel.class);
		//singleton - one instance - all objects have same data.
		hoteobj.setHotelname("Plaza hotel");
		Hotel hoteobj2 = appcontext.getBean("hotelbean", Hotel.class);
		System.out.println("Hotelname...."+hoteobj.getHotelname());
		System.out.println("Hotelname2...."+hoteobj2.getHotelname());
		System.out.println("Location...."+hoteobj.getLocation());
		System.out.println("Itemname...."+hoteobj.getFooditem().getItemname());
		System.out.println("Price...."+hoteobj.getFooditem().getPrice());
		//prototype is not so, only that object will have particular data.
		Bill billobj = appcontext.getBean("billbean", Bill.class);
		Bill billobj2 = appcontext.getBean("billbean", Bill.class);
		billobj2.setBillno(334);
		System.out.println("Bill No:::"+billobj.getBillno());
		System.out.println("Bill No2:::"+billobj2.getBillno());
		System.out.println("Item details ..:::"+billobj.getFooditem2().getPrice());
		
		System.out.println("Using configuration.java...output:");
		ApplicationContext appcontext2 = new AnnotationConfigApplicationContext(Mybean.class);
		
		Hotel hotelobj = appcontext2.getBean("hotelbean", Hotel.class);
		
		System.out.println("hotel name and location.."+hotelobj.getHotelname()+"," +hotelobj.getLocation());
		System.out.println("Fooditem from hote.....>"+hotelobj.getFooditem().getItemname());
		System.out.println("Fooditem price ....hotel:>"+hotelobj.getFooditem().getPrice());
		
		Bill billyobj = appcontext2.getBean("billybean", Bill.class);
		
		System.out.println("Billno, itemname...."+billyobj.getBillno() +billyobj.getFooditem2().getItemname());
		System.out.println("Fooditem price from Bill"+billyobj.getFooditem2().getPrice());
	}

}
