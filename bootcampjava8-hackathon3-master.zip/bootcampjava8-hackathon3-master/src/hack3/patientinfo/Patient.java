package hack3.patientinfo;

import java.time.LocalDate;

//#### class Patient
//
//##### Attributes
//	
//       -patientId : int
//       -name	:string
//       -doctorName : String
//       -appointment_dt : localdate
//       -disease : string
//
//•	Define parameterized constructor to initialize all the properties.
//
//•	Define Getters and Setters for all properties
//
//•	Define the below methods:
//•	  +toString : String       
//
//    - Should return the Patient details as per the below format
public class Patient {
	
	String name, doctorName, disease;
	int patientId;
	LocalDate appointment_dt;
	
	public Patient(int patientId, String name, String doctName, LocalDate appoint, String disea) {
		
		this.patientId=patientId;
		this.name=name;
		this.doctorName=doctName;
		this.appointment_dt=appoint;
		this.disease=disea;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getDisease() {
		return disease;
	}
	public void setDisease(String disease) {
		this.disease = disease;
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public LocalDate getAppointment_dt() {
		return appointment_dt;
	}
	public void setAppointment_dt(LocalDate appointment_dt) {
		this.appointment_dt = appointment_dt;
	}
	
	public String toString() {
		
		return "id---> :" +patientId+ "Name :: " +name+ "Doctor'sname :: " +doctorName+ "Appointmentdate :: ->" +appointment_dt+ "Disease's info ::"+disease;
	}
}
