package hack3.patientinfo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class HospitalProcess {
	
	static List<Patient> patients = new ArrayList<Patient>();
	
	public static void main(String[] args) {
		
//		
//        -patients : List<Patient> 
//	 
//##### Keep below list of 5 patients in the patients list

	patients.add( new Patient(10,"raju","Samsung",LocalDate.of(2021,05,16),"Diabetic"));
	patients.add( new Patient(45,"Uma","Rajiv",LocalDate.of(2021,05,30),"Lungs"));
	patients.add( new Patient(20,"Vimal","Samsung",LocalDate.of(2021,06,10),"Diabetic"));
	patients.add( new Patient(50,"Murali","Samsung",LocalDate.of(2021,05,30),"Diabetic"));
	patients.add(new Patient(10,"Ekta","Raiv",LocalDate.of(2021,04,19),"Lungs"));

	
	getPatientforSamsung();
	getPatientforLungsdis();
	lasttwopatientdetails();
	ascendingorderNames();
	mapdiseasenamewithpatients();
	countpatients();
	getPatientalreadyExp();

	}


//* List the patient who got appointment for the doctor "Samsung"
static void getPatientforSamsung() {
	System.out.println("Patients for doctor samsung ....");
	List<Patient> p1 = patients.stream().filter((pobj)->pobj.getDoctorName().equals("Samsung")).collect(Collectors.toList());
	p1.forEach(System.out::println);
}

//List the names of patient , who have got "Lungs" disease
static void getPatientforLungsdis() {
	System.out.println("get patients with Lungs information ....");
	List<String> patiname = patients.stream().filter((pobj)->pobj.getDisease().equals("Lungs")).map(pobj->pobj.getName()).collect(Collectors.toList());
	patiname.forEach(System.out::println);
}

//Display the last 2 patient details
static void lasttwopatientdetails() {
	System.out.println("Last two patients ....");

		//using the patientId>40 to display last 2 according to that.
//	List<Patient> lastwo = patients.stream().filter((pobj)->pobj.getPatientId()>40).collect(Collectors.toList());
//lastwo.forEach(System.out::println);
	//using skip()
List<Patient> result =  patients.stream().skip(3).collect(Collectors.toList());
//skip()..the number of records mentioned will be skipped and remaining will be returned.
}

static void ascendingorderNames() {
	System.out.println("get ascending order of patient name..");
	patients.stream().sorted(Comparator.comparing(Patient::getName)).collect(Collectors.toList()).forEach(System.out::println);
	
	//	List<Patient> Patientdetails = patients.stream().
//		    sorted((s1,s2)-> s1.getName().compareToIgnoreCase(s2.getName())).
//		    collect(Collectors.toList());
//	Patientdetails.forEach(System.out::println);
	//using comparetoignorecase to ignore case and valid output
	
	
}
//* Return Map , with disease name as key and list of patients having the same disease as value

static void mapdiseasenamewithpatients() {
	
	Map<String, List<Patient>> map = patients.stream().collect(Collectors.groupingBy(Patient::getDisease));
	map.forEach((k,v)-> System.out.println("Disease info...."+k +v));
}
//* Count the patients who have appointment for the month of May

static void countpatients() {
	//System.out.println(LocalDate.now().getMonthValue());
	Long value = patients.stream().filter((pobj)->pobj.getAppointment_dt().getMonthValue()==05).count();
	System.out.println("May appointments ----->" +value);
}
//* Get the list of patients whose appointment date already expired
static void getPatientalreadyExp() {
	System.out.println("get already expired appointment ....");
	Predicate<Patient> pred = (pobj)->pobj.getAppointment_dt().isBefore(LocalDate.of(2021, 05, 28));
	List<Patient> getlist = patients.stream().filter(pred).collect(Collectors.toList());
	getlist.forEach(System.out::println);
}

}