package com.stackroute.threadfile;

import java.util.Scanner;

import com.stackroute.threadfile.resource.DataFile;
import com.stackroute.threadfile.service.MentorProcess;
import com.stackroute.threadfile.service.StudentProcess;

//Get options for reading or writing. 
public class OrganizerMain {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Type the file name in right format as filename.txt");
		//First time, when file not exist, filenotfound exception is thrown, then it is created.
		//write operation is done on the same file.
		DataFile data = new DataFile(scan.next());
		
		System.out.println("The file entered will be read and written. Enter 1 to read and 2 to write.");
		int choice = scan.nextInt();
		
		switch(choice) 
		{
		case 1:
				MentorProcess ment = new MentorProcess(data);
				//to access the Mentor process to read.
				//data.fileOperations("Read");
				ment.start();//execute run() in the mentorprocess.
				break;
		case 2:		
				StudentProcess student = new StudentProcess(data);
				//to access the student Process to write.
				//data.fileOperations("Write");
				student.start();//execute run() in the studentprocess.
				break;
		default:
				break;
		}		

	

}
}
