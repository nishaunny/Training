package com.stackroute.threadfile.service;

import com.stackroute.threadfile.resource.DataFile;

public class StudentProcess extends Thread {
	
//2) StudentProcess --> For writing the content inside file
	//datafileobject is used access fileoperations method.
	DataFile datafile;
	public StudentProcess(DataFile datafileobj)
	{
		this.datafile = datafileobj;
	}
	
	public void run() {
		
		datafile.fileOperations("Write");
		System.out.println("Writing to the file..");
	}

}
