package com.stackroute.threadfile.service;


import com.stackroute.threadfile.resource.DataFile;

//use DataFile 
//1) MentorProcess --> For reading the content from file
//datafileobject is used access fileoperations method.
public class MentorProcess  extends Thread{

	DataFile datafile;
	
	 public MentorProcess(DataFile datafileobj)
	 {
		 this.datafile = datafileobj;
		 
		 
	 }
	 
	 public void run() {
		 datafile.fileOperations("Read");
		 System.out.println("Reading from file..");
		 
	 }
}
