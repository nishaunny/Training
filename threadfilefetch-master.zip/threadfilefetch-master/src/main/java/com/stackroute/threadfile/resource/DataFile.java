package com.stackroute.threadfile.resource;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

//Use parameterized constructor for getting the file name. make the transaction to be synchronized



public class DataFile {
	
	//Fileobject is common in both MentorProcess and StudentProcess.
	//Filename is commonly used in Read and Write operations as follows.
	//Fileoperations method has if type=write, write the file and type=read, read the file.

	String filename;
	
	public DataFile(String file)  {
		this.filename = file;
	}
	//###  Multithreads for File Access . Using Synchronized threads, both read and write makes
	//use of Fileoperations method and datafileobject.
    public boolean	fileOperations (String type)
    
    {
    	//synchronized is made use of so that after reading part, writing thread is executed.
    	synchronized(this) {
        if(type.equals("Read")) {

			 
			 FileReader fileread;
			try {
				fileread = new FileReader(filename);
				BufferedReader bufferead = new BufferedReader(fileread);
				bufferead.readLine();
				bufferead.close();
			} catch (FileNotFoundException e) {
				// First time, this exception is thrown since this file was not created yet.
				// After creation, second time this will not be thrown.
				e.printStackTrace();
			} catch (IOException e) {
				//IO exception for the Buffered Reader.
				e.printStackTrace();
			}	 
			 
		 
        return true;
    }
    	
        else if(type.equals("Write")) {
        	FileWriter filewrite = null;
			try {
				filewrite = new FileWriter(filename);
				BufferedWriter bufferwrite = new BufferedWriter(filewrite);
				bufferwrite.write("my assignment completed");
				bufferwrite.flush();
				bufferwrite.close();
			} catch (IOException e) {
				// Exception is for the bufferedwriter object.
				e.printStackTrace();
			}
        	finally {
        		try {
					filewrite.close();
				} catch (IOException e) {
					// Exception for filewrite.
					e.printStackTrace();
				}
        	}
        	
        	
    	return true;
        }
    	else 
    		return false;
    }
    }//synchronized end
}
    
