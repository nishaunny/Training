package com.ustg.hibernatesample.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


import com.ustg.hibernatesample.dao.CollegeDao;
import com.ustg.hibernatesample.model.College;

@Controller
public class myController {
	
	@Autowired
	CollegeDao collegedao;
	
	@GetMapping("/")
	public String gethome(ModelMap mymap)
	{
		List<College> players= collegedao.getAll();
		mymap.put("List",players);
		return "index";
	}
	
	@RequestMapping("/addcollegeperson")
	public String savecollegeperson(@ModelAttribute("college") College playernew)
	{
		collegedao.addCollegecadet(playernew);
		System.out.println("added");
		return "redirect:/";
	}
	

}
