package com.ustg.hibernatesample.dao;

import java.util.List;

import com.ustg.hibernatesample.model.College;



public interface CollegeDao {
	
	boolean addCollegecadet(College collobj);
	
	List<College> getAll();
	
	College findCollegebyid(int collid);

}
