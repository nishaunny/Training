package com.ustg.hibernatesample.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;

import com.ustg.hibernatesample.model.College;



public class HibernateConfig {
	
	@Bean
	public DataSource getDataSource()
	{
		BasicDataSource datasource=new BasicDataSource();
		datasource.setDriverClassName("com.mysql.cj.jdbc.Driver");
		datasource.setUrl("jdbc:mysql://localhost:3306/university");
		datasource.setUsername("root");
		datasource.setPassword("password123@");
		return datasource;
		
	}
	
	@Bean
	public LocalSessionFactoryBean getSessfact(DataSource datasour) throws Exception
	{
		
		
		LocalSessionFactoryBean sessfact=new LocalSessionFactoryBean();
		sessfact.setDataSource(datasour);
		Properties property=new Properties();
		property.put("hibernate.dialect","org.hibernate.dialect.MySQL5Dialect");
		property.put("hibernate.show_sql","true");
		property.put("hibernate.hbm2ddl.auto","update");
		sessfact.setHibernateProperties(property);
		sessfact.setAnnotatedClasses(College.class);
        sessfact.afterPropertiesSet();
        
		return sessfact;
		
	}
	
	@Bean
	public HibernateTransactionManager getTransaction(SessionFactory sessfactory)
		{
	HibernateTransactionManager hibermanager=new HibernateTransactionManager();
	hibermanager.setSessionFactory(sessfactory);
	return hibermanager;
	
	}

}
