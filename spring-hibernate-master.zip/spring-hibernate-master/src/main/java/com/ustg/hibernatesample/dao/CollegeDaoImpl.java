package com.ustg.hibernatesample.dao;

import java.util.List;

import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ustg.hibernatesample.model.College;
//added enable transactionmanagement and @Transactional from org.springframework.
@EnableTransactionManagement
@Transactional
@Repository
public class CollegeDaoImpl implements CollegeDao{
	
SessionFactory sessionfactory;
	
	@Autowired
	CollegeDaoImpl(SessionFactory sess){
		this.sessionfactory=sess;
	}

	public boolean addCollegecadet(College collobj) {
		sessionfactory.getCurrentSession().save(collobj);
		return true;
	}

	public List<College> getAll() {
		List<College> list=sessionfactory.getCurrentSession().createQuery("from College").list();

		return list;
	}

	public College findCollegebyid(int collid) {
		College obj=(College)sessionfactory.getCurrentSession().createQuery("from College where collegeId=" +collid).uniqueResult();
		// TODO Auto-generated method stub
		return obj;
	}
	
	

}
