import { Injectable } from '@angular/core';
import { Note } from '../note';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { AuthenticationService } from './authentication.service';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';


@Injectable()
export class NotesService {

  errMessage:String ="";

  notes: Array<Note>=[];
  notesSubject: BehaviorSubject<Array<Note>>;

  constructor(private httpcli: HttpClient, private authorizeservice: AuthenticationService) { 

    this.notesSubject= new BehaviorSubject<Array<Note>>([]);
  }

  fetchNotesFromServer() {
    let tok=this.authorizeservice.getBearerToken();
    return this.httpcli.get<Array<Note>>('http://localhost:3000/api/v1/notes',
    {
     headers: new HttpHeaders().set('Authorization',`Bearer ${tok}`)
   }
   ).subscribe(
    (res)=>{
            this.notes=res;
            this.notesSubject.next(this.notes);
    },
    (err)=>{
       this.notesSubject.error(err)
    }
   )
  }

  getNotes(): BehaviorSubject<Array<Note>> {

    return this.notesSubject;

  }

  addNote(note: Note): Observable<Note> {
    let tok=this.authorizeservice.getBearerToken();

    return  this.httpcli.post<Note>('http://localhost:3000/api/v1/notes',note,
    {
      headers: new HttpHeaders().set('Authorization',`Bearer ${tok}`)
    }
    ).
    pipe(
  
       tap( (objitems:Note) =>
        {
          this.notes.push(objitems);
          this.notesSubject.next(this.notes);
        //  return this.productsubject
        }
    )
    );
  }

 editNote(notech: Note): Observable<Note> {

  let tok=this.authorizeservice.getBearerToken();

  return  this.httpcli.put(`http://localhost:3000/api/v1/notes/${notech.id}`
  ,notech,
  {
    headers: new HttpHeaders().set('Authorization',`Bearer ${tok}`)
  }
  ).pipe(
    tap(
      (newnote:any)=>
    {
     let currele=this.notes.find( note=>note.id===notech.id);
Object.assign(currele,newnote);

  this.notesSubject.next(this.notes);    
    }
    )
  );

  } 

  getNoteById(noteId:any): Note {

    const result=this.notes.find( note=>note.id==noteId);
 return result;

  }
}


