import { Component, OnInit } from '@angular/core';
import { Note } from '../note';
import { NotesService } from '../services/notes.service';

@Component({
  selector: 'app-list-view',
  templateUrl: './list-view.component.html',
  styleUrls: ['./list-view.component.css']
})
export class ListViewComponent implements OnInit{
 

 
  errMessage:String="";
  notStartedNotes: Array<Note>;
  startedNotes: Array<Note>;
  completedNotes: Array<Note>;
  constructor(private noteservice: NotesService){}

  
  ngOnInit(): void {

    this.noteservice.getNotes().subscribe((res)=>{
    this.notStartedNotes=[];
    this.startedNotes=[];
    this.completedNotes=[];

    res.forEach(note=>{

      if(note.state==='not-started')
      {this.notStartedNotes.push(note)}
      else if (note.state==='started')
      {this.startedNotes.push(note)}
      else if (note.state==='completed')
      {this.completedNotes.push(note)}
       
  });
},
error => {

  this.errMessage=error.message;
  

}
);
}
}
