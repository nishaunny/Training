import { Component } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';
import { AuthenticationService } from '../services/authentication.service';
import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
    
    username = new FormControl('', Validators.required);
    password = new FormControl('', Validators.required);
    submitMessage: string;
    token: string;
  constructor(private authService: AuthenticationService , private routeService: RouterService){}

    loginSubmit() {
      if (this.username.valid && this.password.valid ){
        let data = { username: this.username.value, password:this.password.value }
          
          this.authService.authenticateUser(data).
            subscribe(
              (res) => {this.token = res["token"];
                   //console.log(this.token);
                        this.authService.setBearerToken(this.token);
                   this.routeService.routeToDashboard();
                  } ,
              (err) =>
                {
                 if (err.status === 403){
                    this.submitMessage = err.error.message;
                 }
                else
                    this.submitMessage = err.message;});
          }
         }
        getunameValidate() {
          let uname = this.username;
            return uname.hasError('required') ? 'User name should not be empty' :  "";
          }
        getpasswordValidate(){
         let pwd = this.password;
            return pwd.hasError('required') ? 'Password should not be empty' : '';
          }
    }

