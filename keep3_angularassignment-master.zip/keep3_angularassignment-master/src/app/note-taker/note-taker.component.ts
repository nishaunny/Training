import { Component, OnInit } from '@angular/core';
import { Note } from '../note';
import { NotesService } from '../services/notes.service';

@Component({
  selector: 'app-note-taker',
  templateUrl: './note-taker.component.html',
  styleUrls: ['./note-taker.component.css']
})
export class NoteTakerComponent {

  errMessage:String ="";
  noteobj :Note;
  notes: Array<Note>=[];
  states:Array<string> = ['not-started', 'started', 'completed'];
  constructor(private noteservice: NotesService) {

    this.noteobj= new Note();

  }

  addNote(){
    if((this.noteobj.text=="")||(this.noteobj.title==""))
    this.errMessage="Title and Text both are required fields";
    else if(this.noteobj.text!=null&& this.noteobj.title!=null && this.noteobj.state!=null)
    {
    this.noteservice.addNote(this.noteobj).subscribe((res)=>this.notes.push(res),
    (err)=>
    this.errMessage=err.message)
    }
  }
}
