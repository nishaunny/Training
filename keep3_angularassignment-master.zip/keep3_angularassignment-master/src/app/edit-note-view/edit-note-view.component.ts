import { OnInit } from '@angular/core';
import { Inject } from '@angular/core';
import { OnDestroy } from '@angular/core';
import { Component } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { EditNoteOpenerComponent } from '../edit-note-opener/edit-note-opener.component';
import { Note } from '../note';
import { NotesService } from '../services/notes.service';
import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-edit-note-view',
  templateUrl: './edit-note-view.component.html',
  styleUrls: ['./edit-note-view.component.css']
})
export class EditNoteViewComponent implements OnInit,OnDestroy{
  note: Note;
  noteid:any;
  states: Array<string> = ['not-started', 'started', 'completed'];
  errMessage: string;

  constructor(private mydialog : MatDialogRef<EditNoteViewComponent>,
    @Inject(MAT_DIALOG_DATA) private data :any,private noteservice: NotesService, private routing: RouterService){
      this.note=new Note();
    }

    close()
  {
  this.mydialog.close();
  }
  ngOnDestroy(): void {
    this.routing.routeBack();
  }
  ngOnInit(): void {
    this.noteid=this.data.myId;
    this.note=this.noteservice.getNoteById(this.noteid); 
  }

  onSave() {

    this.noteservice.editNote(this.note).subscribe(e=>console.log("updated"), (err)=>this.errMessage=err.message);
    this.close();

  }
}
