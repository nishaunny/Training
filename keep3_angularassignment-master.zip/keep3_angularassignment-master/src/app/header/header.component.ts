import { Component, OnInit } from '@angular/core';
import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit{
  isNoteView = true;

  constructor(private routeservice: RouterService){}

  ngOnInit(): void {
  }

  switchView(){
    if(this.isNoteView){
      this.routeservice.routeToListView();
      this.isNoteView=false;
    }else{
      this.routeservice.routeToNoteView();
      this.isNoteView=true;
    }
  }


}
