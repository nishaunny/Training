import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { EditNoteViewComponent } from '../edit-note-view/edit-note-view.component';

@Component({
  selector: 'app-edit-note-opener',
  templateUrl: './edit-note-opener.component.html',
  styleUrls: ['./edit-note-opener.component.css']
})
export class EditNoteOpenerComponent {

  noteid:any;

  constructor(private myroute : ActivatedRoute,private dialog: MatDialog){

    this.noteid=this.myroute.snapshot.paramMap.get('noteId');

    this.dialog.open(EditNoteViewComponent,{
      data : {myId : this.noteid}
    });
  }

}
