import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from './services/authentication.service';
import { RouterService } from './services/router.service';


@Injectable()
export class CanActivateRouteGuard implements CanActivate {

  bearertoken:any;

  constructor(private authService: AuthenticationService, private routeService: RouterService) {
    this.bearertoken = this.authService.getBearerToken();  
  }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): 
    Observable<boolean> | Promise<boolean> | boolean {
      const output = this.authService.isUserAuthenticated(this.bearertoken);   
        return output
        .then
          (
            (res)=>
              {
                if(!res) {    
                    this.routeService.routeToLogin();
                    return false;
                  }
                  else{
                  return true;
                  }
              }
          );}
        }
