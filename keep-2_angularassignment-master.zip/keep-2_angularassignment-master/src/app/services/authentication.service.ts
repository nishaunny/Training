import { HttpHeaders } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { RouterService } from './router.service';

@Injectable()
export class AuthenticationService {
  errMessage:string ='';
  constructor(private httpcli: HttpClient) {

  }

authenticateUser(data:any): Observable<any> {
    return this.httpcli.post('http://localhost:3000/auth/v1',data);
  }

setBearerToken(token:any) {
    localStorage.setItem('bearertoken',token);
  }

getBearerToken() { 
    return localStorage.getItem('bearertoken');   
  }

isUserAuthenticated(token:any): Promise<boolean> {
        //token = this.getBearerToken();

    return this.httpcli.post('http://localhost:3000/auth/v1/isAuthenticated', {},
    { headers: new HttpHeaders().set('Authorization', `Bearer ${token}`) }
    ) .pipe  //  passing the collection {isAuthenticated:true or false} to pipe & map
    (map(
       (res:any) => { return (res['isAuthenticated']); }) // returning value for key isAuthenticated
      ).toPromise(); 
  } 
}
