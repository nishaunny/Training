import { Component, OnInit } from '@angular/core';
import { Note } from '../note';
import { NotesService } from '../services/notes.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  errMessage: string;
  step = 0;
  noteobj: Note;
  notes: Array<Note>=[];

  setStep(index: number) {
    this.step = index;
  }
  addNote(){
    this.step++;
    this.addNotes();
  }
  prevStep(){
    this.step--;
  }

  constructor(private notesService: NotesService){
    this.noteobj = new Note();
    }
    ngOnInit(): void {
    this.getNotes();
    }
  getNotes(){
    this.notesService.getNotes().subscribe(
      (res)=>this.notes=res,
    (error)=>{this.errMessage=error.error.message;});
  }
  addNotes(){
    if((!this.noteobj.title) || (!this.noteobj.text))
      this.errMessage="Title and Text both are required fields";
    else if(this.notes.length>0){
      this.notesService.addNote(this.noteobj).subscribe((res)=>{this.notes.push(this.noteobj);}, 
      (error)=>
        {this.errMessage=error.error.message;});
      }
    }
  }
