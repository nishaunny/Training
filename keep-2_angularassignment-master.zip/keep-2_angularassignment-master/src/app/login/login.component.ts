import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { FormControl } from '@angular/forms';

import { AuthenticationService } from '../services/authentication.service';
import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username = new FormControl('', Validators.required);
  password = new FormControl('', Validators.required);
  submitMessage: string;
  token: string;
  constructor(private authService: AuthenticationService , private routeService: RouterService){}
    /*  submitMessage:string="";
      user: FormGroup;
      constructor(private routser: RouterService, private authser: AuthenticationService){
      this.user=new FormGroup({
        username: new FormControl('',Validators.required),
        password: new FormControl('',Validators.minLength(5)),
      }); 
      }

        loginSubmit(username:string, password:string) {


            // sessionStorage.setItem("username",username);
            // sessionStorage.setItem("password",password);

            if(username=="admin" && password=="password"){
            this.authser.authenticateUser(this.user.value).subscribe(

              (res)=> {
                console.log(res["token"]);
              this.authser.setBearerToken(res["token"]);
              this.routser.routeToDashboard();
              },
              (error)=>{
                if(error.status==403)
                this.submitMessage=error.error.message;
                else
                this.submitMessage=error.message;
              }
            
            )
            }
          }
      }  */
    loginSubmit() {
    if (this.username.valid && this.password.valid ){
    let data = { username: this.username.value, password:this.password.value }

      this.authService.authenticateUser(data).
        subscribe(
          (res) => {this.token = res['token'];
               //console.log(this.token);
                    this.authService.setBearerToken(this.token);
               this.routeService.routeToDashboard();
              } ,
          (err) =>
            {
             if (err.status === 403){
                this.submitMessage = err.error.message;
             }
            else
                this.submitMessage = err.message;});
      }
     }
    getunameValidate() {
      let uname = this.username;
        return uname.hasError('required') ? 'User name should not be empty' :  "";
      }
    getpasswordValidate(){
     let pwd = this.password;
        return pwd.hasError('required') ? 'Password should not be empty' : '';
      }
  }