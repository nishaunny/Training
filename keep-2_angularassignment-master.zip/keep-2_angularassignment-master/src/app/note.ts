export class Note {

    id: number=0;
    title: string;
    text: string;

    constructor(){}
}

