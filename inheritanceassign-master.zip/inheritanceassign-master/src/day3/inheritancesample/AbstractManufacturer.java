package day3.inheritancesample;
// Inheritance assignment
public abstract class AbstractManufacturer{
String Name;
String ModelName;
String Type;

public void setName(String name) {
	Name = name;
}
public void setModelName(String modelName) {
	ModelName = modelName;
}
public void setType(String type) {
	Type = type;
}
public String getModelName() {
return ModelName;
}
public String getType() {
return Type;
}
public String getName() {
return Name;
}
abstract String getManufacturerInformation();

abstract int maxSpeed(String Type);

}
