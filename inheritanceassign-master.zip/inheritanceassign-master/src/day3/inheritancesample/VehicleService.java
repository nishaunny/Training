package day3.inheritancesample;


class Car extends AbstractManufacturer{
public Car(String name, String modelName, String carType) {
}
	public Car() {
	// TODO Auto-generated constructor stub
		setName("toyota");
		setModelName("XYZ");
		setType("Sports");
}
	/*
	should return in the format : Car{Manufacturer name:'name',Model Name:'modelName',Type:'type'}
	*/     
	public String getManufacturerInformation() {
		// TODO Auto-generated method stub
			
	System.out.println("Manufacturer name:" +getName() + "," + "Model Name:" +getModelName() + "," + "Type:" +getType());
	return null;
	}

	public int maxSpeed(String Type) {
		if(Type.equals("Sports"))
			return 250;
		else
		return 190;
	}
}

class Bike extends AbstractManufacturer {
	
public Bike(String name, String modelName, String bikeType) {

}
public Bike() {
	// TODO Auto-generated constructor stub
	setName("Motorbike");
	setModelName("Bikespecialxyz");
	setType("Sports");
}
/*
Method returns maximum speed depending upon their types
For Sports-300kmh
For cruiser-170kmh
*/
@Override
public int maxSpeed(String bikeType) {
	if(bikeType.equals("Sports"))
		return 300;
	else
	return 170;
}
public String getManufacturerInformation() {
System.out.println("name:" +getName() + "," + "Model Name:" +getModelName() + "," + "Type:" +getType());
return null;
}
}

public class VehicleService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//create 2 objects of AbstractManufacturer , and pass instance of Car and Bike. access the methods with relavant parameters
		
		AbstractManufacturer obj = new Car();
		obj.setName("Honda");
            
		obj.getManufacturerInformation();
		AbstractManufacturer obj1 = new Bike();
        obj1.setName("Harleydavidson");
		obj1.getManufacturerInformation();
		
	}

}

