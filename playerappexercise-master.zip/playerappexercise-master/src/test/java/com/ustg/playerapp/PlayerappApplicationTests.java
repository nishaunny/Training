package com.ustg.playerapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlayerappApplicationTests {

	@Test
	void contextLoads() {
	}

}
