package com.ustg.playerapp.repository;

import org.springframework.stereotype.Repository;

import com.ustg.playerapp.model.Player;


import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface PlayerRepo extends JpaRepository<Player,String> {

	

}
