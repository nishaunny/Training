package com.ustg.playerapp.exception;

public class PlayerAlreadyExistException extends Exception{
	
	public PlayerAlreadyExistException(String msg) {
	
	super(msg);
	
	}

}
