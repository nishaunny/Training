package com.ustg.playerapp.service;

import java.util.List;

import com.ustg.playerapp.exception.PlayerAlreadyExistException;
import com.ustg.playerapp.exception.PlayerNotFoundException;
import com.ustg.playerapp.model.Player;

public interface PlayerService {
	
	
	Player addPlayer(Player player) throws PlayerAlreadyExistException;
	
	List<Player> viewPlayers();
	
	Player findeplayer(String id);
	Boolean deletePlayer(String playerid) throws PlayerNotFoundException;
	
	Player updatePlayer(Player ply) throws PlayerNotFoundException;

}
