package com.ustg.playerapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ustg.playerapp.exception.PlayerAlreadyExistException;
import com.ustg.playerapp.exception.PlayerNotFoundException;
import com.ustg.playerapp.model.Player;
import com.ustg.playerapp.service.PlayerService;

@Controller
public class PlayerController {
	
	@Autowired
	PlayerService playerserv;
	
	
	@PostMapping("/ustg/player/addData")
	public ResponseEntity<?> addPlay(@RequestBody Player playernew){
		
		try {
			Player result = playerserv.addPlayer(playernew);
			
			return new ResponseEntity<Player>(result,HttpStatus.CREATED);
		} catch (PlayerAlreadyExistException e) {
			// TODO Auto-generated catch block
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.CONFLICT);
		}
	}

	@GetMapping("/ustg/player/viewAll")
	public ResponseEntity<?> getPlayers(){
		
		List<Player> playerdata = playerserv.viewPlayers();
		
		return new ResponseEntity<List<Player>>(playerdata, HttpStatus.OK);
	}
	
	@RequestMapping("/ustg/player/deleteplayer/{playerid}")
	public ResponseEntity<?> deleteplayer(@PathVariable("playerid") String bid)
	{
		try {
		playerserv.deletePlayer(bid);
		return new ResponseEntity<String>("Deleted succssfully",HttpStatus.CREATED);
		}
		catch(PlayerNotFoundException e)
		{
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.NOT_FOUND);
		}
	}

	@RequestMapping("/ustg/player/modifyPlayer")
	public ResponseEntity<?> updateplayer(@RequestBody Player upd)
	{
		try
		{
			Player playupdated=playerserv.updatePlayer(upd);
			return new ResponseEntity<Player>(playupdated, HttpStatus.CREATED);
		}
		catch(PlayerNotFoundException e)
		{
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.NOT_FOUND);	
			
		}
	}
	

}

