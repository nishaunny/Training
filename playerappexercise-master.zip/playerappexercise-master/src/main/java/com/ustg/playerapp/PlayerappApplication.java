package com.ustg.playerapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan(basePackages="com.ustg.playerapp")

public class PlayerappApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlayerappApplication.class, args);
	}

}
