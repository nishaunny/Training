package com.ustg.playerapp.model;

import javax.persistence.Entity;

import javax.persistence.Id;

@Entity
public class Player {
	
	@Id
	String playerid;

	String playername;
	
	public String getPlayerid() {
		return playerid;
	}
	public void setPlayerid(String playerid) {
		this.playerid = playerid;
	}
	
	public String getPlayerName() {
		return playername;
	}
	public void setPlayerName(String playername) {
		this.playername = playername;
	}
	

}
