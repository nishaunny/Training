package com.ustg.playerapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ustg.playerapp.exception.PlayerAlreadyExistException;
import com.ustg.playerapp.exception.PlayerNotFoundException;
import com.ustg.playerapp.model.Player;
import com.ustg.playerapp.repository.PlayerRepo;

@Service
public class PlayerServiceImpl implements PlayerService {
	
	@Autowired
	PlayerRepo playerrepo;

	@Override
	public Player addPlayer(Player player) throws PlayerAlreadyExistException{
		// TODO Auto-generated method stub
		
		Optional<Player> playerexist=playerrepo.findById(player.getPlayerid());
		
		if (playerexist.isPresent())
			throw new PlayerAlreadyExistException("bookid exist");
		
		
		Player obj=playerrepo.save(player);
				return obj;

		
	}

	@Override
	public List<Player> viewPlayers() {
		// TODO Auto-generated method stub
		List<Player> playerlist= playerrepo.findAll();
		return playerlist;
	}
	
	public Player findeplayer(String id) {

  Optional<Player> opt=playerrepo.findById(id);
		
		if( opt.isPresent())
		return opt.get();
		else
			return null;
	}


	@Override
	public Boolean deletePlayer(String playerid) throws PlayerNotFoundException {
		// TODO Auto-generated method stub
		
		 Player found=findeplayer(playerid);
		 if(found==null)
			 throw new PlayerNotFoundException("invalid id");
			
		 
			playerrepo.deleteById(playerid);
			return true;

	}

	@Override
	public Player updatePlayer(Player ply) throws PlayerNotFoundException {
		// TODO Auto-generated method stub
		
		Player found=findeplayer(ply.getPlayerid());
		 if(found==null)
			 throw new PlayerNotFoundException("invalid id");
		 
		
		 found.setPlayerName(ply.getPlayerName());
		 
		 playerrepo.save(found);
		 
		return found;

	}

}
