package com.ustg.playerapp.exception;

public class PlayerNotFoundException extends Exception {

	public PlayerNotFoundException(String msg) {
		
		super(msg);
		
		}
}
