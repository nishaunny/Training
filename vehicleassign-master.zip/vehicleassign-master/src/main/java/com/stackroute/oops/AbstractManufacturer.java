package com.stackroute.oops;

/*
Class is having 3 fields name, modelName and type.
Type varies for different vehicles.
eg. Car is of type sedan, sports...
Bike is of type cruiser, sports...
 */
public abstract class AbstractManufacturer {
	String Name;
	String ModelName;
	String Type;

	public void setName(String name) {
		Name = name;
	}
	public void setModelName(String modelName) {
		ModelName = modelName;
	}
	public void setType(String type) {
		Type = type;
	}
	public String getModelName() {
	return ModelName;
	}
	public String getType() {
	return Type;
	}
	public String getName() {
	return Name;
	}
    public abstract String getManufacturerInformation();
}
