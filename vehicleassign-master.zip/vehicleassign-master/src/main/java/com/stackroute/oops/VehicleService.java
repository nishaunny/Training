package com.stackroute.oops;

public class VehicleService {
    /*
    create a Car object and return it
     */
    public Car createCar(String name, String modelName, String type) {
        Car obj1 = new Car("Car1","Carmodel","Sports");
    	return obj1;
    }

    /*
    create a bike object and return it
     */
    public Bike createBike(String name, String modelName, String type) {
        Bike firstobj2 = new Bike("BMW","S1000RR","Sports");
    	return firstobj2;
    }

    /*
    Method should compare the speed only if the vehicle is of "SPORTS" type.
    Method should return 0 when speeds are equal otherwise should return maximum vehicle speed.
    Method returns -1 if the type is not "SPORTS"
    */
    public int compareMaxSpeed(Vehicle first, Vehicle second) {
        /*
        Vehicle objects should be downcasted to their respective concrete types
        */
    	
    	String type = null;
    	String type2 = null;
    	if(first instanceof Car)
    	{
    		Car obj1 = (Car)first;
    		if(obj1!=null)
    			type = ((Car) first).getType();
    		
    	}
    	else if(first instanceof Bike)
    	{
    		Bike obj2 = (Bike)first;
    		if(obj2!=null)
    		type = ((Bike) first).getType();		
    	}
    	else if(second instanceof Car)
    	{
    		Car obj3 = (Car)second;
    		if(obj3!=null)
    		type2 = ((Car) second).getType();  		
    	}
    	else if(second instanceof Bike)
    	{
    		Bike obj4 = (Bike)second;
    		if(obj4!=null)
    		type2 = ((Car) second).getType();
    		
    	}
    	int Speed1=first.maxSpeed("Sports");
    	int Speed2=second.maxSpeed("Sports");
    	
    	if(type.equals("Sports") && type2.equals("Sports") && (Speed1==Speed2)) {
    
    			return 0;
    	}
    	else if(Speed1>Speed2) {
    		
    			return Speed1;
    		}	
    		else
    			return Speed2;
    	
          
    }
}
