package com.stackroute.oops;

public interface Vehicle {
    int maxSpeed(String type);
}
