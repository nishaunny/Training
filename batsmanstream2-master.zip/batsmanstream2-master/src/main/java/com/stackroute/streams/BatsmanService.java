package com.stackroute.streams;

import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import java.util.function.Predicate;
import java.util.stream.Collectors;

public class BatsmanService {
	Country count1 = new Country();
	public BatsmanService() {		
	}


	//if country is not found, exception thrown.
	//if arguments null, optional empty
	public Optional<String> getBatsman(List<Batsman> list, String name, String countrycode)throws CountryNotFoundException{
		if(count1.getCountryCode()!=countrycode)
			throw new CountryNotFoundException("country not found");
		if(list==null||name==null||countrycode==null||list.size()<0||name.isBlank()||countrycode.isEmpty())
			return Optional.empty();
		else if(list!=null) {
			//the batsman name, for a name, countrycode provided is returned.
			Optional<String> bats = list.stream().filter(bobj->bobj.getName().equals(name)&& bobj.getCountry().getCountryCode().equals(countrycode)).map(bobj->bobj.getName()).findAny();
			if( bats.isPresent())
			return bats;
		}
		return Optional.empty();

		
	}

	public String getBatsmanNamesForCountry(List<Batsman> list, String countrycode) {
		String batsnamelist = null;
		//null check for the arguments
		if(list==null||countrycode==null||countrycode.isBlank()||list.isEmpty())
			return null; 
		else {
				Predicate<Batsman> pred = (bat)->bat.getCountry().getCountryCode().equals(countrycode);
				//map, then sort after applying country code condition, get only the batsman names with join in a format.
				batsnamelist = list.stream().filter(pred).map(bat->bat.getName()).sorted().collect(Collectors.joining(",", "[","]"));
				return batsnamelist;
		}
					
	}
	//for matchesplayed more than 50, a map of name to runs is returned.
	public Map<String, Integer> getPlayerNameWithTotalRuns(List<Batsman> list) {
	
		Map<String,Integer> map2 = new HashMap<>();
		if(list==null)//list is null, return an empty map
	return map2;
		else
		{
			Map<String,Integer> map = list.stream().filter(bat->bat.getMatchesPlayed()>50).collect(Collectors.toMap(Batsman::getName, Batsman::getTotalRuns));
			return map;
		}
	}
//max score for a countryname is returned, int value.
	public int getHighestRunsScoredByBatsman(List<Batsman> list, String countryname) {
		if(list==null||countryname==null||list.isEmpty()||countryname.isBlank())//null check for the two arguments.
			return 0;
		else {
		Optional<Batsman> runs = list.stream().filter(bat->bat.getCountry().getName().equals(countryname)).max(Comparator.comparing(Batsman::getHighestScore));
		return runs.get().getHighestScore();
		}
	}
//for the countryname, return namebatsman sorted in descending order for totalruns>5000
	public Optional<LinkedList<String>> getPlayerNamesByCountry(List<Batsman> list, String countryname) {
		Optional<LinkedList<String>> opt;
		if(list==null || countryname==null||list.isEmpty()||countryname.isBlank())
			return Optional.empty();
		else {
			Predicate<Batsman> predbats = bat->bat.getCountry().getName().equals(countryname) && bat.getTotalRuns()>5000;
			for(Batsman bat:list)
				//return of optionalempty if totalruns<5000
			if(predbats.test(bat)) {
				//always after map, then do the sorting, sort reversed order to give in descending.
			List<String> playname = list.stream().filter(predbats).map(Batsman::getName).sorted(Comparator.reverseOrder()).collect(Collectors.toList());
			opt = Optional.of(new LinkedList<String>(playname));
			if(opt.isPresent())
				return opt;//optional linked list returned.
			}
			return Optional.empty();
		}
		
		
		
	}

}
