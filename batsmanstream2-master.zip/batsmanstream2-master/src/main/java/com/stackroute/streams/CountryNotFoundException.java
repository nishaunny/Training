package com.stackroute.streams;

public class CountryNotFoundException extends Exception{
	
	public CountryNotFoundException(String msg){
		super(msg);
	}

}
