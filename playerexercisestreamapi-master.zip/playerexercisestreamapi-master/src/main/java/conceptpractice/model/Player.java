package conceptpractice.model;

public class Player {
	
//	- Define a POJO class Player with playerName, 
//	matchesPlayed, runs, highestScore, Country as member variables
	
	private String playerName, Country;
	private int matchesPlayed,runs, highestScore;
	
	
	public Player(String name, int matchplay, int runs, int highScore, String Country) {
		this.playerName=name;
		this.Country=Country;
		this.highestScore=highScore;
		this.matchesPlayed=matchplay;
		this.runs =runs;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
	public int getMatchesPlayed() {
		return matchesPlayed;
	}
	public void setMatchesPlayed(int matchesPlayed) {
		this.matchesPlayed = matchesPlayed;
	}
	public int getRuns() {
		return runs;
	}
	public void setRuns(int runs) {
		this.runs = runs;
	}
	public int getHighestScore() {
		return highestScore;
	}
	public void setHighestScore(int highestScore) {
		this.highestScore = highestScore;
	}
	
	
	public String toString() {
		
		return "Playername " + playerName + " Countryname " + Country + " Matchesplayed " + matchesPlayed + " Runs " + runs + " highest score " + highestScore;
	}
	

}
