package conceptpractice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import conceptpractice.model.Player;

/*From the List of Players, extract data in the following methods

- getPlayersByCountry
	- Return a map with key as country name and value as List of players

- getPlayerNamesByCountry
	- Return a map with key as country name and value as List of player Names who have played more than 100 matches

- getTotalPlayersByCountry
	- Return a LinkedHashMap with key as country name and value as number of players in each country

- getTotalRunsByCountry
	- Return a map with key as country name and value as sum total runs of all players

- getMaxScoreByCountry
	- Return a map with key as country name and value as maximum of the runs scored by players in that country
	
- getPlayerNamesStringByCountry
	- Return a map with key as country name and value as String of player Names separated by comma*/

public class PlayerAnalysis {
	static List<Player> playerslist;
	public PlayerAnalysis() {
		playerslist = new ArrayList();
	}

	public static void main(String[] args) {
		
			Player play1 = new Player("Ram", 110, 20, 100, "India");
			Player play2 = new Player("Sam", 200, 10, 200, "UK");
			Player play3= new Player("Tammy", 50, 30, 100, "India");
			Player play4 = new Player("John", 30, 15, 300, "US");
			Player play5 = new Player("Ron", 170, 20, 100, "India");
			Player play6 = new Player("Hamlet", 900, 10, 90, "Singapore");
			
			playerslist = Arrays.asList(play1, play2,play3,play4,play5,play6);
			
			getPlayersByCountry();
			getPlayerNamesByCountry();
			 getTotalPlayersByCountry();
			 getTotalRunsByCountry();
			 getMaxScoreByCountry();
			 getPlayerNamesStringByCountry();
	}
//	- getPlayersByCountry
//	- Return a map with key as country name and value as List of players
	static void getPlayersByCountry() {
		
		Map<String,List<Player>> playerdata = playerslist.stream().collect(Collectors.groupingBy((pobj)->pobj.getCountry()));
		
		playerdata.forEach((k,v)->System.out.println("Countryname :" +k+ "\nPlayer details:\n" +v));
	}
//	- getPlayerNamesByCountry
//	- Return a map with key as country name and value as List of player Names who have played more than 100 matches		
	static void getPlayerNamesByCountry() {
		//- Return a map with key as country name and value as List of player Names who have played more than 100 matches
//		Map<Department, Set<Employee>> wellPaidEmployeesByDepartment
//		   = employees.stream().collect(
//		     groupingBy(Employee::getDepartment,
//		                filtering(e -> e.getSalary() > 2000,
//		                          toSet())));- full list based on condition.
	
		
		Map<String,List<String>> playerdataname = playerslist.stream().filter((pobj)->pobj.getMatchesPlayed()>100).collect(Collectors.groupingBy((pobj)->pobj.getCountry(), Collectors.mapping((pobj)->pobj.getPlayerName(), Collectors.toList())));
		playerdataname.forEach((k,v)->System.out.println("Countryname :" +k+ "\nPlayer scored more than 100:\n" +v));
		
	}
	
//	- getTotalPlayersByCountry
//	- Return a LinkedHashMap with key as country name and value as number of players in each country
	static void getTotalPlayersByCountry() {
		
		LinkedHashMap<String,Long> totalplaydata = playerslist.stream().collect(Collectors.groupingBy((pobj)->pobj.getCountry(), LinkedHashMap::new, Collectors.counting()));
		totalplaydata.forEach((k,v)->System.out.println("Countryname :" +k+ "\nPlayercount:\n" +v.longValue()));
	}
//	- getTotalRunsByCountry
//	- Return a map with key as country name and value as sum total runs of all players
	static void getTotalRunsByCountry() {
		
		Map<String,Integer> totalrundata = playerslist.stream().collect(Collectors.groupingBy((pobj)->pobj.getCountry(),Collectors.summingInt((pobj)->pobj.getRuns())));
		
		totalrundata.forEach((k,v) ->System.out.println( "Countryname :" +k+ "Total runs :" +v.intValue()));
	}
	
//	- getMaxScoreByCountry
//	- Return a map with key as country name and value as maximum of the runs scored by players in that country
	
	static void getMaxScoreByCountry() {
		
		Map<String, Optional<Player>> maxscore = playerslist.stream().collect(Collectors.groupingBy((pobj)->pobj.getCountry(), Collectors.maxBy(Comparator.comparing((pobj)->pobj.getRuns()))));
		
		
		maxscore.forEach((k,v) ->System.out.println( "Countryname for runs :" +k+ "Maxscoreinruns :" +v.get().getRuns()));
		
	}
	
	/*- getPlayerNamesStringByCountry
	- Return a map with key as country name and value as String of player Names separated by comma*/
	
	static void getPlayerNamesStringByCountry() {
		
		Map<String,String> playcommalist = playerslist.stream().collect(Collectors.groupingBy((pobj)->pobj.getCountry(), Collectors.mapping(Player::getPlayerName, Collectors.joining(","))));
		
		playcommalist.forEach((k,v)-> System.out.println("Country ::"+k+ " Playernames: "+v));
	}
}
