import { Component, OnInit } from '@angular/core';
import { Note } from './note';
import { NotesService } from './notes.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  errMessage: string;
  step = 0;
  setStep(index: number) {
    this.step = index;
  }
  nextStep(){
      this.step++;
    this.addItem();
  }
  prevStep(){
    this.step--;
  }
  noteobj: Note;
  notes: Array<Note>=[];
  constructor(private servobj: NotesService){
    this.noteobj = new Note();
  }
  ngOnInit(): void {
    this.servobj.getNotes().subscribe(
      (res)=>{this.notes=res;},
    (error)=>this.errMessage=error.message);
  }
  addItem(){
    if((!this.noteobj.title)||(!this.noteobj.text))
    this.errMessage="Title and Text both are required fields";
    else if(this.noteobj.title!=null && this.noteobj.text!=null)
    {
    this.servobj.addNote(this.noteobj).subscribe((res)=>{this.notes.push(this.noteobj);}, 
    (error)=>
    this.errMessage=error.message);
    }
  }
}
