import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError } from 'rxjs/operators/catchError';
import { Note } from './note';

@Injectable()
export class NotesService {

  constructor(private httpcli: HttpClient){
   
  }

  getNotes(): Observable<Array<Note>> {

    return this.httpcli.get<Array<Note>>("http://localhost:3000/notes");

  }

  addNote(note: Note): Observable<Note> {

    return this.httpcli.post<Note>("http://localhost:3000/notes",note);

  }

}
