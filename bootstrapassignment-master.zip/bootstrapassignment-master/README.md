This project has index.html, a web page designed using bootstrap v.4, is like a book store using elements like header, navbar, carosuel, jumbotron, featurette and footer.
This page is linked to another page, discover.html to show some genere of books details making use of card.
Also, footer makes use of font awesome icons, some part of body, header uses it. In some areas, google font style is also been used.
The stylesheet is in the styles folder and some other files were copied when the source code example was included while refering the bootstrap official site.

* 1. Two Html pages
* 2. Styles> css files
* 3. Assets> contains the necessary bootstrap files.
* 4. Images> contain the imagery used.
