import { Component, OnInit } from '@angular/core';
import { Product } from 'src/product';
import { ProductserviceService } from '../productservice.service';

@Component({
  selector: 'app-listview',
  templateUrl: './listview.component.html',
  styleUrls: ['./listview.component.css']
})
export class ListviewComponent implements OnInit {
  products : Array<Product>=[];
  constructor(private servobj: ProductserviceService) { }

  ngOnInit(): void {

    this.getProducts();
  }

  getProducts(){
    return this.servobj.getProducts().subscribe(
      res=> this.products=res
      )
  }
}
