import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ProducttakerComponent } from './producttaker/producttaker.component';
import { GridviewComponent } from './gridview/gridview.component';
import { ListviewComponent } from './listview/listview.component';
import { ProductComponent } from './product/product.component';
import {FormsModule} from '@angular/forms';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatCardModule}  from '@angular/material/card';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatFormFieldModule} from '@angular/material/form-field';
import { HttpClientModule } from '@angular/common/http';
import {MatInputModule} from '@angular/material/input';


import {RouterModule, Routes} from '@angular/router';
import { ProducteditopenerComponent } from './producteditopener/producteditopener.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

const routes: Routes =[
  {
    path:'dashboard',
    component:DashboardComponent,
    children:
    [
      {
        path:'view/grid',
        component:GridviewComponent,
      },
      {
        path:'view/list',
        component:ListviewComponent,
      },
      {
        path:'product/:pid/edit',
        component:ProducteditopenerComponent,
        outlet:'productEditoutlet'

      },
      {
        path:'',
        redirectTo:'view/grid',
        pathMatch: 'full'
      }
    ]
    
  },

  {
     path:'',
    redirectTo:'dashboard',
    pathMatch:'full'
  }
]

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    DashboardComponent,
    ProducttakerComponent,
    GridviewComponent,
    ListviewComponent,
    ProductComponent,
    ProducteditopenerComponent
  ],
  imports: [
    BrowserModule,
    RouterModule,
    RouterModule.forRoot(routes),
    FormsModule,
    BrowserAnimationsModule,
    MatExpansionModule,
    MatCardModule,
    MatToolbarModule,
    MatFormFieldModule,
    HttpClientModule,
    MatInputModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
