import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class RoutingService {

  constructor(private routerobj: Router) { }


  openDashboard(){

    this.routerobj.navigate(['dashboard']);
  }


  openGridview(){

    this.routerobj.navigate(['dashboard/view/grid']);
  }

  openListView(){

    this.routerobj.navigate(['dashboard/view/list']);
  }


  openeditViewAuxRoute(productid:any)
    {
    this.routerobj.navigate(['dashboard',
    {
     outlets: { productEditoutlet: ['product',productid,'edit']}}
  ]);
}
}