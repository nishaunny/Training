import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { BehaviorSubject, Observable } from 'rxjs';
import { AuthorizeService } from './authorize.service';
import { Product } from 'src/product';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {

  products : Array<Product>=[];
  productsubject: BehaviorSubject<Array<Product>>;


  constructor(private httpcli: HttpClient, private authserobj: AuthorizeService) { 

    this.productsubject=new BehaviorSubject<Array<Product>>([]);
  }


  addProduct(productobj : Product) : Observable<Product>
  {
    let tok=this.authserobj.getToken();

  return  this.httpcli.post<Product>('http://localhost:3000/api/v1/products',productobj,
  {
    headers: new HttpHeaders().set('Authorization',`Bearer ${tok}`)
  }
  ).
  pipe(

     tap( (nproduct:Product) =>
      {
        this.products.push(nproduct);
        this.productsubject.next(this.products);
      //  return this.productsubject
      }
  )
  );
  }


  getProducts(): BehaviorSubject<Array<Product>>{

    return this.productsubject;

  }

  fetchdatafromServer(){
    let tok=this.authserobj.getToken();
    return this.httpcli.get<Array<Product>>('http://localhost:3000/api/v1/products',
    {
     headers: new HttpHeaders().set('Authorization',`Bearer ${tok}`)
   }
   ).subscribe(

    (res)=>{
            this.products=res;
            this.productsubject?.next(this.products);
    },

    (err)=>
       this.productsubject?.error(err)
   )


  }
}
