import { Component, OnInit } from '@angular/core';
import { RoutingService } from '../routing.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private routeobj: RoutingService) { }

  ngOnInit(): void {
  }

  grid(){

    this.routeobj.openGridview();
  }

  list(){
    this.routeobj.openListView();
  }
}
