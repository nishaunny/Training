import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-producteditopener',
  templateUrl: './producteditopener.component.html',
  styleUrls: ['./producteditopener.component.css']
})
export class ProducteditopenerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
