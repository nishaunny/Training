import { Component, OnInit } from '@angular/core';
import { Product } from 'src/product';
import { ProductserviceService } from '../productservice.service';



@Component({
  selector: 'app-gridview',
  templateUrl: './gridview.component.html',
  styleUrls: ['./gridview.component.css']
})
export class GridviewComponent implements OnInit {
   
  
  products : Array<Product>=[];


  constructor(private servobj: ProductserviceService) { }

  ngOnInit(): void {
    this.getProducts();
  }

  getProducts()///retuns the behaviour subject
  {
    return this.servobj.getProducts().subscribe(
      res=> this.products=res
      )
  }
}
