import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthorizeService {

  constructor(private httpcli: HttpClient) { }


  connectToserver(data:any): Observable<any> {

    return this.httpcli.post('http://localhost:3000/auth/v1',data);
  }

  storeToken(tok:any)
   {
     sessionStorage.setItem("mytoken",tok);
   }

  getToken() :any{
    return sessionStorage.getItem("mytoken");
  }

  
}
