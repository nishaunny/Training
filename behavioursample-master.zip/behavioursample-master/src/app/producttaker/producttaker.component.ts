import { Component, OnInit } from '@angular/core';
import { Product } from 'src/product';
import { ProductserviceService } from '../productservice.service';


@Component({
  selector: 'app-producttaker',
  templateUrl: './producttaker.component.html',
  styleUrls: ['./producttaker.component.css']
})
export class ProducttakerComponent implements OnInit {
  
  errmessage:string="";
  
  products : Array<Product>=[];

  Productobj: Product = new Product();

  constructor(private prodserv: ProductserviceService) { }

  ngOnInit(): void {
  }

  addProduct(){

    this.prodserv.addProduct(this.Productobj).subscribe(
      (res)=> {this.products.push(res)},
    (err)=> {this.errmessage=err.message});

  }
}
