package playercasestudy.player.service;

import java.util.List;

import playercasestudy.player.model.Player;
import playercasestudy.player.repository.PlayerReadImpl;
import playercasestudy.player.repository.PlayerWriteImpl;
import playercasestudy.player.repository.iPlayerRead;
import playercasestudy.player.repository.iPlayerWrite;

public class PlayerServiceImpl implements iPlayerService{

	iPlayerRead readobj;
	iPlayerWrite writeobj;
	
	public PlayerServiceImpl(String filename, int choice) throws Exception {
		
		if (choice==1) {
			try {
			readobj = new PlayerReadImpl(filename);
			}
		catch (Exception e) {
			e.printStackTrace();
			readobj=null;
		}
	}
		else if(choice==2)
		{
			writeobj = new PlayerWriteImpl(filename);
		}
	}
	@Override
	public List<Player> showPlayerData() throws Exception {
		if(readobj!=null)
		{
			return readobj.getPlayerdata();
		}
		return null;
		
	}

	@Override
	public void addPlayer(Player player) throws Exception {
		writeobj.add(player);
		System.out.println("Added to the playerlist.");
	}
	
	

}
