package playercasestudy.player.service;

import java.util.List;

import playercasestudy.player.model.Player;

/*iPlayerService - interface - showPlayerData():Array<Player>,
addPlayer(Player)
PlayerServiceImpl*/
public interface iPlayerService {

	List<Player>showPlayerData() throws Exception;
	
	void addPlayer(Player player) throws Exception;
}
