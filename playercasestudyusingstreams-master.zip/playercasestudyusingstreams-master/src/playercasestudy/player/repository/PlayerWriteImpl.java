package playercasestudy.player.repository;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import playercasestudy.player.exception.PlayerAlreadyFoundException;
import playercasestudy.player.model.Player;

public class PlayerWriteImpl implements iPlayerWrite{

	
	
	List<Player> newplayerlist = new ArrayList<Player>();
	ObjectOutputStream objout;
	
	List<Player> getData(String filename){
		
		List<Player> data=new ArrayList<Player>();
		iPlayerRead read;
		try
		{
			//read the list retrieved from the file - playerreadrepoclass.
		read = new PlayerReadImpl(filename);
		data=read.getPlayerdata();
		}
		catch(Exception e)
		{
			read=null;
		}  	
		
		return data;

	}
	
	public PlayerWriteImpl(String filename) throws Exception{
		//list from getData() is stored in the newplayerlist variable.
		newplayerlist = getData(filename);
		//outputstream to write back to the file.
		FileOutputStream fileout=new FileOutputStream(filename);
		objout = new ObjectOutputStream(fileout);
		
	}
	
	@Override
	public void add(Player player) throws Exception,PlayerAlreadyFoundException {
		//ListIterator objlist = newplayerlist.listIterator();
		//if(objlist.equals(player.getPlayerId()))
		//{
			//throw new PlayerAlreadyFoundException("player found in the list");
		//}
		//else {
		try
		{
        //to the list, new player object added.
		newplayerlist.add(player);
		//list is written back to the file using outputstream.
		objout.writeObject(newplayerlist);
		
	    }
		catch(Exception e)
		{
			System.out.println("error " + e.getMessage());
		}
		finally
		{
			objout.close();
			System.out.println("file closed");
		}
		}
		//}

}
