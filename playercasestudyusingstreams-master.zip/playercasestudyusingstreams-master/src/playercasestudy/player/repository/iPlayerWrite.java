package playercasestudy.player.repository;

import playercasestudy.player.model.Player;

public interface iPlayerWrite {
	
	void add(Player player) throws Exception;

}
