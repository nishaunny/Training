package playercasestudy.player.repository;

import java.util.List;

import playercasestudy.player.model.Player;

public interface iPlayerRead {
	
	List<Player> getPlayerdata() throws Exception;

}
