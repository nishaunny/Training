package playercasestudy.player.repository;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

import playercasestudy.player.model.Player;

public class PlayerReadImpl implements iPlayerRead{

	List<Player> playerreadlist=new ArrayList<Player>();
	  FileInputStream filein;
	  ObjectInputStream objinput;
	  
	  public PlayerReadImpl(String filename) throws Exception
		 {
		  //Objectinputstream is used to read the file.
			filein =new FileInputStream(filename);
			objinput=new ObjectInputStream(filein);
			 
			 
		 }


	@Override
	public List<Player> getPlayerdata() throws Exception {
		try
		{
			//the data read from file is stored as a list.
			playerreadlist= (List<Player>)objinput.readObject();
			
		}
		catch(Exception e)

		{
			System.out.println("exception " + e);
		}

		finally
		{
			objinput.close();
		}
		System.out.println("Player Details:" + playerreadlist);
				return playerreadlist;
			}

			

	}


