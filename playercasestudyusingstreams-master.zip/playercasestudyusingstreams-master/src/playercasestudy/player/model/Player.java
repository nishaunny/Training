package playercasestudy.player.model;

import java.io.Serializable;

public class Player implements Serializable {
	
	private String playerName;
	private int playerId;
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	
	public Player() {}
	public Player(String playname, int id)
	{
		this.playerName=playname;
		this.playerId=id;
	}
	public String toString()
	{
		return "Id no "  + playerId + "player name " + playerName;
		
	}


}
