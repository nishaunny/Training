package playercasestudy.player;

import java.util.Scanner;

import playercasestudy.player.model.Player;
import playercasestudy.player.service.PlayerServiceImpl;
import playercasestudy.player.service.iPlayerService;

public class PlayerClass {
	public static void main(String[] args) throws Exception {
		 
		//	
		//iPlayerService newobj = new PlayerServiceImpl("playerdata.dat")
			
		 
		String ch="y";
		Scanner scan=new Scanner(System.in);
		
			while (ch.equals("y"))
			{
				System.out.println("1 View Player Details");
			    System.out.println("2 Add Player with id and Name\n");
			    int choice=scan.nextInt();

			switch(choice)
			{
			case 1:
				iPlayerService newobj = new PlayerServiceImpl("playerdata.dat",1);
			    newobj.showPlayerData();
				break;
			case 2:
				iPlayerService newobj2 = new PlayerServiceImpl("playerdata.dat",2);
				System.out.println("Give the playername and player id");
				Player player=new Player(scan.next(),scan.nextInt());
				newobj2.addPlayer(player);
				
				
			
			 }//switch

			} // while
			
			System.out.println("Do you want to continue? y or n");
			ch = scan.next();
			
		} //main
	
	
	

}
