package playercasestudy.player.exception;

public class PlayerAlreadyFoundException extends Exception {

	public PlayerAlreadyFoundException(String e) {
	super(e);
	}
}
