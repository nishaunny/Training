import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.stackroute.collections.CricketScoreAnalyzer;

public class CricketScoreAnalyzertests {

	
CricketScoreAnalyzer scorecardobj = new CricketScoreAnalyzer();
	
@Test//the contstructor that returns hashmap object.
public void cricketScoreAnalyzershouldNotReturnNonNull() {
	
	Assertions.assertNotNull(scorecardobj);
	
}

@Test//Add runs method, is it non null value.
public void addRunstoScoreCardshouldNotReturnNonNull() {
	
	Assertions.assertNotNull(scorecardobj.addRunsToScoreCard("Sachin", 50));
	
}

@Test//Getruns method is it non null.
public void getRunsScoredshouldNotReturnNonNull() {
	
	scorecardobj.addRunsToScoreCard("Sachin", 50);
	
	Assertions.assertNotNull(scorecardobj.getRunsScored("Sachin"));
	
}


@Test//Get runs returns the right value for a batsmen.
public void getRunsScoredshouldReturnRightValue() {
	scorecardobj.addRunsToScoreCard("Sachin", 50);
	
	Assertions.assertEquals(50, scorecardobj.getRunsScored("Sachin"));
	
}

@Test//Total runs method is not null and right value checked..
public void getTotalRunsMustReturnRightValue() {
	
	scorecardobj.addRunsToScoreCard("Sachin", 50);
	scorecardobj.addRunsToScoreCard("Sain", 45);
	
	
	Assertions.assertEquals(95, scorecardobj.getTotalRuns());
	
}

@Test//Total runs method returns is not null.
public void getTotalRunsisNotNull() {
	scorecardobj.addRunsToScoreCard("Sachin", 50);
	scorecardobj.addRunsToScoreCard("Sain", 45);
	
	Assertions.assertNotNull(scorecardobj.getTotalRuns());
	
}

@Test//Gethighest runs is not returning null.
public void getHighestRunsScoredNotNull() {
	
	scorecardobj.addRunsToScoreCard("Sachin", 50);
	scorecardobj.addRunsToScoreCard("Sain", 45);

	scorecardobj.addRunsToScoreCard("Mandy", 40);
	
	Assertions.assertNotNull(scorecardobj.getHighestRunsScored());
	
}

@Test//Get highest returns the value as expected.
public void getHighestRunsScoredReturnsRightValue() {
	
	scorecardobj.addRunsToScoreCard("Sam", 55);
	
	Assertions.assertEquals(55,scorecardobj.getHighestRunsScored());
	
}

@Test//Get sorted batsmen is not null.
public void getSortedBatsmenNameReturnsNonNull(){
	
	
	
	Assertions.assertNotNull(scorecardobj.getSortedBatsmanName());
	
}

@Test//Get batsmen returns a list with highest runs.
public void getBatsmenNamewithHighestRunshouldReturnNonNull(){
	
	scorecardobj.addRunsToScoreCard("Sam", 55);
	scorecardobj.addRunsToScoreCard("Mandy", 40);
	List<String> batsmenNames = new ArrayList<>();
	batsmenNames.add("Sam");
	Assertions.assertEquals(batsmenNames, scorecardobj.getBatsmenNamesWithHighestRuns());
	
}
}
