package day1;

import java.util.Scanner;
/*29thApril - Exercise2: 
 * Problem Statement: Find the average of an array 
 * using for and for-each loop
 * Program to find the average of the input values from user
for an array.*/

public class NumberAverage {

    public static void main(String[] args) {
        new NumberAverage().getArrayValues();
    }

    //get the values of the array from the user
    public void getArrayValues() {
    	//scanner obj is initialized
    	Scanner scan = new Scanner(System.in);
        System.out.println("Enter number of values:");
    	int num = scan.nextInt();
    	//waiting for user input on size of array
    	int[] array = new int[num];
    	//assign the size to the array's size
    	System.out.println("Enter the values:");
    	//waiting for the values in the array
    	for(int i=0;i<num;i++) {
    		array[i]= scan.nextInt();
    		//every element of array is received as user's input
    	}
    	new NumberAverage().findAverage(array);
    	//findAverage method is called
    	scan.close();	
    }

    //write here logic to calculate the average an array
    public String findAverage(int[] inputArray) {
    	int sum = 0;
    	//for each loop is used to calculate the sum of element values.
    		for(int in : inputArray) {
    			
    			sum = sum + in;
    		}
        //if total of array values is 0, invalid 
    		// else the average is calculated.
    	if (sum!=0) {
    	double average = sum/inputArray.length;
    	System.out.println("Average is" +average);
    	}
    	else
    	{
    		System.out.println("Array is not valid");
    	}

        return null;
    }
}
