package day1;
/* Assignment1
 * ## Problem Statement: Develop a calculator using switch case ##

**Get two numbers of type of integer or double from the user 
*and perform the operation(Add,Multiply,Divide,Subtract)
selected by the user using switchcase, 
if-else statement,break and looping switchcase using recursion**
*/
import java.util.Scanner;

public class Calculator {
    private static Scanner scan;

    // define,declare scanner and call getValues with scanner as parameter
    public static void main(String[] args) {
        scan = new Scanner(System.in);
        new Calculator().getValues(scan);
    }

    //Get values and which operator from the menu
    public void getValues(Scanner scan) {
    //First number, second number and operation number is received from user.
       System.out.println("Enter the first number");
       int first = scan.nextInt();
 
       System.out.println("Enter the second number");
       int sec = scan.nextInt();
       
       System.out.println("Enter the number for operation to perform 1-Add, 2-Sub, 3-Multiply, 4-Divide");
       int choice = scan.nextInt();
       //passing user's input to the calculate method.
       new Calculator().calculate(first, sec, choice);
       
       
    }

    //perform operation based on the chosen switch case corresponding to the menu and return string
    public String calculate(int firstValue, int secondValue, int operator) {
    	//variables are assigned for 3 parameters.
    	int f = firstValue;
    	int s = secondValue;
    	int b = operator;
    	int add;
    	int sub;
    	int mul;
    	int div;
    	//switch case for 4 operations and default is defined.
    	while(b<=4) {
    		System.out.println("Your numbers and operation is" + f + "," +s + "," +b);	
    		switch(b)
    		{	
    		case 1:
    			add = f + s;
    			System.out.println(+f+ "+" +s+ "=" +add);
    			break;
    		case 2:
    			sub = f - s;
    			System.out.println(+f+ "-" +s+ "=" +sub);
    			break;
    		case 3:
    			mul = f * s;
    			System.out.println(+f+ "*" +s+ "=" +mul);
    			break;
    		case 4:	
    			div = f / s;
    			System.out.println(+f+ "/" +s+ "=" +div);
    			break;		
    		default:
        		break;
    	    }
    		//to iterate and make user input numbers 1 to 4.
    		System.out.println("Do you want to continue? y/n, enter b value");
    		b = scan.nextInt();	
    				
    	}
		//if a number > 4 is inputed or 0.
		if (b>4) {
	        System.out.println("Entered wrong option " +b);
			}
        return null;
    }
}