package day1;
/*
 * 30th April - Method Overloading exercise: Define a class called 2DGeometry that encapsulates the functions for surface area computation of the geometrical objects - square, rectangle.
   Define another class called 3DGeometry that encapsulates the above functions in addition to a function for computing the volume of the geometrical objects - cube, cuboid.
   Use  method overloading.
 */
import java.util.Scanner;

class TwodGeometry{
	
	float a;
	float b;
	float c;
	public float getA() {
		return a;
	}

	public void setA(float a) {
		this.a = a;
	}

	public float getB() {
		return b;
	}

	public void setB(float b) {
		this.b = b;
	}

	public float getC() {
		return c;
	}

	public void setC(float c) {
		this.c = c;
	}

	//Twodclass with 2 methods to calculate square and rectangle's area.
	void CalArea(float x) {
		float area = getA()*getA();
		System.out.println("Area of square" +area);
	}
	
	void CalArea(float x, float y) {
		float rect = getB()*getC();
		System.out.println("Area of rectangle" +rect);
	}
}


class dGeometry extends TwodGeometry{
	//3d class to calculate cube and cuboid's area with 2 methods.
	public void CalArea(int x) {
		double cube = x*x*x;
		System.out.println("Area of cube" +cube);
		
	}

	public void CalArea(int l, int b, int h) {
		double cuboid = 2*((l*b)+(b*h)+(h*l));
		System.out.println("Area of cuboid" +cuboid);
	}	

}


public class CalculateAreageo {

	public static void main(String[] args) {

		//Created object of 2nd class and called 4 methods.
		dGeometry geobj = new dGeometry();
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a value to calculate area of square:");
		geobj.setA(scan.nextFloat());
		geobj.CalArea(geobj.getA());
		System.out.println("Enter two values to calculate area of rectangle:");
		geobj.setB(scan.nextFloat());
		geobj.setC(scan.nextFloat());
		geobj.CalArea(geobj.getB(), geobj.getC());
		System.out.println("Enter a value to calculate area of cube:");
		geobj.CalArea(scan.nextInt());
		System.out.println("Enter a value to calculate area of cuboid:");
	    geobj.CalArea(scan.nextInt(), scan.nextInt(), scan.nextInt());
		scan.close();
        

	}
	
}
