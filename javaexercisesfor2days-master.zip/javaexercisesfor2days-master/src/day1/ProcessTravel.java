package day1;

import java.util.Scanner;
// Exercise1: First java task provided with a public class ProcessTravel and
// class Traveller to use getter, setter with variables defined
// get inputs from user for the variables and two methods
// to display details and set the price.
class Traveller {
	
	//private variables defined.
	private int id;
	private String travelType;
	private double price;
	private String locations;
	private int year;
	
	//getter and setter for the variables.
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTravelType() {
		return travelType;
	}
	public void setTravelType(String travelType) {
		this.travelType = travelType;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getLocations() {
		return locations;
	}
	public void setLocations(String locations) {
		this.locations = locations;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	// method to display the details of the variables.
	public void showDetails() {
		
		System.out.println("The values are");
		System.out.println("id is" +getId());
		System.out.println("Traveltype is" +getTravelType());
		System.out.println("Price is" +getPrice());
		System.out.println("Location is" +getLocations());
		System.out.println("Year is" +getYear());
		
	}
	//method to set the price based on the traveltype.
	void setPricepolicy() {
	    if (travelType.equals("Local"))
	    {
		 setPrice(5000);
		}	
	    else
	    {
	     setPrice(1000);
	    }
	}
	
}
//Process Travel main class that takes the user input for
//the variables and sets it.
//Also the methods are accessed, to display the information.
public class ProcessTravel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Traveller tra = new Traveller();
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter the id value:");
	int id = scan.nextInt();
	tra.setId(id);
	System.out.println("Enter the location value:");
	tra.setLocations(scan.next());
	System.out.println("Enter your traveltype - local or not:");
	tra.setTravelType(scan.next());
	System.out.println("Enter the Year:");
	int year = scan.nextInt();
	tra.setYear(year);
	tra.setPricepolicy();
	tra.getPrice();
	tra.showDetails();
    scan.close();
	}

}
