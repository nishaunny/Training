package com.stackroute.collections;


import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;


import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class ProductSetServiceTests {
	
	int prodid;
	String productName, oldProductname, newProductName;
	double price;
	Product productobj;
	Product productobj1;
	Product productobj2;
	Product productobj3;
	ProductSetService producthash = new ProductSetService();
	Set<Product> productsetobj= producthash.getProductSet();
	
	String Message01="please check the getProductSet() as it doesnot return as expected.";
	String Message02="Add productset method does not add to the set. Please check the logic.";
	String Message03="Check the logic in the product with highest price, whether returns correct.";
	String Message04="Check the replace with new product name function, it does not set with new product name.";
	
	public ProductSetServiceTests(int prodid, String productName, double price, String oldProductname, String newProductName) 
	{
           super();
           this.prodid = prodid;
           this.productName = productName;
           this.newProductName= newProductName;
           this.oldProductname= oldProductname;
           this.price = price;
	
	}
	
	
	@Before
	public void initialize() throws InvalidPriceException
	{
		productobj=new Product(35,"hoshimilkcooker",100);
		productobj1=new Product(36,"Ushamachine",50);
		productobj2=new Product(38,"machine",5150);
		productobj3=new Product(37,"Acermachine",110);
	}
	
	@Parameters
	public static Collection inputdata()
	{
	   
		return Arrays.asList(
				
				new Object[][]
						{
					{12,"Tapasya",100,"Laptop","Laptop3"},
						}
				
				
				);
		}
	
	@Test//1-this test checks whether getProductSet returns a hashset.
	public void getProductSetFunctionReturnsNonNullButHashSet()
	{
		 Assertions.assertEquals(productsetobj,producthash.getProductSet(),Message01);
	}

	
	@Test//2-this test checks whether the addmethod returns true, after adding product object to hashset.
	public void addProductTosetDoesNotReturnNull() throws InvalidPriceException{
	
		Assertions.assertEquals(true, productsetobj.add(productobj), Message02);
	}
	
	@Test//3-The product with highest price is returned right value.
	public void getProductWithTheHighestPriceReturnsCorrectValue() {
		
		productsetobj.add(productobj2);
		productsetobj.add(productobj);
		productsetobj.add(productobj1);
		productsetobj.add(productobj3);
		

		Assertions.assertEquals(Collections.max(productsetobj), producthash.getProductWithHighestPrice(),Message03);
	}
	@Test//4-getProductIdList does not return null value.
	public void getProductGivenProductIdAsListinDescendingOrderDoesNotReturnNull() {

		
		Assertions.assertNotNull(producthash.getProductIdList());
	}
	
	@Test//5-Two tests to check whether not a null value returned, highest price is removed with remove product function.
	public void removeProductwithPricehighThan5000ReturnsRightValue() {
		
		Assertions.assertEquals(productsetobj,producthash.removeProductWithPriceHigherThanFiveThousand());
	}
	
	
	  @Test //6&7-Two tests, one to check the return of method is not null
	  //if the product is replaced with newproductname and changes in hashset.
	  public void replaceWithNewProductNamereturnsProductwithNewName() throws InvalidPriceException {
		  String oldProductName="hoshimilkcooker";
		  String newProductName="milkcooker";
		  productsetobj.add(productobj);
		  productsetobj.add(productobj1);
		  productsetobj.add(productobj2);
		  productsetobj.add(productobj3);
		  Product productobj4 = producthash.replaceProductName(oldProductName, newProductName);
		  Assertions.assertNotNull(productobj4);//if returned product is not null, has newProductName.
	      Assertions.assertEquals(productobj4.getProductName(), productobj.getProductName());
	  
	  }
	 
	  @Test//8-removeproduct method does not return null
	  public void removeProductwithPricehighThan5000ReturnsNotNull() {
			
			Assertions.assertNotNull(producthash.removeProductWithPriceHigherThanFiveThousand());
			
		}

		
}
