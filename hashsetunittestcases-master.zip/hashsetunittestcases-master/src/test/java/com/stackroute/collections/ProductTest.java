package com.stackroute.collections;



import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;



import java.util.Arrays;

//import static org.junit.runners.parameterized.*;

import java.util.Collection;

import org.junit.jupiter.api.Assertions;

@RunWith(Parameterized.class)
public class ProductTest {
	
	int pid;
	String pname;
	double pricetype;
	Product productobj;
	Product productobj1;
	private static final String Message01 = "check the setter for Product Name.";
	private static final String Message02 = "check the getters for Properties id,name and price.";
	private static final String Message03 = "please check the compareTo method for price calculation.";
	
	public ProductTest(int pid, String pname, double pricetype) {
		
		super();
		this.pid = pid;
		this.pname = pname;
		this.pricetype = pricetype;
		
	}
	
	@Before
	public void initialize() throws InvalidPriceException
	{
		productobj=new Product(pid,pname,100);
		productobj1=new Product(pid,pname,50);
	}
	


	@Parameters
	public static Collection inputdata()
	{
	   
		return Arrays.asList(
				
				new Object[][]
						{
					{12,"Tapasya",100},
						}
				
				
				);
		}

   @Test//1 To test whether getter is proper for all properties
   public void testProductParametersNotNull()
   {
	   Assertions.assertEquals(pid, productobj.getProductId(), Message02);
	   Assertions.assertEquals(pname, productobj.getProductName(), Message02);
	   Assertions.assertEquals(pricetype, productobj.getPrice(), Message02);
   }
   
   @Test//2	To test price<0 throws exception
   public void ifPriceisLessThanZeroThenThrowsException()
   {
	   
		
		Exception exceptionobj=Assertions.assertThrows(InvalidPriceException.class,
				()-> new Product(pid,pname,-1));
		
	    Assertions.assertEquals("Product price should be greater than zero", exceptionobj.getMessage());

   }
   @Test//3	To test property productname setter is set.
   public void whenProductObjectSetProductNameThenPropertyChanges()
   {
	   productobj.setProductName("Bag");
	   Assertions.assertEquals("Bag", productobj.getProductName(),Message01);

   }
   
   @Test//4	To check whether productdetails toString format is proper.
   public void validProductDetailswithToStringFormat() throws InvalidPriceException
   
   {
	   String message = "Product{" +
               "productId=" + productobj.getProductId() +
               ", productName=" + productobj.getProductName() +
               ", price=" + productobj.getPrice() +
               "}";
	   Assertions.assertEquals(message, productobj.toString());
   }
   
   @Test//5	To test whether compareTo returns proper subtracted integer value.
   public void whetherCompareToProductTestReturnsNotNullButRightSubtractedValue() {
	   int result = productobj.compareTo(productobj1);
	   Assertions.assertEquals(50,result,Message03);
   }
   
}

