package com.stackroute.collections;

public class InvalidPriceException extends Exception {

    public InvalidPriceException(String message) {
        super(message);
    }
}
