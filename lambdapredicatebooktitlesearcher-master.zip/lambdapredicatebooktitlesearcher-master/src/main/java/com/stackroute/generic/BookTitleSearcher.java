package com.stackroute.generic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

/*- In this problem, books has to be searched from the given list of books 

- Should return a matching book list given a list of books and a search string
- Should return a matching book list given a list of books and a Predicate*/

public class BookTitleSearcher {
	//List<String> booksList = new ArrayList<String>();	
	  
	     //Predicate<String> predlist = (list)-> list.contentEquals("Spring");
	   /* Predicate<String> predlist2 = (list)-> list.contains("Spring");
	     
	     Optional<List<String>> searchNameresult = searchBookNames(booksList, predlist2);
	     if(searchNameresult.isPresent())
	     {
	    	 List<String> result = searchNameresult.get();
	     result.forEach(System.out::println);	 
	     }*/
	
Optional<List<String>> getBookList(List<String> booklist,String strobj)
//method that takes List<String> books and String to check whether it is present in the list.
 {
		List<String> booksreturnList = new ArrayList<>();
		//line to check whether string is null, blank, booklist is null or empty. Always use isEmpty and isBlank
		//as last condition to avoid null pointer exception
		if(strobj == null||booklist == null||booklist.isEmpty()||strobj.isBlank()) {
			return Optional.empty();//return optional empty
		}
		else {
		for(String l:booklist) {//for the whole list, checked to see if contains the string passed.
			if(l.contains(strobj))
				booksreturnList.add(l);//adding the string to another list.
			
		}	
		
		Optional<List<String>> bookreturn = Optional.of(booksreturnList);//converting this list to an optionaltype.
		System.out.println("Reading the list from getBooklist..");
		return bookreturn;//returning this optional list.
		//to check if this optional list is null - returning false, then return optional.empty().
		//if(bookreturn.isPresent()) {
			
			/*List<String> result = bookreturn.get();
		     result.forEach(System.out::println);*/
		//return bookreturn;//returning this optional list.
	/*	}else
			System.out.println("empty optional list from getBooklist..");
		return Optional.empty();
		
			*/ 			
		}
 }
	
 Optional<List<String>> searchBookNames(List<String> searchlist,Predicate<String> predbookobj2)
 {
		List<String> searchListreturn = new ArrayList<>();
		//checking if predicate object or list is empty or null
		if(searchlist==null||predbookobj2==null||searchlist.isEmpty()) {
			return Optional.empty();
		}	
		else {
		for(String l:searchlist) {
			if(predbookobj2.test(l))//checking if the predicate condition is there in the list passed
				searchListreturn.add(l);// add this to a new list.
			
		}
		Optional<List<String>> bookreturnsearch = Optional.of(searchListreturn);//convert to an optional list.
		System.out.println("Reading the list from searchBookNames..");
		return bookreturnsearch;//return this optional list.
			/*if(bookreturnsearch.isPresent()) {
				System.out.println("Reading the list from searchBookNames..");
				List<String> result = bookreturnsearch.get();
			     result.forEach(System.out::println);*/
				//return bookreturnsearch;
			/*
			 * }else System.out.println("empty optional list from searchBookNames..");
			 * return Optional.empty();
			 */
			}

}
}
 

