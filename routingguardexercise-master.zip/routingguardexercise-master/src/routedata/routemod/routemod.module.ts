import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes} from '@angular/router';
import { HomeComponent } from 'src/app/home/home.component';
import { LoginComponent } from 'src/app/login/login.component';
import { DashboardComponent } from 'src/app/dashboard/dashboard.component';
import { CanactivateustGuard } from 'src/app/canactivateust.guard';
import { UserviewComponent } from 'src/app/userview/userview.component';
import { ClientviewComponent } from 'src/app/clientview/clientview.component';

const myroute: Routes =[
  {
    path:'home',
    component:HomeComponent
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'dash',
    component:DashboardComponent,
    //only because this CanActivatemethod with guard on this component, it will check before loading
    //this page.
    canActivate:[CanactivateustGuard],
    children:[
        {
          path:'userview',
          component:UserviewComponent
        },
        {
          path:'clientview',
          component:ClientviewComponent
        }
    ]
  },
  {
    path:'',
    redirectTo:'/home',
    pathMatch:'full'
  },
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule,
    RouterModule.forRoot(myroute)
   
  ],
  exports: [RouterModule]
})
export class RoutemodModule { }
