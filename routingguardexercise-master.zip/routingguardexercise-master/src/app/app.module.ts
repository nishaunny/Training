import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserviewComponent } from './userview/userview.component';
import { ClientviewComponent } from './clientview/clientview.component';

import {MatButtonModule} from '@angular/material/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RoutemodModule } from 'src/routedata/routemod/routemod.module';
import { CanactivateustGuard } from './canactivateust.guard';
/* const myroute: Routes =[
  {
    path:'home',
    component:HomeComponent
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'dash',
    component:DashboardComponent,
    canActivate:[CanactivateustGuard],
    children:[
        {
          path:'userview',
          component:UserviewComponent
        },
        {
          path:'clientview',
          component:ClientviewComponent
        }
    ]
  },
  {
    path:'',
    redirectTo:'/home',
    pathMatch:'full'
  },
] */

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    LoginComponent,
    DashboardComponent,
    UserviewComponent,
    ClientviewComponent

  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatButtonModule,
    RoutemodModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

//Appmodule- routing part is copied and used in a userdefined module as RoutemodModule.