import { Component, OnInit } from '@angular/core';
import { MyrouteService } from '../myroute.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private serobj: MyrouteService) { }

  ngOnInit(): void {
  }

  showDash(uname:string, pwd:string){

    sessionStorage.setItem("ustuser",uname);
    sessionStorage.setItem("password",pwd)

    this.serobj.openDash();
  }

}
