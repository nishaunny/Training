
  //Print first 10 even number in the given n
  //Assume n=20
  for(i=1; i<=20; i++){
    // let's divide the value by 2
    // if the remainder is zero then it's an even number
   
    if(i % 2 == 0){
      console.log("Even number------>" + i);
    }
  }