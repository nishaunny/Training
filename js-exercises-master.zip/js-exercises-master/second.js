//Two seperate functions
/* funUnitrate(unit)
	if the unit goes above 100 , then print rate as 15 percent
      else rate is 10 per unit
funCalcuamount(unit,rate)
checks the unit rate and multiply the same with unit
Call these functions by passing some values */
let fun1 = function funUnitrate(unit)
{
     if(unit>100)
     return "Rate is 15%";
     else
     return "Rate is 10%";
 }
	
//console.log(fun1(900));
 
 function funCalcuamount(unit,rate){

    let ans=fun1(unit);
    console.log(ans);
    
    return"The calculated rate:" + (unit*rate);
    
 }

 console.log(funCalcuamount(110,25));
			