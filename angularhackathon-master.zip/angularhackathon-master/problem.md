### In continuation with the Organic world case study , develop secured applications for customer cart handling process

#### Broader task are

* Login

* authenticated user can view cart

* Authenticated user can add more item to cart

* Authenticated user can delete the item from cart

### Use the below components

* Login - with reactive form , to get JWT token

* Dashboard protected by CanActivateGuard , using token

* Dashboard further classified into  Carttaker component and cartview component

* Carttaker , use mat expansion panel to store item into db.json

* cartview component , displays all the items using Cartitem component

* Delete button in Cartitem component to remove item

#### Build Route and Services based on requirement

##### Format of db.json


  items {
        
            id :10,
            
            name :"",
        
            price:0
    }


#### Use Authentication server for JWT token













