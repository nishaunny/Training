import { Component, OnInit } from '@angular/core';
import { CartprocessService } from 'services/cartprocess.service';
import { Items } from 'src/items';

@Component({
  selector: 'app-cartview',
  templateUrl: './cartview.component.html',
  styleUrls: ['./cartview.component.css']
})
export class CartviewComponent implements OnInit {

  productsarray: Array<Items>=[];
  constructor(private cartprocess: CartprocessService) { }

  ngOnInit(): void {
    this.viewItems();
  }

  viewItems(){
    this.cartprocess.getItems().subscribe(
      res=> this.productsarray=res
      )
  }

}
