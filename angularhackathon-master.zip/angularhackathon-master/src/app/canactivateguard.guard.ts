import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthorizeService } from 'services/authorize.service';
import { RoutingService } from 'services/routing.service';

@Injectable({
  providedIn: 'root'
})
export class CanactivateguardGuard implements CanActivate {

  constructor(private authorizeservice:AuthorizeService,private routingserv: RoutingService){}
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot):
     Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    
      let output=this.authorizeservice.validateToken();
  
  return output
  .then
  (

    (res)=>
      {
        if(!res)
          
          { 
            this.routingserv.openLogin();
           return false;
          }
           else
           return true;
      }
  )

  .catch()

  
  

}
  }
  

