import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarttakerComponent } from './carttaker.component';

describe('CarttakerComponent', () => {
  let component: CarttakerComponent;
  let fixture: ComponentFixture<CarttakerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CarttakerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CarttakerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
