import { Component, OnInit } from '@angular/core';
import { CartprocessService } from 'services/cartprocess.service';
import { Items } from 'src/items';

@Component({
  selector: 'app-carttaker',
  templateUrl: './carttaker.component.html',
  styleUrls: ['./carttaker.component.css']
})
export class CarttakerComponent implements OnInit {

  errMessage:string="";
  Itemsproduct: Items;

  constructor(private cartprocess: CartprocessService) { 
    this.Itemsproduct= new Items();
  }

  ngOnInit(): void {

  }

  addItem(){

    this.cartprocess.addProductItem(this.Itemsproduct).subscribe((res)=>console.log(res),
    (error)=>{this.errMessage=error.message});

  }

}
