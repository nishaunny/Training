import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthorizeService } from 'services/authorize.service';
import { RoutingService } from 'services/routing.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user:FormGroup;

  constructor(private routerservice:RoutingService, private authorizeservice: AuthorizeService) {

    this.user=new FormGroup({
      username: new FormControl('',Validators.required),
      password: new FormControl('',Validators.minLength(5)),
      });
   }

  ngOnInit(): void {
  }

  signIn(){

    this.authorizeservice.connectToserver(this.user.value).subscribe(
      (res)=> {
        this.authorizeservice.storeToken(res['token']);
        this.routerservice.openDashboard();
      }
    )

  }

}
