import { Component, Input, OnInit } from '@angular/core';
import { CartprocessService } from 'services/cartprocess.service';
import { Items } from 'src/items';

@Component({
  selector: 'app-cartitem',
  templateUrl: './cartitem.component.html',
  styleUrls: ['./cartitem.component.css']
})
export class CartitemComponent implements OnInit {

  @Input()
  productobj : Items= new Items();

  constructor(private cartprocess: CartprocessService) { }

  ngOnInit(): void {
  }

  delete()
  {

    this.cartprocess.deleteProductItem(this.productobj.id).subscribe
    (
      res=>console.log("deleted")
     

    );
   // window.location.reload();


  }
}
