export class Items{

    id:number =0;
    name:string ="";
    price:number=0

    constructor(){}
}