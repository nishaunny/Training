import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Items } from 'src/items';
import { AuthorizeService } from './authorize.service';

@Injectable({
  providedIn: 'root'
})
export class CartprocessService {

  itemsarray : Array<Items>=[];
  itemssubject: BehaviorSubject<Array<Items>>;

  constructor(private httpcli: HttpClient, private authorizeservice: AuthorizeService) { 
    this.itemssubject=new BehaviorSubject<Array<Items>>([]);
  }

  fetchDatafromserver(){

    let tok=this.authorizeservice.getToken();
    return this.httpcli.get<Array<Items>>('http://localhost:3000/api/v1/items',
    {
     headers: new HttpHeaders().set('Authorization',`Bearer ${tok}`)
   }
   ).subscribe(

    (res)=>{
            this.itemsarray=res;
            this.itemssubject?.next(this.itemsarray);
    },

    (err)=>
       this.itemssubject?.error(err)
   )
  }

  addProductItem(itemobj : Items) : Observable<Items>
  {
    let tok=this.authorizeservice.getToken();

  return  this.httpcli.post<Items>('http://localhost:3000/api/v1/items',itemobj,
  {
    headers: new HttpHeaders().set('Authorization',`Bearer ${tok}`)
  }
  ).
  pipe(

     tap( (objitems:Items) =>
      {
        this.itemsarray.push(objitems);
        this.itemssubject.next(this.itemsarray);
      //  return this.productsubject
      }
  )
  );
  }

  getItems() : BehaviorSubject<Array<Items>>
  {
  return this.itemssubject; 
  }
  
   deleteProductItem(id : any)
   {
    let tok=this.authorizeservice.getToken();

    return  this.httpcli.delete(`http://localhost:3000/api/v1/items/${id}`,
    {
      headers: new HttpHeaders().set('Authorization',`Bearer ${tok}`)
    }
    ).pipe(
      tap(()=>
      {
       const ind=this.itemsarray.findIndex( product=>product.id==id);
       this.itemsarray.splice(ind,1);
    this.itemssubject.next(this.itemsarray);    
      }
      )
    );
   }
}
