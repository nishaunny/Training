import { TestBed } from '@angular/core/testing';

import { CartprocessService } from './cartprocess.service';

describe('CartprocessService', () => {
  let service: CartprocessService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CartprocessService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
