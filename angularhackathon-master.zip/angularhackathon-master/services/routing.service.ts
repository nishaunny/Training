import { Location } from '@angular/common';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class RoutingService {

  constructor(private router: Router, private location:Location) { }

  openLogin(){

    this.router.navigate(['login']);
  }

  openDashboard(){

    this.router.navigate(['dashboard']);
  }

  openCartView(){
    this.router.navigate(['dashboard/view/cart']);
  }
  routetoback()
  {
    this.location.back();
  }
}
