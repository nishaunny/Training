
//Two arrays -marks and names
let marks =[60, 20, 56,10,50];

let names =["ravi","raju","balu","amirtha","reshma"];
// Funpass function
let funpass = function (fun, mark){
    console.log("The result is---------->");
    console.log(fun(mark));
}
funpass(function(mark)
{
    if(mark>35)
    return "passed";
    else
    return "failed";
},40);


// Funpass function -second way using lambda
function funpassing(mark){
    let answer = marks.filter((m)=>m>35)
    answer.forEach(m=>console.log("Passed as above score 35...> " +m))
}

funpassing(marks); 
//Using lambda
let markstotal = (ma)=>{
    if(ma>35)
    return "Passed as above 35";
    else
    return "Failed."
}

console.log("Using lambda.....>" +markstotal(50));

// touppercase using map
let uppernamelist = names.map((n)=>n.toUpperCase());
uppernamelist.forEach((name)=>console.log(name));

// marks above 50 using filter
let abovefifty = marks.filter((m)=>m>50);

abovefifty.forEach((mar)=>console.log(mar));

//total count of students who scored above 50
console.log("Total students who scored over 50: "+abovefifty.length);


//Reduce operation
let answerofcount = marks.filter((m)=>m>50).reduce( (cont, num)=>{
   cont=cont+1;
   return cont;
},0);

console.log(answerofcount);

//reduce function takes accumulator, currentvalue of array - adds it, this way can sum all elements of array
// If initialValue is not provided, reduce() will execute the callback function starting at index 1, skipping the first index. If initialValue is provided, it will start at index 0.
let total = marks.reduce((accu,value)=>{console.log(accu);return accu+value;},0)
//marks.reduce((acc,value)=>acc+value)-it starts adding from 0th index, acc=0,value=60
console.log("Total of marks---->"+total)

//Funtest function

function funTest(name){

    return "Welcome " +name;
}

console.log(funTest("Nancy"));

//Funtest method 2
let funTest2 = (n)=> console.log("FunTest2--->Welcome..."+n);

funTest2("Nina");

//using funTest to print names array with similar output.
names.forEach((m)=>funTest2(m));

//Funtest in a different way using prototype
let funTest3 = function(f1, name){
    console.log(f1(name));
}

funTest3(function(nam)
{
    return "FunTest3-->Welcome...." +nam;
}, "NancyD");