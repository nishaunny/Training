# Complete the following functionalities using fetch API


### Design user registration page , as per the format in uidesign.png

#### Complete the following activities

* Store the User data in user.json when the user click on Sign in Button

* Display the data using table   format when user clicks View All button

* Delete the user , by using delete button. 


Use the boilerplate structure


* --- jscript -> script file

* --- serverdata -> user.json file

* --- styles -> css file


##### Complete the process and share the gitlink. Inform mentor for manual evaluation