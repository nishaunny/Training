//initialize array to store the json data into an array, later use this to disply as a table.
var arr=[];
//get the data from the json file and store in an array. Display is called to display this as a table in section.
function showData()
{
// event.preventDefault();
fetch("http://localhost:3000/user",{"method":"Get"})
                    .then(
                            (res)=>
                            {
                                if(res.ok)
                                {
                                    console.log("first connect");
                                    console.log(res);
                                    return res.json();
                                    
                                }
                                else
                                console.log("some error");
                            }
                    )
                    .then
                    (
                        (out)=>
                        {
                            console.log("further process");
                            console.log(out);
                            arr=out;
                            display();
                        }
                    )

                    .catch(
                        (err)=>
                        console.log("some error")
                    )

}

showData(); //calling the get and load data
//after adding the data, display is called to put the added data in the table.
function dataAdd(){

    event.preventDefault();
    console.log("add clicked");

    let sid=myform.id.value;
    let sname=myform.username.value;
    let add=myform.address.value;
    let password = myform.pass.value;

    let mydata={
                "id": sid,
                "name": sname,
                "address": add,
                "password":password
    };
    console.log(mydata);
    ///alert(mydata);
fetch("http://localhost:3000/user",
{
    "method":"post",
    "headers":{"content-type":"application/json"},
    body:JSON.stringify(mydata)//converts javascript value to json data.
}
).then(
    (res)=>
    {
        if(res.ok)
        {
            
            // alert(res.statusText);
            console.log("Response read successful.....>"+res.text)
            res.preventDefault();
        arr.push(mydata);
        //console.log(arr);
        display();
        }
    }
)
.catch(err=>console.log(err))


}
//to display the stored arr as a table in section.
function display()
{
    event.preventDefault();
    let myoutput="<table border=3 class=bg-white><tr class=bg-secondary><td>Id</td><td>Name</td><td>Address</td><td>Password</td><td>Edit?</td></tr>";

arr.forEach(
               (record)=>
                {
                    myoutput+="<tr>";
 myoutput+="<td>"+record.id+"</td>"+"<td>"+record.name+"</td>"
 +"<td>"+ record.address+"</td>" +"<td>"+record.password+"</td>"
 + "<td> <button class=btn-outline-success onclick=deleteFun('" + record.id + "')>Delete</button></td>" ;
                    myoutput+="</tr>"
               }
 )   
    myoutput+="</table>";
document.getElementById("paraonedisplay").innerHTML=myoutput;
}
//to delete a data using delete method
function deleteFun(sid)
{
    event.preventDefault();
    //alert( sid);
   // console.log(`http://localhost:3000/user/${sid}`);

    fetch("http://localhost:3000/user/"+sid,{"method":"DELETE"})
    .then(
        (res)=>console.log("Record deleted"+sid)
            
    )
    .catch(
        (err)=>console.log("error")
        )

}
