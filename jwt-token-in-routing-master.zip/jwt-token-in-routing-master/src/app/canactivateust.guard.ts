import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthenticateserviceService } from './authenticateservice.service';
import { MyrouteService } from './myroute.service';

@Injectable({
  providedIn: 'root'
})
export class CanactivateustGuard implements CanActivate {

  constructor(private servobj: MyrouteService, private authserv: AuthenticateserviceService){}
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): 
    Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
//Can activate this interface takes the session storage credentials and does validation
//returning false, it stops from dashboard page and redirects to Login page.
//when true, shows the dashboard page
      let user=sessionStorage.getItem("user");
      let pwd=sessionStorage.getItem("pwd");
      //condition to check for the guard to apply, if it's equal to admin, pass@123, access the dashboard
      
      if((user!="admin")||(pwd!="password"))
      {
        this.servobj.openLogin();
        return false;
      }

    this.authserv.validateToken().subscribe((res)=>console.log(res))
    return true;
  }
  
}
