import { TestBed } from '@angular/core/testing';

import { CanactivateustGuard } from './canactivateust.guard';

describe('CanactivateustGuard', () => {
  let guard: CanactivateustGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(CanactivateustGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
