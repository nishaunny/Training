import { Component, OnInit } from '@angular/core';
import { Comments } from 'src/comments';
import { GetpostserviceService } from '../getpostservice.service';
import { MyrouteService } from '../myroute.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  comment: Comments;
  commarray: Array<Comments>=[];
  errMessage :string ="";
  constructor(private servobj: MyrouteService, private dataop: GetpostserviceService) { 

    this.comment = new Comments();
  }

  ngOnInit(): void {

    this.viewcomments();
  }

  userview()
  {
    this.servobj.openUserview();
  }
  clientview()
  {
    this.servobj.openClientview();
  }

  logout(){
    sessionStorage.clear();
  }

  viewcomments(){

    this.dataop.getdata().subscribe(res=>this.commarray=res,
      (error)=>this.errMessage=error.message);
  }

  addComm(){

    this.dataop.adddata(this.comment).subscribe((res)=>this.commarray.push(this.comment),
    (error)=>this.errMessage=error.message);
  }
}
