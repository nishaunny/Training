import { TestBed } from '@angular/core/testing';

import { GetpostserviceService } from './getpostservice.service';

describe('GetpostserviceService', () => {
  let service: GetpostserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetpostserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
