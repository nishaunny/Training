import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Comments } from 'src/comments';
@Injectable({
  providedIn: 'root'
})
export class GetpostserviceService {
  
  constructor(private httpcli: HttpClient) { }


  getdata(): Observable<Array<Comments>> 
  {

    return this.httpcli.get<Array<Comments>>("http://localhost:3000/api/v1/comments");
  }

  adddata(comm: Comments): Observable<Comments> 
  {

    return this.httpcli.post<Comments>("http://localhost:3000/api/v1/comments", comm);
  }
}
