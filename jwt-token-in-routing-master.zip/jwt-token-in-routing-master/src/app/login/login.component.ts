import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { User } from 'src/user';
import { AuthenticateserviceService } from '../authenticateservice.service';
import { MyrouteService } from '../myroute.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  //userobj: User;

  
  constructor(private serobj: MyrouteService, private authser:AuthenticateserviceService) {
    // for the earlier RouteSample acivity.
    //this.userobj= new User();
    this.user=new FormGroup({
      username: new FormControl('',Validators.required),
      password: new FormControl('',Validators.minLength(5)),
    }); 
   }

  ngOnInit(): void {
    
  }

  /* showDash(uname:string, pwd:string){

    sessionStorage.setItem("ustuser",uname);
    sessionStorage.setItem("password",pwd)

    this.serobj.openDash();
  } */

  signIn(username:string, pass:string){

    sessionStorage.setItem("user",username);
    sessionStorage.setItem("pwd", pass);


    this.authser.connectToServer(this.user.value).subscribe(
      
      (res)=>{
    this.authser.storeToken(res["token"]);
    this.serobj.openDash();
  }
    )

  }
}
