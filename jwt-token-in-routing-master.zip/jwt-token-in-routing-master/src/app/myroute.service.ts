import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class MyrouteService {

  constructor(private routobj: Router) { 

  }

  openLogin(){
   this.routobj.navigate(['login']);
  }
  openHome(){
    this.routobj.navigate(['home']);
   }
   openDash(){
    this.routobj.navigate(['dash']);
   }
   //children of dashboard, so the path is a little different parentlabel/childlabel
   openUserview(){
    this.routobj.navigate(['dash/userview']);
   }
   openClientview(){
    this.routobj.navigate(['dash/clientview']);
   }

   addComment(){

   }

   viewComment(){
     
   }
}
