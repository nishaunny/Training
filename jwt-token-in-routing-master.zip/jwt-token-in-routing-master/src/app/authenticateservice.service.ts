import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Comments } from 'src/comments';

@Injectable({
  providedIn: 'root'
})
export class AuthenticateserviceService {
  
  
  constructor(private httpcli: HttpClient) 
  
  { }

  connectToServer(data:any):Observable<any>
  {
    console.log(data);
    return this.httpcli.post("http://localhost:3000/auth/v1",data);
  
  }

  storeToken(tok:any){

    sessionStorage.setItem("mytoken",tok);

  }

  getToken():any {

    sessionStorage.getItem("mytoken");

  }

  validateToken(){

    let tokenreceived = this.getToken();

    return this.httpcli.post(`http://localhost:3000/auth/v1/isAuthenticated`,[],
    {
      headers: new HttpHeaders().set('Authorization',`Bearer ${tokenreceived}`)
    } );

  }

  
}
