export class Comments{

    id: number=0;
    title: string ="";
    descri: string="";

    constructor(){}
}