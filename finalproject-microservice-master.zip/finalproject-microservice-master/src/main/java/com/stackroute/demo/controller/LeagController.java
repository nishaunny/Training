package com.stackroute.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stackroute.demo.exception.LeagueAlreadyExistsException;
import com.stackroute.demo.model.LeagueInfo;
import com.stackroute.demo.service.LeagueService;

@CrossOrigin("*")
@RestController
@RequestMapping("sportsleague/app")
public class LeagController {
	

	@Autowired
	LeagueService service;

	@CrossOrigin("*")
	@PostMapping("/api/League/addLeagueinfo")
    public ResponseEntity<String> addLeaguedata(@RequestBody LeagueInfo information){
        try {
            if( service.addLeagueDetails(information)) {
            return new ResponseEntity<String>("League added", HttpStatus.CREATED);
            }
        } catch (LeagueAlreadyExistsException ex) {
            return new ResponseEntity<String>(ex.getMessage(), HttpStatus.CONFLICT);
        }
        return new ResponseEntity<>(HttpStatus.CONFLICT);
    }
	//@GetMapping("/viewLeague") - view only for the registered users.

}
