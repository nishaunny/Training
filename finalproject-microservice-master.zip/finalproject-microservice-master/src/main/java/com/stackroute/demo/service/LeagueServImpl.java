package com.stackroute.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.demo.exception.LeagueAlreadyExistsException;

import com.stackroute.demo.model.LeagueInfo;
import com.stackroute.demo.model.User;
import com.stackroute.demo.repository.leaguerepo;

@Service
public class LeagueServImpl implements LeagueService{
	
	@Autowired
	leaguerepo Leaguerepos;

	@Override
    public boolean addLeagueDetails(LeagueInfo leagueinfo) throws LeagueAlreadyExistsException {

 

        /* checking and getting user object */
        Optional<User> userExist = Leaguerepos.findById(leagueinfo.getUserName());
        if (userExist.isPresent()) {

 

            /* getting count on league exists or not */
            long leagueCount = userExist.get().getLeagues().stream()
                    .filter(league -> league.getTeamName().equalsIgnoreCase(leagueinfo.getTeamName())).count();

 

            /* add leagueinfo to existing list if count is 0 */
            if (leagueCount == 0) {
                userExist.get().getLeagues().add(leagueinfo);
                Leaguerepos.save(userExist.get());
                return true;
            } else {
                throw new LeagueAlreadyExistsException("Already exists");
            }
        }
        List<LeagueInfo> leagueList= new ArrayList<>();
        leagueList.add(leagueinfo);
        User user= new User();
        user.setUserName(leagueinfo.getUserName());
        user.setLeagues(leagueList);
        if(Leaguerepos.save(user)!=null) {
            return true;
        }
        return false;
//        throw new UserNotFoundException("User" + favourite.getUserName() + "doesn't exists");
    }
	

}
