package com.stackroute.lamdbaexpression;

import java.util.ArrayList;

import java.util.List;
import java.util.ListIterator;
import java.util.function.Predicate;

public class PredicateFunctionalInterface{
	//new list to add the I starting strings.
 	List<String> addedlist = new ArrayList<>();
    //write logic to find the values that starts with letter I in the given list
    public List<String> findPattern(List<String> list)  {
   
    	 //Testing whether the newlist contains words with "I".	
    	Predicate<String> predobj = (addedlist)-> addedlist.contains("I");
 		
    	if(list==null)
    		return null;//if input string null, return null.
    	else{
    		for(String s:list) {
    			//if predicate condition is true and the (new) addedlist does not contain a string already to avoid duplicates.
    			if(predobj.test(s)&&!addedlist.contains(s)) 
    				addedlist.add(s);
    			addedlist.forEach(System.out::println);
    		}
    			return addedlist; //return the new addedlist.
    		  
    }
    

     }
}
