package com.stackroute.oops;

public class ProductLineItem {

    /* Define the properties as given in problem.md */


    /*
       Complete the Parameterized constructor to initialize all properties of Author
    */
         private int id;
         private int quantity;
         private Product product;
         //Private id, quantity and product is declared.
    public ProductLineItem(int id, int quantity, Product product) {
    	this.id = id;
    	this.quantity = quantity;
    	this.product = product;
    }


    /*
        Complete the Getters and Setters
    */
    //get and set the values for the private attributes.
    public int getId() {

        return id;
    }

    public void setId(int id) {

            this.id = id;
    }

    public int getQuantity() {

        return quantity;
    }

    public void setQuantity(int quantity) {

           this.quantity = quantity;
    }

    public Product getProduct() {

        return product;
    }

    public void setProduct(Product product) {

               this.product = product;
    }

    /*
        This method should return a string containing the ProductLineItem details in below format
            ProductLineItem{id=xx,quantity='xxxxx', description='xxxx',Product{id=x, name='xxx', description='xxxxx'}}
     */
    public String getItemDetails() {
        return "productLineItem{id="+getId()+","+"quantity="+getQuantity()+","+"product="+product.getProductDetails()+"}";    
}
}
