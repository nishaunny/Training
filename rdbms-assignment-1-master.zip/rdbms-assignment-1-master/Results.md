Execute:
> Select * from UserProfile where CreatedAt between '20-02-2019' and current_date()

+ ----------- + -------------- + ------------- + ------------ + ---------- + -------------- +
| UserId      | FirstName      | LastName      | Contact      | Email      | CreatedAt      |
+ ----------- + -------------- + ------------- + ------------ + ---------- + -------------- +
| Jack        | Jackson        | James         | 889977665    | jack@yahoomail.com | 2021-06-21 18:34:38.000000 |
| John        | Johnson        | Dzousa        | 9192939495   | john@yahoomail.com | 2021-06-21 18:36:29.000000 |
| Kevin       | Kevin          | Lyloyd        | 87756789625  | kevin@yahoomail.com | 2021-06-21 18:37:24.000000 |
+ ----------- + -------------- + ------------- + ------------ + ---------- + -------------- +
3 rows

Execute:
> Select * from News where CreatedBy='Jack'

+ ----------- + ---------- + ------------ + ---------------- + -------------- + -------- + --------------- +
| NewsId      | Title      | Content      | PublishedAt      | CreatedBy      | URL      | UrlToImage      |
+ ----------- + ---------- + ------------ + ---------------- + -------------- + -------- + --------------- +
| 101         | IT industry growth can be seen in 2020 | IT industry was facing disruptive changes in 2019.It is expected to have positive growth in 2020. | 2021-06-22 01:21:09.000000 | Jack           |          |                 |
| 102         | 2020 FIFA U17 Women World Cup | The tournamment will be held in India between 2 and 20Nov... | 2021-06-22 01:22:47.000000 | Jack           |          |                 |
| NULL        | NULL       | NULL         | NULL             | NULL           | NULL     | NULL            |
+ ----------- + ---------- + ------------ + ---------------- + -------------- + -------- + --------------- +
3 rows

Execute:
> Select * from User, News D where UserId=D.CreatedBy and NewsId=103

+ ----------- + ------------- + ----------- + ---------- + ------------ + ---------------- + -------------- + -------- + --------------- +
| UserId      | Password      | NewsId      | Title      | Content      | PublishedAt      | CreatedBy      | URL      | UrlToImage      |
+ ----------- + ------------- + ----------- + ---------- + ------------ + ---------------- + -------------- + -------- + --------------- +
| John        | something#121 | 103         | Chadrayananspacera2-ft | The Lander of Chandrayaan 2 was named.... | 2021-06-22 01:23:45.000000 | John           |          |                 |
+ ----------- + ------------- + ----------- + ---------- + ------------ + ---------------- + -------------- + -------- + --------------- +
1 rows

Execute:
> Select UserId, Content from User, News D where UserId=D.CreatedBy

+ ----------- + ------------ +
| UserId      | Content      |
+ ----------- + ------------ +
| Jack        | IT industry was facing disruptive changes in 2019.It is expected to have positive growth in 2020. |
| Jack        | The tournamment will be held in India between 2 and 20Nov... |
| John        | The Lander of Chandrayaan 2 was named.... |
| John        | Bank customers..... |
+ ----------- + ------------ +
4 rows

Execute:
> Select Title,ReminderId from News,Reminders where News.NewsId=Reminders.NewsId

+ ---------- + --------------- +
| Title      | ReminderId      |
+ ---------- + --------------- +
| IT industry growth can be seen in 2020 | 1               |
| 2020 FIFA U17 Women World Cup | 2               |
| Chadrayananspacera2-ft | 4               |
| NEFT transactions to be available 24x7 | 3               |
+ ---------- + --------------- +
4 rows

Execute:
> Select Createdby, Count(*) from News group by Createdby

+ -------------- + ------------- +
| Createdby      | Count(*)      |
+ -------------- + ------------- +
| Jack           | 2             |
| John           | 2             |
+ -------------- + ------------- +
2 rows

update UserProfile set Contact='9192939495' where UserId='John';
Select * from UserProfile;

Execute:
> Select * from UserProfile

+ ----------- + -------------- + ------------- + ------------ + ---------- + -------------- +
| UserId      | FirstName      | LastName      | Contact      | Email      | CreatedAt      |
+ ----------- + -------------- + ------------- + ------------ + ---------- + -------------- +
| Jack        | Jackson        | James         | 889977665    | jack@yahoomail.com | 2021-06-21 18:34:38.000000 |
| John        | Johnson        | Dzousa        | 9192939495   | john@yahoomail.com | 2021-06-21 18:36:29.000000 |
| Kevin       | Kevin          | Lyloyd        | 87756789625  | kevin@yahoomail.com | 2021-06-21 18:37:24.000000 |
+ ----------- + -------------- + ------------- + ------------ + ---------- + -------------- +
3 rows
Execute:
> Select * from Reminders

+ --------------- + ------------- + ----------- +
| ReminderId      | Schedule      | NewsId      |
+ --------------- + ------------- + ----------- +
| 1               | 2021-06-22 01:28:54.000000 | 101         |
| 2               | 2021-06-22 01:29:16.000000 | 102         |
| 3               | 2021-06-22 01:29:28.000000 | 104         |
| 4               | 2021-06-22 17:19:25.000000 | 103         |
+ --------------- + ------------- + ----------- +
4 rows
Execute:
> select * from News

+ ----------- + ---------- + ------------ + ---------------- + -------------- + -------- + --------------- +
| NewsId      | Title      | Content      | PublishedAt      | CreatedBy      | URL      | UrlToImage      |
+ ----------- + ---------- + ------------ + ---------------- + -------------- + -------- + --------------- +
| 101         | IT industry growth can be seen in 2020 | IT industry was facing disruptive changes in 2019.It is expected to have positive growth in 2020. | 2021-06-22 01:21:09.000000 | Jack           |          |                 |
| 102         | 2020 FIFA U17 Women World Cup | The tournamment will be held in India between 2 and 20Nov... | 2021-06-22 01:22:47.000000 | Jack           |          |                 |
| 103         | Chadrayananspacera2-ft | The Lander of Chandrayaan 2 was named.... | 2021-06-22 01:23:45.000000 | John           |          |                 |
| 104         | NEFT transactions to be available 24x7 | Bank customers..... | 2021-06-22 01:24:36.000000 | John           |          |                 |
| NULL        | NULL       | NULL         | NULL             | NULL           | NULL     | NULL            |
+ ----------- + ---------- + ------------ + ---------------- + -------------- + -------- + --------------- +
5 rows

Execute:
> Select * from User

+ ----------- + ------------- +
| UserId      | Password      |
+ ----------- + ------------- +
| Jack        | pass@123      |
| John        | something#121 |
| Kevin       | test@123      |
| NULL        | NULL          |
+ ----------- + ------------- +
4 rows
