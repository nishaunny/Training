
-- Please refer Results.MD for the queries result----
create database Sample
USE Sample
SELECT database()
Create Table User(
`UserId` nvarchar(50) Not Null,
`Password` nvarchar(50) Not Null,
Primary Key(`UserId`))
Drop table User


Insert into User(UserId, Password)
Values('Jack','pass@123');
Insert into User(UserId, Password)
Values('John','something#121');
Insert into User(UserId, Password)
Values('Kevin','test@123');

Select * from User

create table UserProfile(
`UserId` nvarchar(50) Not Null,
`FirstName` nvarchar(50) Not Null,
`LastName` nvarchar(50) Not Null,
`Contact` nvarchar(100),
`Email` nvarchar(100),
`CreatedAt` datetime(6),
Foreign Key (`UserId`) References User(`UserId`));


Insert into UserProfile(UserId, FirstName, LastName, Contact, Email,CreatedAt)
Values('Jack', 'Johnson','James',889977665,'jack@yahoomail.com', current_timestamp());

Insert into UserProfile(UserId, FirstName, LastName, Contact, Email,CreatedAt)
Values('John', 'Johnson','Dzousa',890345678,'john@yahoomail.com', current_timestamp());

Insert into UserProfile(UserId, FirstName, LastName, Contact, Email,CreatedAt)
Values('Kevin', 'Kevin','Lyloyd',87756789625,'kevin@yahoomail.com', current_timestamp());

Select * from UserProfile;

Show tables;

Drop Table UserProfile;

Create Table News(
`NewsId` int Not Null,
`Title` nvarchar(100) Not Null,
`Content` nvarchar(100) Not Null,
`PublishedAt` datetime(6) Not Null,
`CreatedBy` nvarchar(50) Not Null,
`URL` nvarchar(100),
`UrlToImage` nvarchar(100),
Primary Key(`NewsId`));

Insert into News(NewsId, Title, Content, PublishedAt, CreatedBy, URL, UrlToImage)
Values(101,'IT..','IT industries.....',current_timestamp(),'Jack', Null, Null);
Insert into News(NewsId, Title, Content, PublishedAt, CreatedBy, URL, UrlToImage)
Values(102,'2020 FiFA','The tournmament was held.....',current_timestamp(),'Jack', Null, Null);
Insert into News(NewsId, Title, Content, PublishedAt, CreatedBy, URL, UrlToImage)
Values(103,'Chandrayananspaceera-2','The Lander of Chandranyaan space era.....',current_timestamp(),'John', Null, Null);
Insert into News(NewsId, Title, Content, PublishedAt, CreatedBy, URL, UrlToImage)
Values(104,'NEFT transactions to be available 24x7','Bank customers.....',current_timestamp(),'John', Null, Null);

Select * from News;

Create Table Reminders(
`ReminderId` int Not Null,
`Schedule` datetime(6) Not Null,
`NewsId` int Not Null,
Foreign Key (`NewsId`) References News(`NewsId`));

Insert into Reminders(ReminderId, Schedule, NewsId)
Values(1, current_timestamp(),101);
Insert into Reminders(ReminderId, Schedule, NewsId)
Values(2, current_timestamp(),102);

Insert into Reminders(ReminderId, Schedule, NewsId)
Values(3, current_timestamp(),104);

Select * from Reminders;


---Used insert into to add records for all 4 tables as per the data attached in this assignment----
-- Queries Answers------


Select * from UserProfile where CreatedAt between '20-02-2019' and current_date();
Select * from News where CreatedBy='Jack';
Select * from User, News D where UserId=D.CreatedBy and NewsId=103;
Select UserId, Content from User, News D where UserId=D.CreatedBy;


Select Title,ReminderId from News,Reminders where News.NewsId=Reminders.NewsId;

Select Createdby, Count(*) from News group by Createdby;




update UserProfile set Contact='9192939495' where UserId='John';


Update News set Title='IT industry growth can be seen in 2020' where NewsId=101;


Delete from Reminders where exists (Select News.CreatedBy from News where News.NewsId=Reminders.NewsId and News.CreatedBy='Jack');

Delete from Reminders where Reminders.NewsId=101;
select * from News;



Insert into Reminders values(4,current_timestamp(),(select NewsId from News where NewsId=103));
