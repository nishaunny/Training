
function displayAll(){

    event.preventDefault();

fetch("http://localhost:3000/hotel", {"method":"Get"})
.then(
    (resp)=>
    {
    if(resp.ok){

        console.log("first connection to the json data");
        console.log(resp);
        return resp.json();
    }
    else
    console.log("some error");
    }
)
.then(
    (data)=>{
        console.log("Json data is fetched..");
        console.log(data);}
)
.catch(

    (err)=>
    console.log("Error occured")
)

}