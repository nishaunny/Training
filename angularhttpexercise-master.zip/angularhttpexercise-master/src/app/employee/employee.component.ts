import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/employee';
import { EmployeeprocessService } from '../employeeprocess.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  empobj: Employee;
  constructor(private empserv: EmployeeprocessService) { 

    this.empobj= new Employee()
  }

  ngOnInit(): void {
  }

  showdetails(){
    this.empserv.showData().subscribe((res)=>console.log(res));
  }

  addUser(){
    this.empserv.addData(this.empobj).subscribe((res)=>console.log(res));
    alert("Nothing to be printed.");
  }
}
