import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from 'src/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeprocessService {

  constructor(private httpcli: HttpClient) {


   }

   showData() : Observable<Array<Employee>>
   {

    return this.httpcli.get<Array<Employee>>("http://localhost:3000/employee");
   }

   addData(empobj: Employee): Observable<Employee>

   {
     return this.httpcli.post<Employee>("http://localhost:3000/employee", empobj);
   }
}
