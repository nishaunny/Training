export class Employee{

    id: number=0;
    empname: string="";
    salary: string="";

    constructor(){}
}