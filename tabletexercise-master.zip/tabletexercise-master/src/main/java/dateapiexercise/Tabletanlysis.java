package dateapiexercise;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/*- Exercise: Create a class Tablet with attributes,tablet name, manufacturer, manufacture date and expiry date(LocalDate). 
- Create a class DateTimeExercise with the following methods and variables
  - create a variable tablets of type ArrayList<Tablet> and initialize with some tablet objects 
  - getExpiringTables(int months):List<String>
    - method should take number of months as parameter and return a List of tablet names expiring within the given months from today.
  -getExpiringTabletsSorted
  	- return a  List of Tablets, in the ascending order of expiry date  	
  - getTabletExpiryPeriod
  	- return a Map with the tablet name as key and the period between the manufacture date and expiry date as value. 
  - getSameYearExpiry
  	- Return a Map with key as manufacturer and value as list of tablet names which are manufactured in the current year and are already expired
*/
public class Tabletanlysis {
	static List<Tablet> tabletlist=new ArrayList<Tablet>();
	public static void main(String[] args) {
// operationsperformed on the tablet class objects using the list, stream api, date period.
		
		
	Tablet tab1 = new Tablet("Crocin", "XYZ",LocalDate.of(1995, 12, 20),LocalDate.of(2020, 10, 12));
	Tablet tab2 = new Tablet("Panadol", "ABC",LocalDate.of(2020, 12, 20),LocalDate.of(2021, 6, 12));
	Tablet tab3 = new Tablet("Panadollike", "ABC Comp",LocalDate.of(1989, 12, 20),LocalDate.of(2019, 8, 12));
	Tablet tab4 = new Tablet("Aline", "ABlolaC",LocalDate.of(1987, 12, 20),LocalDate.of(2020, 9, 3));
	Tablet tab5 = new Tablet("Ellakka", "AB & sons",LocalDate.of(2020, 12, 20),LocalDate.of(2021, 7, 12));
	
	tabletlist = Arrays.asList(tab1,tab2,tab3,tab4,tab5);
	LocalDate today=LocalDate.now();
	 
	getExpiringTablets(3);
	getExpiringTabletsSorted();
	getTabletExpiryPeriod();
	getSameYearExpiry();
	}
	
	
	
//	 - getExpiringTables(int months):List<String>
//	    - method should take number of months as parameter and return a List of tablet names expiring within the given months from today.
	static void getExpiringTablets(int months){
		
		List<String> tablist =tabletlist.stream().filter(tab->Period.between(tab.getExpdate(), LocalDate.now()).getMonths()<(months)).map(tab->tab.getTabletName()).collect(Collectors.toList());
		
				tablist.forEach(System.out::println);
	 }
	
	
	
//	 -	getExpiringTabletsSorted
//	  	- return a  List of Tablets, in the ascending order of expiry date
	static void getExpiringTabletsSorted() {
		List<Tablet> sort =tabletlist.stream().sorted(Comparator.comparing(tab->tab.getExpdate())).collect(Collectors.toList());
		sort.forEach(System.out::println);
	}
	 
	
	
//	  - getTabletExpiryPeriod
//	  	- return a Map with the tablet name as key and the period between the manufacture date and expiry date as value.  	  
	static void getTabletExpiryPeriod() {
	
		Map<String,Period> periodlist = tabletlist.stream().collect(Collectors.toMap(Tablet::getTabletName, tab ->Period.between(tab.getManufactDate(), tab.getExpdate())));
		periodlist.forEach((k,v) -> System.out.println("Tabname  :"+k+" Expiry in : " +v.getMonths()+" months"));
	}
	

	
//	  - getSameYearExpiry
//	  	- Return a Map with key as manufacturer and value as list of tablet names which are manufactured in the current year and are already expired
	static void getSameYearExpiry() {
		Predicate<Tablet> tabpred = tab->tab.getExpdate().isAfter(LocalDate.of(2021,02 , 01)) && tab.getManufactDate().isAfter(LocalDate.of(2020,12 , 01));
		Map<String,List<Tablet>> mapsame = tabletlist.stream().filter(tabpred).collect(Collectors.groupingBy(tab->tab.getManufacturer()));
			mapsame.forEach((k,v)->System.out.println(" Manufacturer  :" +k +" Tabletnames " +v));
}
}