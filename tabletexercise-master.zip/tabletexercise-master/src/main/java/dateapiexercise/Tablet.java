package dateapiexercise;

import java.time.LocalDate;
public class Tablet {
	
	String tabletName,manufacturer;
	LocalDate manufactDate, Expdate;
	
	
	public Tablet(String tabname, String Manufact, LocalDate manudate, LocalDate expdate) {
		
		this.tabletName=tabname;
		this.manufactDate=manudate;
		this.Expdate=expdate;
		this.manufacturer=Manufact;
	}


	public String getTabletName() {
		return tabletName;
	}


	public void setTabletName(String tabletName) {
		this.tabletName = tabletName;
	}


	public String getManufacturer() {
		return manufacturer;
	}


	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}


	public LocalDate getManufactDate() {
		return manufactDate;
	}


	public void setManufactDate(LocalDate manufactDate) {
		this.manufactDate = manufactDate;
	}


	public LocalDate getExpdate() {
		return Expdate;
	}


	public void setExpdate(LocalDate expdate) {
		Expdate = expdate;
	}
	
	 public String toString()
	 {
	  return "TaBname :" + tabletName + " Manufactdate :" + manufactDate + " Manufacturer :" + manufacturer +  " Expirydate :" + Expdate;
	 }
	 

}
