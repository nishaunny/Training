package ustbootcampjavahack1.nfl;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import ustbootcampjavahack1.nfl.Exception.PlayerNotFoundException;
import ustbootcampjavahack1.nfl.model.LeagueTeam;
import ustbootcampjavahack1.nfl.model.Player;
import ustbootcampjavahack1.nfl.service.LeagueTeamServiceImpl;
import ustbootcampjavahack1.nfl.service.PlayerServiceImpl;
import ustbootcampjavahack1.nfl.service.int_leagueteam;
import ustbootcampjavahack1.nfl.service.int_leagueteamservice;

public class NFLPlayerProcess {

	public static void main(String[] args) throws IOException, PlayerNotFoundException {
		
		//main class than makes use of serviceinterfaceobj with instance of service class, and calls the requiredmethods.
	
		int_leagueteam servobj = new LeagueTeamServiceImpl();
		int_leagueteamservice playerservobj = new PlayerServiceImpl();
		
		char ch='y';
		
		while(ch=='y')
		{
		System.out.println("1-Add a new player, 2-Get player list, 3-Add new team, 4-Get player details and 5-exit.");
		Scanner scan=new Scanner(System.in);
		int choice=scan.nextInt();
	
			
		switch(choice)
		{
		
		case 1:
			System.out.println("Enter playername and other details.");
			List<Player> newplaylist = playerservobj.fetchPlayers(scan.next());
			Player player = new Player(scan.next(),scan.next(),scan.next(),scan.nextInt(),scan.next());
			newplaylist.add(player);
			System.out.println("Added player"+player.getPlayerName());
			
		break;
		
		case 2:
			List<Player> getlist;
				getlist = playerservobj.getAllRegisteredPlayers();
				for (Player playobj: getlist)
					System.out.println(playobj);
			
		break;
		
		case 3:
			System.out.println("Enter league team title and other details.");
			List<LeagueTeam> newleaguelist = servobj.fetchLeagueTeams(scan.next());
		    LeagueTeam league = new LeagueTeam(scan.next(),scan.nextInt(),scan.next());
			newleaguelist.add(league);
			System.out.println("Added league"+league.getTeamTitle());
			for (LeagueTeam leagueobj: newleaguelist)
				System.out.println(leagueobj);
		break;
		
		case 4:
			System.out.println("Enter playerid, password,teamtitle and leaguename.");
			
		    servobj.registerPlayerToLeague(scan.next(), scan.next(), scan.next(), scan.next());
			System.out.println("Thanks for the player details to register.");
		break;
		
		case 5:
		break;	
			

	}
		System.out.println("Do you want to continue y/n");
		ch=(char) System.in.read();
}
}
}