package ustbootcampjavahack1.nfl.repository;

import java.util.List;

import ustbootcampjavahack1.nfl.model.LeagueTeam;
//Interface methods are implemented by leagueclass to get the list and find team by teamtitle.
public interface LeagueTeamRepoImpl {

	LeagueTeam findByLeagueTeamTitle(String teamitle);
	List<LeagueTeam>getAllLeagueTeams();
}
