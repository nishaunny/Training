package ustbootcampjavahack1.nfl.repository;

import java.util.List;

import ustbootcampjavahack1.nfl.model.Player;
//Playerteam repo methods are implemented by theclass to get the player list and find player by id.
public interface PlayerRepoImpl {

	Player findPlayer(String playerId);
	List<Player> getAllPlayers();
}
