package ustbootcampjavahack1.nfl.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import ustbootcampjavahack1.nfl.model.LeagueTeam;

//LeagueTeamrepo class implements the interface to get the league list and one more method.
public class LeagueTeamRepoImplc implements LeagueTeamRepoImpl{

	List<LeagueTeam> leaguelist = new ArrayList<LeagueTeam>();
	
	public LeagueTeam findByLeagueTeamTitle(String teamitle) {
		
		LeagueTeam leagfind=null;
		
		ListIterator iterator = leaguelist.listIterator();
		while(iterator.hasNext()) {
			LeagueTeam nextobj = (LeagueTeam)iterator.next();
			if(nextobj.getTeamTitle()== teamitle)
				leagfind = nextobj;
		}
	      return leagfind;
	}


	public List<LeagueTeam> getAllLeagueTeams() {
		
		LeagueTeam legobj1 = new LeagueTeam("Rocky",2000,"Fall");
		LeagueTeam legobj2 = new LeagueTeam("MandyTeam",1989,"Spring");
		LeagueTeam legobj3 = new LeagueTeam("Tigerteam",1978,"Winter");
		LeagueTeam legobj4 = new LeagueTeam("Mandhills",1900,"Summer");
		LeagueTeam legobj5 = new LeagueTeam("RockyMount",2010,"Snow");
		
		leaguelist.add(legobj1);
		leaguelist.add(legobj2);
		leaguelist.add(legobj3);
		leaguelist.add(legobj4);
		leaguelist.add(legobj5);
	 
		return leaguelist;
	}

}
