package ustbootcampjavahack1.nfl.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;


import ustbootcampjavahack1.nfl.model.Player;

public class PlayerRepoImplc implements PlayerRepoImpl{

	List<Player> playerlist = new ArrayList<Player>();
	
	public Player findPlayer(String playerId) {
          Player findplay=null;
		
		ListIterator iterator = playerlist.listIterator();
		while(iterator.hasNext()) {
			Player nextobj = (Player)iterator.next();
			if(nextobj.getPlayerId().equalsIgnoreCase(playerId))
				findplay = nextobj;
		}
		return findplay;
	}
	


	public List<Player> getAllPlayers() {
		Player play1= new Player("1", "Mandy", "pass123", 3, "MandyTeam");
		Player play2= new Player("2", "Sandy", "pass123", 2, "MandyTeam");
		Player play3= new Player("3", "Sonny", "pass123", 1, "RockyMount");
		Player play4= new Player("4", "Richardy", "pass123", 4, "RockyMount");
		Player play5= new Player("5", "Sammy", "pass123", 3, "Mandhills");
		
		playerlist.add(play1);
		playerlist.add(play2);
		playerlist.add(play3);
		playerlist.add(play5);
		playerlist.add(play4);
		return playerlist;
	}

}
