package ustbootcampjavahack1.nfl.model;
/*
 * Define the following properties.Properties should be private.
   -teamTitle : String
   -year : int
   -season : String
Define parameterized constructor to initialize all the properties
Define Getter for all the properties
Override the toString() method to display League details
 */
public class LeagueTeam {

	private String teamTitle;
    private int year;
    private String season;
	//Constructor to intialize.
    public LeagueTeam(String title, int year, String season)
    {
    	this.teamTitle=title;
    	this.season=season;
    	this.year=year;
    }
     //getter and setter.
	public String getTeamTitle() {
		return teamTitle;
	}

	public void setTeamTitle(String teamTitle) {
		this.teamTitle = teamTitle;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getSeason() {
		return season;
	}

	public void setSeason(String season) {
		this.season = season;
	}
	
	public String toString() {
		return "LeagueTeam:"+"{"+"title"+getTeamTitle()+"year"+getYear()+"season"+getSeason()+"}";
	}
}
