package ustbootcampjavahack1.nfl.model;
/*
 * Define the following properties.Properties should be private.
   -playerId : String
   -playerName : String
   -password : String
   -yearExpr : int
   -teamTitle :String
Define parameterized constructor to initialize all the properties
Define Getter for all the properties and setter for leagueTitle
Override the toString() method to display Player details
 */
public class Player {
	
	private String playerId,playerName,password,teamTitle;
	private int yearExpr;
	
	//Constructor to intialize.
	
	public Player(String id,String name, String password, int yearexperience, String teamTitle){
		this.password=password;
		this.playerId=id;
		this.playerName=name;
		this.yearExpr=yearexperience;
		this.teamTitle=teamTitle;
	}
	//getters and setters.
	public String getPlayerId() {
		return playerId;
	}

	public void setPlayerId(String playerId) {
		this.playerId = playerId;
	}


	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	public String getTeamTitle() {
		return teamTitle;
	}

	public void setTeamTitle(String teamTitle) {
		this.teamTitle = teamTitle;
	}


	public int getYearExpr() {
		return yearExpr;
	}

	public void setYearExpr(int yearExpr) {
		this.yearExpr = yearExpr;
	}

	public String toString() {
		return "Playerdetails:"+"{"+"id"+getPlayerId()+"name"+getPlayerName()+"title"+getTeamTitle()+"yearExp"+getYearExpr()+"password"+getPassword()+"}";
	}

}
