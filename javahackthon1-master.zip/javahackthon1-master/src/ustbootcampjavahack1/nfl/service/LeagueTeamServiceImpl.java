package ustbootcampjavahack1.nfl.service;

import java.util.List;
import java.util.Scanner;

import ustbootcampjavahack1.nfl.model.LeagueTeam;
import ustbootcampjavahack1.nfl.model.Player;
import ustbootcampjavahack1.nfl.repository.LeagueTeamRepoImpl;
import ustbootcampjavahack1.nfl.repository.LeagueTeamRepoImplc;
import ustbootcampjavahack1.nfl.repository.PlayerRepoImpl;
import ustbootcampjavahack1.nfl.repository.PlayerRepoImplc;
//League service class implements the methods of Leagueservice interface to get playerlist, leaguelist, registerplayertoteam and get all registered players.
public class LeagueTeamServiceImpl implements int_leagueteam {
	
	List<LeagueTeam> fetchedlist;
	LeagueTeamRepoImpl lobj = new LeagueTeamRepoImplc();
	
	Scanner scan = new Scanner(System.in);
	public LeagueTeamServiceImpl(){	
		fetchedlist = lobj.getAllLeagueTeams();	
		
	}
	
	
	public List<LeagueTeam>fetchLeagueTeams(String leaguetitle){	
		for(LeagueTeam obj: fetchedlist) {
			System.out.println(obj);
		}
		return fetchedlist;
	}
	
	public String registerPlayerToLeague(String playerId, String password, String teamTitle, String leaguename){
		System.out.println("Enter the teamtitle to which the player is part of.");
	
		String teamtitle = scan.next();
		if(lobj.findByLeagueTeamTitle(teamtitle)!=null) {
			return "Register player to team"+teamtitle;
		}
		else
			return "Not registered";
			
	}
	
		
	}
	
