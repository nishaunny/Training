package ustbootcampjavahack1.nfl.service;

import java.util.List;

import ustbootcampjavahack1.nfl.model.LeagueTeam;

public interface int_leagueteam {
	List<LeagueTeam>fetchLeagueTeams(String leaguetitle);
	String registerPlayerToLeague(String playerId, String password, String teamTitle, String leaguename);

}
