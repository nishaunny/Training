package ustbootcampjavahack1.nfl.service;

import java.util.List;
import java.util.Scanner;

import ustbootcampjavahack1.nfl.Exception.PlayerNotFoundException;
import ustbootcampjavahack1.nfl.model.Player;
import ustbootcampjavahack1.nfl.repository.PlayerRepoImpl;
import ustbootcampjavahack1.nfl.repository.PlayerRepoImplc;

public class PlayerServiceImpl implements int_leagueteamservice {
	
	List<Player> playerlist;
	PlayerRepoImpl playobj = new PlayerRepoImplc();
	Scanner scan = new Scanner(System.in);
	public PlayerServiceImpl() {
	playerlist = playobj.getAllPlayers();
	}
	@Override
	public List<Player> fetchPlayers(String playername) {
		for(Player obj: playerlist) {
			System.out.println(obj);
		}
		return playerlist;
	}

	@Override
	public List<Player> getAllRegisteredPlayers() throws PlayerNotFoundException{
		System.out.println("Enter the playerid to check whether registered.");
        String id = scan.next();
        Player playfindobj = playobj.findPlayer(id);
		if(playfindobj==null) {
	
			throw new PlayerNotFoundException("id is not found");
		}
		else
			System.out.println("Player found in the list");
		return playerlist;
	}

}
