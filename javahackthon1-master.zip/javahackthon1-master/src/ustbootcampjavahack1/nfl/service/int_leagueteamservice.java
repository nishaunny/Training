package ustbootcampjavahack1.nfl.service;

import java.util.List;

import ustbootcampjavahack1.nfl.Exception.PlayerNotFoundException;
import ustbootcampjavahack1.nfl.model.LeagueTeam;
import ustbootcampjavahack1.nfl.model.Player;

public interface int_leagueteamservice {
	List<Player>fetchPlayers(String playername);
	
	List<Player>getAllRegisteredPlayers() throws PlayerNotFoundException;

}
