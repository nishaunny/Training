package ustbootcampjavahack1.nfl.Exception;

public class PlayerNotFoundException extends Exception{

	public PlayerNotFoundException(String msg)
	{
		super(msg);
	}

}
