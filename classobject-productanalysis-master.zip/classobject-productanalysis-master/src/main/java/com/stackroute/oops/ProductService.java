package com.stackroute.oops;

import java.util.Collections;

/*
    Class for Analyzing the products present in ProductRepository
 */
public class ProductService {

	Product[] newproductlist=ProductRepository.getProducts();
	
    /*
        Returns the name of the product given the productCode
     */
    public String findProductNameByCode(int productCode) {
    	for(Product pobj:newproductlist) {
    		if(pobj.getProductCode()==(productCode))
    		{
    			System.out.println("name"+pobj.getName());
    			return pobj.getName();
    		}
    	}
        return null;
    }

    /*
        Returns the Product with maximum price in a given category
     */
    public Product findMaxPriceProductInCategory(String category) {
    	for(Product pobj:newproductlist) {
    		if(pobj.getCategory().equalsIgnoreCase(category) && pobj.getPrice()>=1000)
    		{
    			return pobj;
    			
    		}
    	}
		
        return null;
    }

    /*
        Returns a array of products for a given category
     */
    public Product[] getProductsByCategory(String category) {
    	
    	Product[] prodtemp = ProductRepository.getProducts();
    	
		int j=0, i=0;
		while(i<7) {
		if(newproductlist[i].getCategory().equalsIgnoreCase(category)){
			  i=i+1;
			  j=j+1;
			  prodtemp[j]=newproductlist[i];
				/*
				 * for(Product obj:prodtemp) { System.out.println(obj);}
				 */
			  return prodtemp;
		   }
		
		}
    	return null;
       // return new Product[]{};
    }
}
