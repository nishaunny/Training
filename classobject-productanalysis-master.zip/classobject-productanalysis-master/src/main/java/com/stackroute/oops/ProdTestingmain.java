package com.stackroute.oops;

public class ProdTestingmain {

	public static void main(String[] args) {
		// MAIN METHOD NOT THERE - ADDED TO TEST THE Workflow.
		
		/*
		 * ProductService serobj = new ProductService();
		 * serobj.getProductsByCategory("TOYS");
		 */
		/* Product prodmaxprice = serobj.findMaxPriceProductInCategory("Toys");
		 * System.out.println(prodmaxprice.getPrice());
		 serobj.getProductsByCategory("Toys"); serobj.findProductNameByCode(104);
		 * serobj.findProductNameByCode(101); serobj.findProductNameByCode(102);
		 * serobj.findProductNameByCode(103); serobj.findProductNameByCode(105);
		 * serobj.findProductNameByCode(106); serobj.findProductNameByCode(107);
		 * serobj.findProductNameByCode(108);
		 */
		

	}

}
