package com.stackroute.newz.aspect;

/* Annotate this class with @Aspect and @Component */
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/* Annotate this class with @Aspect and @Component */
@Aspect
@Component
public class LoggerAspect {

	/*
	 * Write loggers for each of the methods of NewsController, any particular
	 * method will have all the four aspectJ annotation
	 * (@Before, @After, @AfterReturning, @AfterThrowing).
	 */
	Logger mylogger = LoggerFactory.getLogger(LoggerAspect.class);

	@Pointcut("execution (* com.stackroute.newz.controller.NewsController.saveNews(..))")
	public void saveNews() {

	}

	@After("saveNews()")
	public void saveNewsAdvice(JoinPoint jp) {
		mylogger.info("news saved");
		System.out.println(jp.getSourceLocation().toString());
			
		}
	
	@AfterThrowing("saveNews()")
	public void afternewssaved() {
		mylogger.warn("Exception raised  due to duplicate id");
	}
	
	@Pointcut("execution (* com.stackroute.newz.controller.NewsController.deleteNews(..))")
	public void deleteNews() {

	}

	@After("deleteNews()")
	public void deleteNewsAdvice(JoinPoint jp) {
		mylogger.info("news deleted");
		System.out.println(jp.getSourceLocation().toString());
			
		}
	
	@Pointcut("execution (* com.stackroute.newz.controller.NewsController.updateNews(..))")
	public void updateNews() {

	}

	@After("updateNews()")
	public void updateNewsAdvice(JoinPoint jp) {
		mylogger.info("news updated");
		System.out.println(jp.getSourceLocation().toString());	
		}
	
	@AfterThrowing("updateNews()")
	public void afternewsUpdated() {
		mylogger.warn("Exception raised  due to invalid id");
	}
	
	@Pointcut("execution (* com.stackroute.newz.controller.NewsController.getNews(..))")
	public void getNews() {

	}

	@After("getNews()")
	public void getNewsAdvice(JoinPoint jp) {
		mylogger.info("news fetched");
		System.out.println(jp.getSourceLocation().toString());
			
		}
	
	@AfterThrowing("getNews()")
	public void afternewsFetched() {
		mylogger.warn("Exception raised due to invalid id");
	}
}
