package com.stackroute.newz.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.newz.model.News;
import com.stackroute.newz.model.UserNews;
import com.stackroute.newz.repository.NewsRepository;
import com.stackroute.newz.util.exception.NewsNotFoundException;

/*
* Service classes are used here to implement additional business logic/validation 
* This class has to be annotated with @Service annotation.
* @Service - It is a specialization of the component annotation. It doesn't currently 
* provide any additional behavior over the @Component annotation, but it's a good idea 
* to use @Service over @Component in service-layer classes because it specifies intent 
* better. Additionally, tool support and additional behavior might rely on it in the 
* future.
* */

@Service
public class NewsServiceImpl implements NewsService {

	/*
	 * Autowiring should be implemented for the NewsDao and MongoOperation. (Use
	 * Constructor-based autowiring) Please note that we should not create any
	 * object using the new keyword.
	 */

	@Autowired
	NewsRepository newsRepo;

	/*
	 * This method should be used to save a new news.
	 */
	@Override
	public boolean addNews(News news) {

		Optional<UserNews> userExist = newsRepo.findById(news.getNewssource().getNewsSourceCreatedBy());
		if (userExist.isPresent()) {
			long userCount = userExist.get().getNewslist().stream().filter(newz -> newz.getNewsId() != news.getNewsId())
					.count();
			if (userCount == 0) {
				userExist.get().getNewslist().add(news);
				return true;
			} else {
				return false;
			}

		} else {
			List<News> newsList = new ArrayList<>();
			newsList.add(news);
			UserNews userNews = new UserNews();
			userNews.setUserId(news.getNewssource().getNewsSourceCreatedBy());
			userNews.setNewslist(newsList);
			if (newsRepo.insert(userNews) != null) {
				return true;
			}
		}
		return false;
	}

	/* This method should be used to delete an existing news. */

	public boolean deleteNews(String userId, int newsId) {
		Optional<UserNews> newsOptional = newsRepo.findById(userId);

		if (newsOptional.isPresent()) {
			UserNews userNews = newsOptional.get();
			List<News> newsList = userNews.getNewslist().stream().filter(news -> news.getNewsId() != newsId)
					.collect(Collectors.toList());

			userNews.setNewslist(newsList);
			 newsRepo.save(userNews);

			return true;
		} else {
			throw new NullPointerException("News not found");
		}
	}

	/* This method should be used to delete all news for a specific userId. */

	public boolean deleteAllNews(String userId) throws NewsNotFoundException {
	
			Optional<UserNews> newsOptional = newsRepo.findById(userId);
			if (newsOptional.isPresent()) {
				newsRepo.deleteById(userId);
				return true;
			}
			else {
				throw new NewsNotFoundException("News not found");
			}
		

	}

	/*
	 * This method should be used to update a existing news.
	 */

	public News updateNews(News news, int newsId, String userId) throws NewsNotFoundException {
			Optional<UserNews> newsOptional = newsRepo.findById(userId);

			if (newsOptional.isPresent()) {
				UserNews userNews = newsOptional.get();

				List<News> newsList = userNews.getNewslist().stream().peek((newz) -> {
					if (newz.getNewsId() == newsId) {
						newz.setAuthor(news.getAuthor());
	                        newz.setContent(news.getContent());
	                        newz.setDescription(news.getDescription());
	                        newz.setNewssource(news.getNewssource());
	                        newz.setPublishedAt();
	                        newz.setReminder(news.getReminder());
	                        newz.setTitle(news.getTitle());
	                        newz.setUrl(news.getUrl());
	                        newz.setUrlToImage(news.getUrlToImage());
					}
				}).collect(Collectors.toList());

				userNews.setNewslist(newsList);
				newsRepo.save(userNews);

				return newsList.stream().filter(newz -> newz.getNewsId() == newsId).findFirst().get();
			}
			else {
			throw new NewsNotFoundException("News not found");
		}
	}

	/*
	 * This method should be used to get a news by newsId created by specific user
	 */

	public News getNewsByNewsId(String userId, int newsId) throws NewsNotFoundException {
		
			Optional<UserNews> newsOptional = newsRepo.findById(userId);
			if (newsOptional.isPresent()) {
				Optional<News> optionalNews = newsOptional.get().getNewslist().stream()
						.filter(news -> news.getNewsId() == newsId).findFirst();
				News news = optionalNews.get();

				return news;
		} else {
			throw new NewsNotFoundException("News not found");
		}
	}

	/*
	 * This method should be used to get all news for a specific userId.
	 */

	public List<News> getAllNewsByUserId(String userId) {
		Optional<UserNews> newsOptional = newsRepo.findById(userId);

		if (newsOptional.isPresent()) {
			return newsOptional.get().getNewslist();
		}
		return null;
	}

}
