package daythree.main;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import daythree.model.Student;
import daythree.repo.StudentRepo;



public class StudentReportAnalysis {
	
	static List<Student> studentlist = StudentRepo.getStudents();

	public static void main(String[] args) {
		/*1. list students who belongs to vidhyamandir school
		2. list students who belongs to commerce group and secured above 1000 marsk
		3. list school names  which is having rank to be less than 5//greater than 5
		4. get student data who scored maximum / minimum
		5. list the student data in ascending order of mark secured
		6. list the average marks for the given city or  subject
		7. list schoolname, studenname who secured above 1000
		8. list highestscore in the given schoolname
		9. list topper in the given school*/
		
		getStudentbySchoolName("vidhyamandir");
		getCommerceStudentandHighestMark("Commerce",1000);
		getSchoolnames(5);
		getStudentswhoScoredMaxandMin();
		sortStudentMarkAscending();
		getAverageMarksInCity("Delhi");
		getSchoolStudentNameaboveMark(1000);
		getHighestScoreinGivenSchoolName("johns");
		getToppernameintheGivenSchool("johns");
	

	}
//	list students who belongs to vidhyamandir school
	static void getStudentbySchoolName(String str) 
	{
		
		Predicate<Student> predobjforsname = (sobj) -> sobj.getSchoolname().equals(str);
		
		List<Student> schoolstudentforvidhya = studentlist.stream().filter(predobjforsname).collect(Collectors.toList());
		
		schoolstudentforvidhya.forEach(System.out::println);
		
	}
	//list students who belongs to commerce group and secured above 1000 marsk
	static void getCommerceStudentandHighestMark(String group, int highmark) 
	{
		
	   Predicate<Student> pre1comm = (sobj) -> sobj.getGroupname().equals(group);
	   Predicate<Student> pre2highmark = (sobj) -> sobj.getTotal()>=(highmark);
	   
	   Predicate<Student> preboth = pre1comm.and(pre2highmark);
	   
	   List<Student> getcommerhighlist = studentlist.stream().filter(preboth).collect(Collectors.toList());
	   
	   getcommerhighlist.forEach(System.out::println);
	   
	   
	   
	}
	//3. list school names  which is having rank to be less than 5//greater than 5
	static void getSchoolnames(int rank) {
		
		Predicate<Student> predschool = (sobj) -> sobj.getRank()>(rank);
		
		List<String> schoolnamewithRank = studentlist.stream().filter(predschool).map((sobj) -> sobj.getSchoolname()).collect(Collectors.toList());
		//takes the stream as input applying the condition using test in filter, take the school object from filter and map applies the condition to return string -schoolname, then convertedto list.
		schoolnamewithRank.forEach(System.out::println);
	}
	
	//4. get student data who scored maximum / minimum	
static void getStudentswhoScoredMaxandMin() {
	
//	Comparator<Student> cobj = (sud1,sud2)->{ if(sud1.getTotal()==sud2.getTotal()) return 0;
//	else if(sud1.getTotal()<sud2.getTotal()) return -1; 
//	else return 1;};
//	
//	Optional<Student> compared = studentlist.stream().max(cobj);
//	if(compared.isPresent())
//		System.out.println(compared.get().getName());
	
	Optional<Student> compa=studentlist.stream().max(Comparator.comparing(Student::getTotal));
	System.out.println("Max score by this student" +compa.get().getName());
	Optional<Student> compamin=studentlist.stream().min(Comparator.comparing(Student::getTotal));
	System.out.println("Min score by this student" +compamin.get().getName());
//	OptionalInt value = studentlist.stream().mapToInt(Student::getTotal).max(); - maptoInt to get the totalof student returned as int, then take max or min to get the score.
//	System.out.println(+value.getAsInt());
	
	
}

//5. list the student data in ascending order of mark secured - default sorted will give ascending(bigtosmall) so used.reversed to 
//make it descending order after sortncompare.
static void sortStudentMarkAscending()
{

	 
//List<String> sortedlist=studentlist.stream().sorted(Comparator.comparing(Student::getTotal)).map(Student::getName).collect(Collectors.toList());
//	  
List<Student> sortedlist=studentlist.stream().sorted(Comparator.comparing(Student::getTotal).reversed()).collect(Collectors.toList());
// give this list in descending order - small to big using .reverse in comparator.
//
		sortedlist.forEach(System.out::println);
	  
}
	
	
//6. list the average marks for the given city or  subject	
//getting average marks for the given city or subject.
static void getAverageMarksInCity(String cityname)
{

		Predicate<Student> precity = (sobj) -> sobj.getAddr().equals(cityname);
		OptionalDouble avg=studentlist.stream().filter(precity).mapToInt( sobj->sobj.getTotal()).average();

		//OptionalDouble avg=studentlist.stream().filter((sobj) -> sobj.getAddr().equals(cityname)).mapToInt( sobj->sobj.getTotal()).average();

if(avg.isPresent())
System.out.println("Average marks in ..." +cityname+":"+avg.getAsDouble());
	
}

//7. list schoolname, studenname who secured above 1000
static void getSchoolStudentNameaboveMark(int mark) {
			 
//		getting the studentname as list for marks above given mark
//	List<String> name = studentlist.stream().filter((sobj)->sobj.getTotal()>(mark)).map(Student::getName).collect(Collectors.toList());
//	name.forEach(System.out::println);
	
	Predicate<Student> premark=(sobj)->sobj.getTotal()>mark;
	
	//collectors.tomap(to convert the result to a map - key and value)
	Map<String, String> mapresult=studentlist.stream().filter(premark).collect(Collectors.toMap(Student::getName, Student::getSchoolname));
	
	mapresult.forEach( (k,v) -> System.out.println(k + " school nmae : "  + v));
	
	
//Map with string and object
//Map<String,Student> mapresult=studentlist.stream().filter(premark).collect(Collectors.toMap(Student::getName, sobj->sobj));
//mapresult.forEach( (k,v) -> System.out.println(k + " : "  + v.getGroupname() + v.getSchoolname() ));

	}
	



//8. list highestscore in the given schoolname
static void getHighestScoreinGivenSchoolName(String sch)			
 {
	 OptionalInt score = studentlist.stream().filter((sobj)-> sobj.getSchoolname().equals(sch)).mapToInt((sobj)->sobj.getTotal()).max();
	 
	 System.out.println("Max score " +score.getAsInt());
	 
 }
//9. list topper in the given school*/ 
 static void getToppernameintheGivenSchool(String sch)
 {
	 Optional<Student> studtopper = studentlist.stream().filter((sobj)->sobj.getSchoolname().equals(sch)).max(Comparator.comparing((sobj)->sobj.getTotal()));
	 if(studtopper.isPresent())
		 System.out.println("Topper in schoolname " +sch+", is " +studtopper.get().getName());
	 
		/*For using collectors.tocollection(convert to linkedlist)
		 * LinkedList<Student> llist=
		 * studentlist.stream().collect(Collectors.toCollection(LinkedList::new));
		 * 
		 * llist.forEach(System.out::println);
		 */
	 
 }
}
