package forexercise.streamapi;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import forexercise.streamapi.model.Studente;
import forexercise.streamapi.model.repo.Studenterepo;

//Compute the below operations

/*
 * 1) list all the studnet details belongs to the given university
 * 
 * 2) Find the average rank for the given subject
 * 
 * 3) Find the Best performer list (sort using Rank)
 * 
 * 4) List down the student names , who are all secured <10 rank in the given
 * Subject
 * 
 * 5) Display the name of student in Rank descending order , for the given
 * Collegename
 * 
 * 6) Compute the count of student in the given University
 */
public class StudentAnalysis {
	
	static List<Studente> analyzelist = Studenterepo.getStudents();

	public static void main(String[] args) {

		getStudentDetails("Mahatma");
		findAverageRankforSub("CSE");
		bestPerformerusingRank();
		getStudentsforSubjMaxrank("CSE");
		getNameDescendingOrder("Le College");
		countStudentsforUni("Bits");

	}
	//1) list all the studnet details belongs to the given university
	static void getStudentDetails(String uni) {
		
		Predicate<Studente> predobj = (sobj)-> sobj.getUniversity().equals(uni);
		
		List<Studente> list = analyzelist.stream().filter(predobj).collect(Collectors.toList());
		
		System.out.println("1.List1 for student details");
		list.forEach(System.out::println);
		
	}
	//2) Find the average rank for the given subject
	static void findAverageRankforSub(String sub) {
		
		 Predicate<Studente> predobj = (sobj)-> sobj.getSubj().equals(sub);
		 
		 OptionalDouble rankavg = analyzelist.stream().filter(predobj).mapToInt((sobj)->sobj.getRank()).average();
		 
		 if(rankavg.isPresent())
			 System.out.println("2.Average for a subject " +sub +":" +rankavg.getAsDouble());
	}
	//3) Find the Best performer list (sort using Rank)
	static void bestPerformerusingRank() {
		
		
		List<String> list = analyzelist.stream().sorted(Comparator.comparing((sobj)-> sobj.getRank())).map(Studente::getName).collect(Collectors.toList());
		System.out.println("3.Sort using rank, best performers");
		list.forEach(System.out::println);
	
	}
//	* 4) List down the student names , who are all secured <10 rank in the given
//	 * Subject
	static void getStudentsforSubjMaxrank(String sub) {
		
		/*
		 * Optional<Studente> strstud =
		 * analyzelist.stream().filter((sobj)->sobj.getSubj().equals(sub)).max(
		 * Comparator.comparing((sobj)-> sobj.getRank()));
		 * 
		 * if(strstud.isPresent())
		 * 
		 * System.out.println("students with high rank for a subject.."+strstud.get().
		 * getName());
		 */
		Predicate<Studente> pred1 = (sobj) -> sobj.getSubj().equals(sub) && sobj.getRank()<10;
		//Predicate<Studente> pred1 = (sobj) -> sobj.getSubj().equals(sub);
		//Predicate<Studente> pred2 = pred1.and((sobj)-> sobj.getRank()<10);
		
		List<String> result = analyzelist.stream().filter(pred1).map(Studente::getName).collect(Collectors.toList());
		System.out.println("4.Students with rank less than 10");
		result.forEach(System.out::println);
		
		
	}
	
	
//	 * 5) Display the name of student in Rank descending order , for the given Collegename
	
	static void getNameDescendingOrder(String collg) {
		
		Predicate <Studente> countpred = (sobj)->sobj.getCollegename().equals(collg);
		//sorted returns in the ascending order, to make it descending.reversed in the comparator condition,map to get studentname(returns string) with sorted rank. Then convert to list.
		List<String> desclist = analyzelist.stream().filter(countpred).sorted(Comparator.comparing(Studente::getRank).reversed()).map(Studente::getName).collect(Collectors.toList());
		System.out.println("5.Descending order based on collegename "+collg);
		
		desclist.forEach(System.out::println);
	}
	// * 6) Compute the count of student in the given University
  static void countStudentsforUni(String Uni) {
		
		Predicate<Studente> countpred = (sobj)->sobj.getUniversity().equals(Uni);
		
		Long total = analyzelist.stream().filter(countpred).count();
		
		System.out.println("6.Total count of students in university " +Uni +":" +total);
		
	}
	
}
