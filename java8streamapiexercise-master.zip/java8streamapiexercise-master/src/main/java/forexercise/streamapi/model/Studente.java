package forexercise.streamapi.model;

public class Studente {
//	Build a Student class with below attributes
//
//	  Name - string
//	  Subject -string
//	   Collegename - String
//	  Rank - int
//	  University - String
	
	
	private String name, Subj, Collegename, University;
	private int rank;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSubj() {
		return Subj;
	}
	public void setSubj(String subj) {
		Subj = subj;
	}
	public String getCollegename() {
		return Collegename;
	}
	public void setCollegename(String collegename) {
		Collegename = collegename;
	}
	public String getUniversity() {
		return University;
	}
	public void setUniversity(String university) {
		University = university;
	}
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	
	 public Studente(String nam, String sub, String collg, String univer, int rank)
	    {
		 	this.rank = rank;
		 	this.name = nam;
		 	this.Subj= sub;
		 	this.Collegename=collg;
		 	this.University=univer;
	       
	    }
	 
	    public String toString()
	    {
	     return "Studente name :" + name + " Rank :" + rank + " College :" + Collegename + " Subject :" + Subj + " University's name :" + University;
	     }
	    

}
