package forexercise.streamapi.model.repo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import forexercise.streamapi.model.Studente;



//Keep 5 list of students 

public class Studenterepo {

	static List<Studente> students;
	 public Studenterepo()
	 {
	 students=new ArrayList(); 
	 }
	 
	 public static List<Studente> getStudents()
	 {
	  Studente student1=new Studente("Manu", "CSE", "Le College", "Bits", 5);
	  Studente student2=new Studente("Kamalu", "CSE", "Le College", "Bits", 20);
	  Studente student3=new Studente("Sam", "EEE", "Le College", "Bits", 30);
	  Studente student4=new Studente("Leeul", "EEE", "Le College", "Mahatma", 40);
	  Studente student5=new Studente("Mike", "MECH", "Le College2", "Mahatma", 6);
	  Studente student6=new Studente("Tyson", "CSE", "Le College3", "VIT", 3);
	 students=Arrays.asList(student1,student2,student3,student4,student5,student6);
	 
	  return students;
}
}
