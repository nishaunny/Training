import { Component, OnInit } from '@angular/core';
import { Product } from 'src/product';
import { CustomerorderService } from '../customerorder.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  product: Product;
  prods: Array<Product>=[];
  constructor(private custord: CustomerorderService) {
    this.product = new Product();
   }
  
  ngOnInit(): void {

    this.custord.getProduct().subscribe( (res)=>console.log(res));
    
  }

  get(){
    this.custord.getProduct().subscribe( (res)=>{ this.prods=res;},(error)=>console.log(error.message));
  }

  add(){

    event?.preventDefault();

    this.custord.addProduct(this.product).subscribe( (res)=>{this.prods.push(this.product);},(error)=>console.log(error));
  }

  logout(){
    sessionStorage.clear();
  }

}
