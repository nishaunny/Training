
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class OrganicrouteService {

  constructor(private routobj: Router) { }
//Using routerobj, call navigate method to move to that page using routing.
  openLogin(){

    this.routobj.navigate(['login']);
  }

  openDashboard(){
    this.routobj.navigate(['dash']);
  }

  openHome(){
    this.routobj.navigate(['home']);
  }
}
