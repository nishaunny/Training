import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { OrganicrouteService } from './organicroute.service';

@Injectable({
  providedIn: 'root'
})
export class ActivateGuard implements CanActivate {

  constructor(private orgrout: OrganicrouteService){}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): 
    Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    let user = sessionStorage.getItem("username");
    let password= sessionStorage.getItem("password");

    if ((user!="admin") || (password!="password"))
    {
      this.orgrout.openLogin();
      return false;
    }

    return true;
  }
  
}
