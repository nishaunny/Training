import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from 'src/product';

@Injectable({
  providedIn: 'root'
})
export class CustomerorderService {

  constructor(private httpcli: HttpClient) { }

  getProduct():Observable<Array<Product>>
  {
    return this.httpcli.get<Array<Product>>("http://localhost:3000/Product");
  }
  addProduct(data:Product): Observable<Product>
  {

    return this.httpcli.post<Product>("http://localhost:3000/Product",data);
  }

}
