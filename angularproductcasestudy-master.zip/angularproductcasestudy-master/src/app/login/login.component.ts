import { Component, OnInit } from '@angular/core';
import { OrganicrouteService } from '../organicroute.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private orgroute: OrganicrouteService) { }

  ngOnInit(): void {
  }


  showDashwhile(user:string, pass:string){

    sessionStorage.setItem("username", user);
    sessionStorage.setItem("password",pass);

    this.orgroute.openDashboard();

  }
}
