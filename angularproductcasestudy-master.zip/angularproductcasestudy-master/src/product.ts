export class Product{

    id: number =0;
    Productname: string ="";
    Qty: number=0;


    constructor(){}

}