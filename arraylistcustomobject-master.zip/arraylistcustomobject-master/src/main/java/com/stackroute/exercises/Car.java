package com.stackroute.exercises;

/*/## Problem Statement: Write a program to create a car catalog using Arrraylist with custom class Object

**Given car details like Model Name,Manufacturer Name,Engine Capacity,Car Type 
create a Arraylist of car details with a custom object as List datatype***/

// Custom Class
//setCarDetails(String modelName, String manufacturerName, int engineCapacity, String carType)
public class Car{

	private String modelName;
	private String manufacturerName;
	private int engineCapacity;
	private String carType;
	
	public String getCarType() {
		return carType;
	}

	public void setCarType(String carType) {
		this.carType = carType;
	}

	public Car() {
	}

	/*
	 * public Car (String name, String manufacturer, int engineCap, String carType)
	 * { this.modelName=name; this.manufacturerName=manufacturer;
	 * this.engineCapacity=engineCap; this.carType = carType; }
	 */
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getManufacturerName() {
		return manufacturerName;
	}
	public void setManufacturerName(String manufacturerName) {
		this.manufacturerName = manufacturerName;
	}
	public int getEngineCapacity() {
		return engineCapacity;
	}
	public void setEngineCapacity(int engineCapacity) {
		this.engineCapacity = engineCapacity;
	}

	//[{modelName: 'Vitara Brezza', manufacturerName: 'MarutiSuzuki', engineCapacity: 1000, carType: 'suv'}]
	public String toString() {
		
		return "{modelName: '"+getModelName()+"', "+"manufacturerName: '"+getManufacturerName()+"', "+"engineCapacity: "+getEngineCapacity()+", "+"carType: '"+getCarType()+"'}";
	
}
}