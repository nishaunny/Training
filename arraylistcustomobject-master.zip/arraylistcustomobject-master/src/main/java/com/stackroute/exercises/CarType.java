package com.stackroute.exercises;

public enum CarType {
    HatchBack,
    SUV,
    Sedan,
    PickupTruck,
}


