package com.stackroute.exercises;

import java.util.ArrayList;
import java.util.List;

public class CarDetailsListCreation {
    //Write here logic to return global list variable
	//List is created and the carobjects are added to the list.
	 List<Car> carlist = new ArrayList<Car>();
	 Car carobj1 = new Car();
	 Car carobj2 = new Car();
	 Car carobj3 = new Car();
	 Car carobj4 = new Car();
	 Car carobj5 = new Car();
	 Car carobj6 = new Car();
	 
    public String getCarDetails() {
    	carobj1.setCarType("suv");
		carobj1.setEngineCapacity(1000);
    	carobj1.setModelName("Vitara Brezza");
    	carobj1.setManufacturerName("MarutiSuzuki");
    	carobj2.setCarType("SUV"); 
		carobj2.setEngineCapacity(2200);
		carobj2.setModelName("Innova");
		carobj2.setManufacturerName("Toyota"); 
  		carobj3.setCarType("Sedan"); 
  		carobj3.setEngineCapacity(1500);
  		carobj3.setModelName("Rapid");
  		carobj3.setManufacturerName("Skoda"); 	 
  		carobj4.setCarType("sedan");
  		carobj4.setEngineCapacity(3500); 
  		carobj4.setModelName("M3Competition");
  		carobj4.setManufacturerName("BMW"); 
  		carobj5.setCarType("hatchback");
  		carobj5.setEngineCapacity(1200); 
  		carobj5.setModelName("Micra");
  		carobj5.setManufacturerName("Nissan");
  		carobj6.setCarType("Pickuptruck");
  		carobj6.setEngineCapacity(5800);
  		carobj6.setManufacturerName("Ford");
  		carobj6.setModelName("F-150");
  		carlist.add(carobj1);
  		carlist.add(carobj2);
  		carlist.add(carobj3);
  		carlist.add(carobj4);
  		carlist.add(carobj5);
  		carlist.add(carobj6);
  		//System.out.println(carlist.toString());

        return carlist.toString();
    }

    //Write here logic to add value to global list variable
    public void setCarDetails(String modelName, String manufacturerName, int engineCapacity, String carType) throws WrongInputException,OutOfRangeException {
        //Storing enuam value as a string in enum1 to enum4.
    	String enum1=CarType.HatchBack.name();
    	String enum2=CarType.PickupTruck.name();
    	String enum3=CarType.SUV.name();
    	String enum4=CarType.Sedan.name();
    //Validations to check for all the attributes of the custom class Car.
    	if(modelName==null||manufacturerName==null||carType==null)
    	{
    		throw new WrongInputException("Input might contain a null or empty or blank space value");
    	}
    	else if(modelName.isBlank()||manufacturerName.isBlank()||modelName.isEmpty()||manufacturerName.isEmpty()||carType.isBlank())
    	{
    		throw new WrongInputException("Input might contain a null or empty or blank space value");
    	}
    	else if(engineCapacity<1000||engineCapacity>10000)
    	{
    		throw new OutOfRangeException("EngineCapacity is out of range(1000 to 10000)");
    		
    	}
    	
    	else if((carType.equalsIgnoreCase(enum1))||(carType.equalsIgnoreCase(enum2))||(carType.equalsIgnoreCase(enum3))||(carType.equalsIgnoreCase(enum4)))
    	{
                 //System.out.println("added."+modelName +manufacturerName +engineCapacity +carType);     
    	}
    	else
    	{
    		throw new WrongInputException("CarType '"+carType+"' is not present in the enumeration");
    	}
    		
    		
    	
    }

}
