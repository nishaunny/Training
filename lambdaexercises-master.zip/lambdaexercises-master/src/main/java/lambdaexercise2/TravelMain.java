package lambdaexercise2;

import java.util.Arrays;
import java.util.List;

///*method : isSenior() --> returns true if age>64 else false
//
//
//Interface
//iSeniorProcess
//   boolean checkSenior(int age)
//
//
//interface
//iPassengerProcess
//    String showDetail(Passenger )
//
//Main class : TravelMain
//
//method ->
//
//1)  passengerData(List<Passenger> , iPassengerProcess)
//this method should return the list of passenger name who travelled from the city "Chennai"
// 
//
//2) main method
//  initiate 5 Passenger list
//  call passengerData with the list and implement the functionality for 
//  iPassengerProcess using lambda
//
//
//
//  use method reference for ISeniorProcess with  Passenger Class , 
//  isSenior method and display (use one sample object)*/*/
@FunctionalInterface
interface iSeniorProcess{
	 boolean checkSenior(int age);
}
@FunctionalInterface
interface iPassangerProcess{
	String showDetail(Passager pobj);
}
public class TravelMain {
	
	static void passengerData(List<Passager> list, iPassangerProcess pobj) {
		for(Passager p: list)
		if (pobj.showDetail(p)!=null)
	
				System.out.println("Person travelled from chennai " +p.getName());
	
	}

	public static void main(String[] args) {
		
         Passager passobj1= new Passager("Raju","Chennai",70, 189);
         Passager passobj2= new Passager("Mani","Hyderabad",50, 180);
         Passager passobj3= new Passager("Sam","Chennai",60, 188);
         Passager passobj4= new Passager("Tom","Delhi",35, 182);
         Passager passobj5= new Passager("John","Andhra",56, 181);
         
         List<Passager> passlist = Arrays.asList(passobj1, passobj2, passobj3, passobj4, passobj5);
         
         passengerData(passlist, (pobj)-> 
         {
        	 
        	 if(pobj.getCity().equalsIgnoreCase("Chennai"))
        			 return pobj.getName();
        	 else
			return null;});
         
         iSeniorProcess senobj = Passager::isSenior;
         boolean ans = senobj.checkSenior(70);
         System.out.println("Answer for boolean function " +ans);
        
        		 
	}

}
