package lambdaexercise2;
/*Complete below functionalities. Use lambda

Passenger Class
Attibutes : name , 	age , 	tickenumber, city
method : isSenior() --> returns true if age>64 else false


Interface
iSeniorProcess
   boolean checkSenior(int age)


interface
iPassengerProcess
    String showDetail(Passenger )

Main class : TravelMain

method ->

1)  passengerData(List<Passenger> , iPassengerProcess)
this method should return the list of passenger name who travelled from the city "Chennai"
 

2) main method
  initiate 5 Passenger list
  call passengerData with the list and implement the functionality for 
  iPassengerProcess using lambda



  use method reference for ISeniorProcess with  Passenger Class , 
  isSenior method and display (use one sample object)*/


public class Passager {
	
	private String name, city;
	private int age;
	private int ticketNumber;
	
	public Passager(String name, String city, int age, int tickno) {
		this.name = name;
		this.ticketNumber=tickno;
		this.city = city;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getTicketNumber() {
		return ticketNumber;
	}
	public void setTicketNumber(int ticketNumber) {
		this.ticketNumber = ticketNumber;
	}
	
	public static boolean isSenior(int age) {
		if(age>64)
			return true;
		else
			return false;
	}

}
