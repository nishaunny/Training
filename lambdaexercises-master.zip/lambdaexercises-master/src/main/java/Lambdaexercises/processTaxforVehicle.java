package Lambdaexercises;

import java.util.Scanner;

/*1)Create below functional interface and implement using lambda 

Class :  Vehicle

attribute : string type,String company, int price


interface iShowTax
   method : int findTax(int price)

Main method Class
  static method : void processTax (Vehicle, iShowTax) 

in main method 
    create an object of Vehicle 
    implement iShowTax using lambda, if price >50000 then 24% tax else 10% tax

   call processTax method*/

@FunctionalInterface
interface iShowTax{
	//functional interface that is implemented in the main method class.
	int findTax(int price);
}

public class processTaxforVehicle {
	
//since in main method this method is static, it take vehicle object and ishowtax interface object.
	//interface findtax abstract method is called.
	static void processTax(Vehicle obj, iShowTax taxobj) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the price for which tax is returned.");
		int price = scan.nextInt();
		
		int taxreturn = taxobj.findTax(price);
		System.out.println("Tax returned  " +taxreturn);
		
	}	


	public static void main(String[] args) {
		
		Vehicle vehobj = new Vehicle(9000,"Cruiser","Toyota");
		System.out.println("Car's type and company:"+vehobj.getType()+" "+vehobj.getCompany());
		
		iShowTax taxobj = (price)-> {
			if(price>5000) 
				return price*24/100;
			else
				return price*10/100;
		};
		//calling the processTax static method.
		processTax(vehobj,taxobj);
		

	}
	

}
