package Lambdaexercises;

/*1)Create below functional interface and implement using lambda 

Class :  Vehicle

attribute : string type,String company, int price


interface iShowTax
   method : int findTax(int price)

Main method Class
  static method : void processTax (Vehicle, iShowTax) 

in main method 
    create an object of Vehicle 
    implement iShowTax using lambda, if price >50000 then 24% tax else 10% tax

   call processTax method*/


public class Vehicle {
	//vehicle class variables.
	private String type;
	private String company;
	private int price;
	//constructor
	public Vehicle (int price, String type, String company) {
		this.price = price;
		this.type = type;
		this.company = company;
	}
	//getters and setters.
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	

}
