package concepts;

class Ticket
{
	int ticketqty=15;
	public void displayDetail(String type, int num)
	{
		//shared resource ticketobj will be locked until the first thread finishes execution.
		//then second thread will access. - using synchronized keyword.
		synchronized(this)
		{
		if (type.equals("booking"))
		{
			for(int i=1;i<=num;i++)
			{
			ticketqty=ticketqty-1;
			System.out.println( type + " current qty is " + ticketqty);
			 try
			 {
				 Thread.sleep(5000);
			 }
			 catch(Exception e) {}
			}
		}
		else if (type.equals("cancel"))
		{
			for(int i=1;i<=num;i++)
			{
			ticketqty=ticketqty+1;
			System.out.println( type + " current qty is " + ticketqty);
			 try
			 {
				 Thread.sleep(5000);
			 }
			 catch(Exception e) {}
			}
		}
		} //sync
	}
}

class Booking extends Thread
{
	Ticket ticketobj;
	Booking(Ticket ticket)
	{
		this.ticketobj=ticket;
		
	}
	public void run()
	{
		ticketobj.displayDetail("booking", 6);
	}
}

class Cancellation extends Thread
{
	 Ticket ticketobj;
	 Cancellation(Ticket tobj)
	 {
		 this.ticketobj=tobj;
	 }
	
	 public void run()
	 {
		 ticketobj.displayDetail("cancel", 5);
	 }
	 
}
public class ThreadSyncExample {

	public static void main(String[] args) {
	Ticket ticketprocess=new Ticket();
	Booking bookobj=new Booking(ticketprocess);
	Cancellation cancel=new Cancellation(ticketprocess);
	bookobj.start();
	cancel.start();
	
	
	}

}
