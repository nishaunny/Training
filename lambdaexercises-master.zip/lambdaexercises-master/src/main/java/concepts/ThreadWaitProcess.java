package concepts;

class MyCab extends Thread
{
	
	//state : 0 -- close , 1-- wait , 2-- notify
	String name;
	int state;
	MyCab(String name)

	{
		this.name=name;
	}
	public synchronized void setState(int initial)
	{
     state=initial;
     if(state==2)
    	 notify();
     System.out.println("notify...");
       
	}
	
	public synchronized boolean checkState()
	{
		while(state==1)
		{
			try
			{
				System.out.println("waiting..");
				wait();
			}
			catch(Exception e) {}
		}
		if(state==0)
			return false;
		
		return true;
		
	}
	public void run()
	{
		while(true)
		{
			System.out.println(" Cab name is " + name);
			if(!checkState())
				break;
		}
	}
}


public class ThreadWaitProcess {

	public static void main(String[] args) throws Exception {
	
 MyCab cabtaxi=new MyCab("OLA Cab");
 
 cabtaxi.start();
 cabtaxi.setState(1);
 
 Thread.sleep(4000);
 
 cabtaxi.setState(2);//wait puts into pool, notify releases out of pool, soon after run iscalled.
 
 
 cabtaxi.setState(0);
 
 
	}

}
