package concepts;

class PlayMusic extends Thread
{
	PlayMusic(String s)
	{
	 this.setName("Playing Music");	
	}
	
	public void run()
	{
		int ans=0;
		while(ans==0)
		{
			   System.out.println("Welcome " + this.getName());//getname of thread.
			   try
			   {
				   this.sleep(2000);//putting this thread to sleep.
				   
			   }
			   catch(Exception e) {}
		}
	}
	
}
class PrintData extends Thread
{
	
	PrintData(String s)
	{
		this.setName("Printin process ");
	}
	
	public void run()
	{
		int ans=0;
		while(ans==0)
		{
			   System.out.println("Welcome " + this.getName());
			   try
			   {
				   this.sleep(2000);
				   
			   }
			   catch(Exception e) {}
		}
	}
}

class DrawPaint implements Runnable 
{
 String task;
     DrawPaint(String tsk)
     {
    	 this.task=tsk;
     }
	public void run() {
		int ans=1;
	 while(ans==1)
	 {
		System.out.println(" Current task " + task);
		  try
		   {
			   Thread.sleep(2000);
			   
		   }
		   catch(Exception e) {}
	 
	 }
	 }
}

public class SampleThread {
	public static void main(String[] args) throws Exception {
		PlayMusic album1=new PlayMusic("Western ");
		PrintData  data1=new PrintData(" Books ");
		DrawPaint draw=new DrawPaint(" drawing designs");
		Thread obj=new Thread(draw);
		obj.start();//to execute the run() method.
		
		album1.start();
	   data1.start();
		
		//Thread.sleep(10000);

	
	System.out.println("Hai Welcome");
	}

}
