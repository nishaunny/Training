package com.stackroute.basics;
/* Assignment1
 * ## Problem Statement: Develop a calculator using switch case ##

**Get two numbers of type of integer or double from the user 
*and perform the operation(Add,Multiply,Divide,Subtract)
selected by the user using switchcase, 
if-else statement,break and looping switchcase using recursion**
*/
import java.util.Scanner;


public class Calculator {
    private static Scanner scan;
    int first;
    int sec;
    int operator;

    // define,declare scanner and call getValues with scanner as parameter
    public static void main(String[] args) {
        scan = new Scanner(System.in);
        new Calculator().getValues(scan);
        char ans;
        do {
        	//System.out.println("Do you want to continue? y/n");	
        	ans = scan.next().charAt(0);
        	if(ans=='y') {
        new Calculator().getValues(scan);
        	}
        } while(ans!='n');
    }

    //Get values and which operator from the menu
    public void getValues(Scanner scan) {
    //First number, second number and operation number is received from user.
       //System.out.println("Enter the first number");
      first = scan.nextInt();
 
       //System.out.println("Enter the second number");
        sec = scan.nextInt();
       
       /*System.out.println("Enter number beside the operation to perform: "
       		+ " 1. Add\n"
       		+ " 2. Sub\n "
       		+ " 3. Multiply\n"
       		+ " 4. Divide"); */
       operator = scan.nextInt();
       //passing user's input to the calculate method.
       //calculate(first, sec, operator);
       System.out.println(calculate(first, sec, operator));
       
       
    }

    //perform operation based on the chosen switch case corresponding to the menu and return string
    public String calculate(int firstValue, int secondValue, int operator) {
    	//variables are assigned for 3 parameters.
    	//int f = firstValue;
    	//int s = secondValue;
    	//int b = operator;
    	String result;

    	//switch case for 4 operations and default is defined.
    	
    		switch(operator)
    		{	
    		case 1:
    			result = firstValue + " + " + secondValue + " = " + (firstValue + secondValue);
                break;
    		case 2:
    			result = firstValue + " - " + secondValue + " = " + (firstValue - secondValue);
                break;
    		case 3:
    			result = firstValue + " * " + secondValue + " = " + (firstValue * secondValue);
                break;
    		case 4:	
    			if(secondValue!=0) {
        			result = firstValue + " / " + secondValue + " = " + (firstValue / secondValue);
                    break;
    			}
    			else
    			{
    			result = "The divider (secondValue) cannot be zero";	
    			break;
    			}
    		default:
    	    	result = "Entered wrong option " +operator;
    			break;
    	    }
    		// Returning the result of the case operation as string.
            return result;
        }
    
}

