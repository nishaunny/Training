package com.stackroute.user.util.exception;

public class UserNullException extends Exception {


	private static final long serialVersionUID = 1L;

	public UserNullException(String message) {
        super(message);
    }
}
