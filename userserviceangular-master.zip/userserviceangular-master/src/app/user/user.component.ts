import { Component, OnInit } from '@angular/core';
import { User } from 'src/user';
import { UserprocessService } from '../userprocess.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  //creating class User object
  usernew: User;
  
  constructor(private userser: UserprocessService) {
    //instance of class user object
    this.usernew = new User();
    this.usernew.username="";
    this.usernew.password="password";
    this.usernew.mailid="";

   }

   signIn(){
     //local method calls the service method using service object.
     this.userser.validate(this.usernew);

     
   }

  ngOnInit(): void {
  }

}
