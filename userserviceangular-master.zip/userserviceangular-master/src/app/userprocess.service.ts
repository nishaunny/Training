import { Injectable } from '@angular/core';
import { User } from 'src/user';

@Injectable({
  providedIn: 'root'
})
export class UserprocessService {

  constructor() { }
// validate uses User class obj in this service method, user attribute values are checked
  validate(user: User){

    if ((user.username==="admin") && (user.password==="password"))
    alert("Valid user");
    else
    alert("Invalid user");
  
  }
}
