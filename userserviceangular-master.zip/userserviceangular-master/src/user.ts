// Create a class to implement class attributes connecting to the variables.
// 1-click on main.ts - new file - name as name.ts..in that define class
// attributes and constructor
// use keyword export to make use of this class outside ..like public

export class User{
    username: string ="";
    password: string ="";
    mailid: string ="";



    constructor(){}







}