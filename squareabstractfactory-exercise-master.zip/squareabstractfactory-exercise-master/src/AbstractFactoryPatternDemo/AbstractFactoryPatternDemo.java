package AbstractFactoryPatternDemo;
//main method to access the FactoryProducer object, this has a factory method.
public class AbstractFactoryPatternDemo {

	public static void main(String[] args) {
		
		FactoryProducer factobject = new FactoryProducer("square");
		String sampletype = factobject.getType();
		factobject.getFactory(sampletype);

	}

}
