package AbstractFactoryPatternDemo;
//Shape interface with method draw() that is overridden in the 4 classes that implement them.
public interface Shape {

		
		void draw();

}
