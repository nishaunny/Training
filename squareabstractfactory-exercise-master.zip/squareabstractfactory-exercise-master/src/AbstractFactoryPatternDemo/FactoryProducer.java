package AbstractFactoryPatternDemo;

public class FactoryProducer {

	String type;
	///factory method to create abstract class AbstractFactory object using instance of Shapefactory and Roundedshapefactory that implements it.
	public void getFactory(String type){
	       if (type == "square")
	       {
	    	   AbstractFactory factobj = new ShapeFactory();
	    	   factobj.getShape();
	       }
	       else if(type == "rectangle")
	       {
	    	   AbstractFactory factobj = new ShapeFactory();   
	    	   factobj.getShape();
	       } 
	       else if(type == "Roundedrectangle")
	       {
	    	   AbstractFactory factobj = new RoundedShapeFactory(); 
	    	   factobj.getShape();
	       }
	       else if(type == "Roundedsquare")
	       {
	    	   AbstractFactory factobj = new RoundedShapeFactory();   
	    	   factobj.getShape();
	       }
	      
	}
	
	public FactoryProducer(String stype) {
		this.type = stype;
	}
//String is set and get using getter and setter and this is passed in the getFactory();
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
