package AbstractFactoryPatternDemo;
//Contains abstractfactory class with getShape(), this is overridden in the ShapeFactory and the other class that implements
//getshape() creates shape object and uses the method draw(), overriddes it. As shape interface is implemented by the four classes.
abstract class AbstractFactory {
	
	abstract void getShape();

}

class ShapeFactory extends AbstractFactory{
	
	void getShape() {
	
		Shape shape1 = new Rectangle();
		Shape shape2 = new Square();
		shape1.draw();
		shape2.draw();
	}
	
}

class RoundedShapeFactory extends AbstractFactory{

	void getShape() {
		
		Shape shape3 = new RoundedRectangle();
		Shape shape4 = new RoundedSquare();
		shape3.draw();
		shape4.draw();
	}
	
}

class Rectangle implements Shape {

	@Override
	public void draw() {
		
		System.out.println("draw rectangle.");
		
	}
	
	
}

class Square implements Shape {
	
	@Override
	public void draw() {
		System.out.println("draw a square.");
		
	}
}

class RoundedRectangle implements Shape {
	
	@Override
	public void draw() {
		System.out.println("draw a rounded rectangle.");
		
	}
}

class RoundedSquare implements Shape {
	
	@Override
	public void draw() {
		System.out.println("draw a roundedsquare.");
		
	}
}
