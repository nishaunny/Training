
/*Create the below functional interface and implement lambda operation

1)
interface : iCalculate

method : int bonusProcess(int Salary)


Lambda implementation : return 10% of salary


2)

interface : iValidateData
method : boolean passwordMatch(String password)
	

Implementation : if password > 6 characters returns true else false

3) interface : iWelcome

method : String display()

Implementation : returns "Welcome to JDK8"*/

@FunctionalInterface
interface iCalculate{
	int bonusProcess(int Salary);
}
@FunctionalInterface
interface iValidateData{
	boolean passwordMatch(String password);
}
@FunctionalInterface
interface iWelcome{
	String display();
}

public class Interfacelambda {

	public static void main(String[] args) {
	
		iCalculate calobj = (Sal) -> {return (Sal*10/100);};
		
		System.out.println(calobj.bonusProcess(1000));
		
	    iValidateData dataobj = (password) -> password.length()>6;
	    
	    System.out.println(dataobj.passwordMatch("4567891"));
	    
	    iWelcome welobj =()-> {return "Welcome to JDK8";};
	    
	    System.out.println(welobj.display());
		

	}

}