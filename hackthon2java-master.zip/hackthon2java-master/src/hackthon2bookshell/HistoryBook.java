package hackthon2bookshell;
//#### Class HistoryBook 
//#####  This class should be	Sub class of Book class. Below are the properties
//	
//	countryName      : String
//
//* override +getBookDetails(), call the Book classes getBookDetails() method and also print Country name		

public class HistoryBook extends Book{
	
	

	private String countryName;
	
	
    //calling the super constructor and setting the countryname in this constructor
	public HistoryBook(String countryname)
	{	//super(isbn, title, edition, author);//call the book constructor.
		this.countryName=countryname;}

	
//	public HistoryBook(long isbn, String title, String edition, Author author) {
//		super(isbn, title, edition, author);
//		// TODO Auto-generated constructor stub
//	}



	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	
	//calling the parent class getBookdetails and also printing the countryName.
	public String getBookDetails() {
		 System.out.println(super.getBookDetails());//call the book's getBookdetails.
		 return " {Country name: " +countryName+"}";
		
	}

}
