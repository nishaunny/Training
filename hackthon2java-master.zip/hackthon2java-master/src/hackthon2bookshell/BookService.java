package hackthon2bookshell;
//class BookService
//Define the below methods:
//•	
// static +createAuthor(String, String) : Author       
//
//•	      - Should create an Author object using the input name and addr and return the author object 
//•	
//
//static +createBook(long, String, String, author) : Book
//
//•	      - Should create a Book object with the below input to the method
//
//•	         book details     :  isbn, title and edition 
//
//•	         author details   :  using author class object  
//
//      - parameter order of inputs to the method should be as given above
//
//##### Main Method
//
//* Get the Instance of Author using createAuthor method
//
//* Get the instance of Book using createBook method
//
//* Get the instance of HistoryBook.
//
//* Call the getBookDetails() method , using object of HistoryBook


public class BookService {

	public static void main(String[] args) {
	    
		//instance of author
		Author authorexamine = createAuthor("Philip Kotler", "Wallstreet");
		System.out.println("Author details....>");
		//System.out.println(authorexamine.getName());
		
		System.out.println(authorexamine.toString());
		
		//instanse of book
		Book bookanalyze = createBook(2345, "Marketing management", "3rd edition", authorexamine);
		System.out.println("Book details with author printed....>"+bookanalyze.getBookDetails());
	
		//instance of Historybook
		//HistoryBook historyinherit1 = new HistoryBook("USA",2345, "Marketing management", "3rd edition", authorexamine);
		HistoryBook historyinherit = new HistoryBook("USA");
		//calling the book parent's bookdetails to be displayed here.
		System.out.println("History book child class details with book's method.......>");
		System.out.println(historyinherit.getBookDetails());
		
	}
	//returns Author class object
	static Author createAuthor(String authname, String authaddr) {
		
		Author authorobj = new Author(authname, authaddr);
		return authorobj;
		
	}
	//returns Book class object
	static Book createBook(long isbn, String title, String edition, Author author) {
		Book bookobj = new Book(isbn, title, edition, author);
		return bookobj;
	}
}
