package hackthon2bookshell;
//#### Class Book
//##### Define the following properties. properties should be private:
//
//    -isbn      : long         
//    -title     : String
//    -edition   : String
//    -author    : Author 
//    
//*	Define parameterized constructor to initialize all the properties
//*	
//•	Define Getters and Setters for all properties
//
//•	Define the below methods:
//
//•	  +getBookDetails() : String       
//    - Should print all the attribute details
    
public class Book {
    //private variables
	private long isbn;
	private String title, edition;
	private Author author;
	
	public Book() {};
	//getters and setters
	public Author getAuthor() {
		return author;
	}

	public void setAuthor(Author author) {
		this.author = author;
	}
    //parametrized constructor
	public Book(long isbn, String title, String edition, Author author) {
		
		this.isbn=isbn;
		this.title=title;
		this.edition=edition;
		this.author=author;
	}
	
	

	public long getIsbn() {
		return isbn;
	}


	public void setIsbn(long isbn) {
		this.isbn = isbn;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getEdition() {
		return edition;
	}


	public void setEdition(String edition) {
		this.edition = edition;
	}
//method to print the details.	
public String getBookDetails() {
		
		return "Isbn :" +isbn+ " Book Title : "+title+ " Edition : "+edition+" Author name :" +author;
	}

}
