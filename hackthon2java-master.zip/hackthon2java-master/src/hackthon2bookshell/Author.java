package hackthon2bookshell;
//#### class Author
//##### Define the following properties. properties should be private:
//
//    -name    : String 
//    -addr : String
//    
//*	Define parameterized constructor to initialize all the properties.
//	
//*   Define Getters and Setters for all properties
//
//*	Define the below methods:
//	  +toString : String       
//    - Should return the author details as per the below format
public class Author {
	//private variables
	private String name, addr;
	
	public Author() {};
	//parameterized constructor
	public Author(String name, String Add) {
		
		this.name=name;
		this.addr=Add;
	}
	
    //getters and setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}
	//toString method
	public String toString() {
		
		return "Author name: " +name+ "Address : " +addr;
	}


}
