package com.ustg.ustactivitycore;

public class Order {

	private String Orderid;
	private String customername;
	Item itemobj;
	public String getOrderid() {
		return Orderid;
	}
	public void setOrderid(String orderid) {
		Orderid = orderid;
	}
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public Item getItemobj() {
		return itemobj;
	}
	public void setItemobj(Item itemobj) {
		this.itemobj = itemobj;
	}
}
