package com.ustg.ustactivitycore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World to Springactivity 1!" );
        
        ApplicationContext appcontext=new ClassPathXmlApplicationContext("mybean.xml");
        
        Order orderobj = appcontext.getBean("orderbean", Order.class);
        
        System.out.println("CustomerName....>"+orderobj.getCustomername());
        
        System.out.println("Order id....>"+orderobj.getOrderid());
        
        System.out.println("Itemname....>"+orderobj.getItemobj().getItemname());
    }
}
