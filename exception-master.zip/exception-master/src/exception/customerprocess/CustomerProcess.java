package exception.customerprocess;
import java.util.Scanner;

/*
 * Excercise based on Exceptions:
 * Attributes of Customer class
 customerName : String
 depositType : String
 baseAmount : int
*
*use the below method to set the values
  setCustomerData(String cname,String deposit,int amount)
  -- set all values

 displayData()
  --> Print all the values 
  CustomerProcess - Main method

 access setCustomerData method by passing value thro scanner, if amount is <1000, then throw the exception 
 call displayData method

	 		
  *
  *
  *
  */

class Customer {
	String customerName;
	String depositType;
	int baseAmount;
	
	public String getCustomerName() {
		return customerName;
	}



	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}



	public String getDepositType() {
		return depositType;
	}



	public void setDepositType(String depositType) {
		this.depositType = depositType;
	}



	public int getBaseAmount() {
		return baseAmount;
	}



	public void setBaseAmount(int baseAmount) {
		this.baseAmount = baseAmount;
	}
	
	

void setCustomerData(String cname,String deposit,int amount) {
	this.customerName = cname;
	this.depositType = deposit;
	this.baseAmount = amount;
}

void displayData() {
	System.out.println("Customer:\n"  + getCustomerName()+"\n"+  "Deposit:\n"  + getDepositType()+"\n"+  "Amount:\n"  + getBaseAmount());
}

}

public class CustomerProcess {

	public static void main(String[] args) throws InvalidBaseAmountException{
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter customername, deposit and amount");
		String cust = scan.next();
		String depo = scan.next();
		int amount = scan.nextInt();
		scan.close();
		if(amount<1000) 
			throw new InvalidBaseAmountException("Amount has to be more than 1000");
		
		Customer obj = new Customer();
		obj.setCustomerData(cust,depo, amount);
		obj.displayData();
	}

}
