package exception.customerprocess;

import java.lang.Exception;


public class InvalidBaseAmountException extends Exception {
	
	InvalidBaseAmountException(String msg){
		super(msg.toString());
	}

}
