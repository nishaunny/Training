package com.stackroute.banking.main;


import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import com.stackroute.banking.exception.CustomerAlreadyExistsException;
import com.stackroute.banking.model.Customer;
import com.stackroute.banking.service.CustomerService;
import com.stackroute.banking.service.iCustomerService;

public class BankProcess {

	
	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub	
		iCustomerService serviceobject = new CustomerService();
        char ch='y';
		
		while(ch=='y')
		{
		
		System.out.println("Enter the choice - 1:Add new customer 2:view the list 3:withdraw. 4.exit");
		
	
		Scanner scan = new Scanner(System.in);	
		
		int choice=scan.nextInt();
		
		switch(choice)
		{
		
		case 1:
			System.out.println("Enter the values for Name, type and baseamount");
			try
			{
			Customer custdata = serviceobject.createCustomer(scan.next(), scan.next(),scan.nextInt());
			serviceobject.addCustomerService(custdata);
			System.out.println("Added");
			}
			catch(CustomerAlreadyExistsException e)
			{
				System.out.println(e.getMessage());
			}
			break;
			
		case 2:
		List<Customer> newlist = serviceobject.getAllCustomerdata();
		for(Customer custobj: newlist) {
			System.out.println("Name"+custobj.getCustomerName());
		    System.out.println("Baseamount"+custobj.getBaseAmount());
		    System.out.println("Depositype"+custobj.getDepositType());
		}
			break;
		
		case 3:
			System.out.println("Enter the values for Name,type and amount");
			String name = scan.next();
			String type = scan.next();
			int amount= scan.nextInt();
			Customer withobj = serviceobject.createCustomer(name, type, 10);
			serviceobject.withdrawAmount(withobj,amount);
			break;
		case 4:
			break;		
	    }
		System.out.println("Do you want to continue y/n");
		ch=(char) System.in.read();
		}
}
}