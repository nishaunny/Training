package com.stackroute.banking.service;

import java.util.List;

import com.stackroute.banking.exception.CustomerAlreadyExistsException;
import com.stackroute.banking.model.Customer;

public interface iCustomerService {

	
	void addCustomerService(Customer customer) throws CustomerAlreadyExistsException;
	List<Customer> getAllCustomerdata();
	void withdrawAmount(Customer customer , int amt);
	public Customer createCustomer(String name, String type, int amt);
}
