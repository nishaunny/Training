package com.stackroute.banking.service;

import java.util.ArrayList;
import java.util.List;

import com.stackroute.banking.exception.CustomerAlreadyExistsException;
import com.stackroute.banking.model.Customer;
import com.stackroute.banking.model.repository.CustomerRepo;
import com.stackroute.banking.model.repository.iCustomer;


//Service class implements the service interface and has methods to add, viewlist, withdramount and create customer.
public class CustomerService implements iCustomerService{   
	
	List<Customer> customerinfo = new ArrayList<Customer>();
	iCustomer customerrepobj;
	
    public CustomerService() {
    	customerrepobj = new CustomerRepo();
    }
	@Override
	public void addCustomerService(Customer customer) throws CustomerAlreadyExistsException {
		
		if (customer.hashCode()==customerrepobj.hashCode()) {
			
			throw new CustomerAlreadyExistsException("This customer is already in the list.");
		}
		else
			
		{
			 customerrepobj.addCustomer(customer);
			 System.out.println("Customer has been added.");
			}
		
		
		
	}

	@Override
	public List<Customer> getAllCustomerdata() {
		customerinfo = customerrepobj.getCustomerData();
		return customerinfo;
	}

	@Override
	public void withdrawAmount(Customer customer, int amt) {
		// TODO Auto-generated method stub
		if(customer!=null)
		{
			int balance = amt - customer.getBaseAmount();
		  System.out.println("Amount balance"+balance);
		}
		
	}
	@Override
	public Customer createCustomer(String name, String type, int amt) {
	
		Customer customer = customerrepobj.createCustomer(name, type, amt);
		return customer;
	}

}
