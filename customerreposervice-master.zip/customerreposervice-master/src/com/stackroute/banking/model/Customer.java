package com.stackroute.banking.model;

public class Customer {

	private String customerName;
	private String depositType;
	private int baseAmount;
	
	public Customer(String name, String depoType, int amount){
		this.customerName = name;
		this.depositType = depoType;
		this.baseAmount = amount;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getDepositType() {
		return depositType;
	}
	public void setDepositType(String depositType) {
		this.depositType = depositType;
	}
	public int getBaseAmount() {
		return baseAmount;
	}
	public void setBaseAmount(int baseAmount) {
		this.baseAmount = baseAmount;
	}
	
}
