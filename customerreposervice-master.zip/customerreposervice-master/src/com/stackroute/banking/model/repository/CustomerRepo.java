package com.stackroute.banking.model.repository;

import java.util.ArrayList;
import java.util.List;

import com.stackroute.banking.model.Customer;

public class CustomerRepo implements iCustomer{
	
	List<Customer> customers= new ArrayList<Customer>();
	public CustomerRepo(){
		Customer customer1 = new Customer("Mani","Annual",1000);
		Customer customer2 = new Customer("Nani","Annual",1000);
		Customer customer3= new Customer("Sina","Annual",1000);
        customers.add(customer1);
        customers.add(customer2);
        customers.add(customer3);
      
	}

	@Override
	public void addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		customers.add(customer);
		
	}

	@Override
	public List<Customer> getCustomerData() {
		// TODO Auto-generated method stub
		return customers;
	}

	@Override
	public Customer createCustomer(String name, String type, int amt) {
		Customer customerobj = new Customer(name,type,amt);
		return customerobj;
	}

}
