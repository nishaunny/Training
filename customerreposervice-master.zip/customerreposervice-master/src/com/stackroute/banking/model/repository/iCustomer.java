package com.stackroute.banking.model.repository;

import java.util.List;

import com.stackroute.banking.model.Customer;

public interface iCustomer {

	void addCustomer(Customer customer);
	List<Customer> getCustomerData();
	Customer createCustomer(String name, String type, int amt);
}
