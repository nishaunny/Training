package com.stackroute.banking.exception;



public class CustomerAlreadyExistsException extends Exception {
	public CustomerAlreadyExistsException(String msg)
	{
		super(msg);
	}

}
