package com.stackroute.exercises;


import java.io.*;

public class FileMigration {
	byte[] array1;

    //Write here logic to read content of first file and write it in second file
    public String fileContentDuplicator(String firstFile, String secondFile) throws IOException {
	////    //Write here logic to read content of first file and write it in second file

		String result;
		
		if (firstFile == null || secondFile == null || firstFile.isBlank() || secondFile.isBlank())
			return "Given fileName to read or write is empty, null or blank space";
//		File file = new File(firstFile);
//		File filetwo = new File(secondFile);
//		if(file.getPath()==null||filetwo.getPath()==null)
//			return result ="Given fileName does not exist.";
		if (firstFile.isEmpty() || secondFile.isEmpty()) {
			throw new IOException("Invalid file.");
		}
		if (firstFile != null && secondFile != null) {
			String first = firstFile.replaceAll("\\s+", "");
			String second = secondFile.replaceAll("\\s+", "");
			FileInputStream filein = new FileInputStream(first);
			BufferedInputStream bufferinp = new BufferedInputStream(filein);
			array1 = bufferinp.readAllBytes();
			FileOutputStream file2 = new FileOutputStream(second);
			BufferedOutputStream bufferoutp = new BufferedOutputStream(file2);
			bufferinp.transferTo(bufferoutp);
			/*
			 * bufferoutp.write("Hi, my name is..".getBytes());
			 * bufferoutp.write(System.lineSeparator().getBytes()); //// *
			 * bufferoutp.write("This is an example of writing data to a file".getBytes());
			 * ////
			 */
			bufferoutp.write(array1);
			bufferoutp.flush();
			filein.close();
			file2.close();
			bufferinp.close();
			bufferoutp.close();
		}
		
		result = new String(array1);
		return result;

	}
}
