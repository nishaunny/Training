package com.stackroute.oops;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.stackroute.oops.Employee.EmployeeBuilder;

public class EmployeeServiceTests {
	
	EmployeeBuilder builderobj = new EmployeeBuilder(10,"Princy", "Harriet");
	
	//Employee empbobj = new Employee(builderobj);
	
	EmployeeService serviceobj = new EmployeeService();
	
	//createBasicemployee` should create employee object with desired properties
	@Test
	public void createBasicEmployeeDoesNotReturnNull() {
		Assertions.assertNotNull(serviceobj.createBasicEmployee(10, "Princy", "Harriet"));
		Assertions.assertNotNull(builderobj.buildEmployee());
	}
	
	//createEmployeeWithAge` should create employee object with desired properties and optional age property
	@Test
	public void createEmployeewithAgeDoesNotReturnNull() {
		Assertions.assertNotNull(serviceobj.createEmployeeWithAge(10, "Princy", "Harriet",(short) 20));
		Assertions.assertNotNull(builderobj.withOptionalAge((short)20));
		Assertions.assertNotNull(builderobj.buildEmployee());
	}
    //createEmployeeWithPhone` should create employee object with desired properties and optional Phone property
	@Test
	public void createEmployeeWithPhoneDoesNotReturnNull() {
		Assertions.assertNotNull(serviceobj.createEmployeeWithPhone(10, "Princy", "Harriet","9987654321"));
		Assertions.assertNotNull(builderobj.withOptionalPhone("9987654321"));
		Assertions.assertNotNull(builderobj.buildEmployee());
	}
    //createEmployeeWithAddress` should create employee object with desired properties and optional address property
	@Test
	public void createEmployeewithAddressDoesNotReturnNull() {
		Assertions.assertNotNull(serviceobj.createEmployeeWithAddress(10, "Princy", "Harriet","XYZ streetname"));
		Assertions.assertNotNull(builderobj.withOptionalAddress("XYZ streetname"));
		Assertions.assertNotNull(builderobj.buildEmployee());
	}
    //createEmployeeWithAgePhoneAndAddress` should create employee object with all desired and optional properties 
	@Test
	public void createEmployeewithAgePhoneAndAddressDoesNotReturnNullandIsRight() {
		Assertions.assertNotNull(serviceobj.createEmployeeWithAgePhoneAndAddress(20, "Emmanual", "Sam", (short)25, "9987654321", "Seahstreet"));
	
		Assertions.assertNotNull(builderobj.buildEmployee());
	}

}
