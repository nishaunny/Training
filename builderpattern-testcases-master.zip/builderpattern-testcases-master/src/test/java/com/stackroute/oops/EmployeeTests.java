package com.stackroute.oops;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.stackroute.oops.Employee.EmployeeBuilder;

public class EmployeeTests {
	
	public EmployeeTests(){};
	
	EmployeeBuilder builderobj = new EmployeeBuilder(3, "Sam", "Thomas");
	
	Employee employeeobj = new Employee(builderobj);
	
	
	public static final String Message01 = "Employee details are not returned in toString in expected format.";
	
	
	
	@Test//Getpropertiesof employee return as expected and not null.
	public void getPropertiesFromEmployeeShouldNotReturnNull() {
		
		
		Assertions.assertNotNull(employeeobj);
		Assertions.assertEquals(3, employeeobj.getId());
		Assertions.assertEquals("Sam", employeeobj.getFirstName());
		Assertions.assertEquals("Thomas", employeeobj.getLastName());
		
	}
	
	@Test//To string prints employee details in expected format.
	public void toStringshouldReturnEmployeeDetailsinRequiredFormat() {
		
		String expectstr="Employee{" +
                "id=" + employeeobj.getId() +
                ", firstName=" + employeeobj.getFirstName() +
                ", lastName=" + employeeobj.getLastName() +
                ", age=" + employeeobj.getAge() +
                ", phone=" + employeeobj.getPhone() +
                ", address=" + employeeobj.getAddress() +
                "}";
		Assertions.assertNotNull(employeeobj);
		Assertions.assertEquals(employeeobj.toString(),expectstr,Message01);
		
	}

	@Test//This function identifies invalid phone number when not equal to 10 digits.
	public void withOptionalPhoneOfEmployeeBuilderShouldNotReturnNull() {
		
		
		Assertions.assertNotNull(builderobj.withOptionalPhone("98765431290"));
		Assertions.assertNotNull(builderobj.buildEmployee());
		Assertions.assertEquals(builderobj.buildEmployee().getPhone(),"Invalid");
	
		
	}
	
	@Test//This validates as expected for the phone number.
	public void withOptionalPhoneOfEmployeeBuilderShouldReturnValid() {
		
		
		Assertions.assertNotNull(builderobj.withOptionalPhone("9876543129"));
		Assertions.assertNotNull(builderobj.buildEmployee());
		Assertions.assertEquals(builderobj.buildEmployee().getPhone(),"9876543129");
	
		
	}
	@Test//Provides the address as expected.
	public void withOptionalAddressOfEmployeeBuilderShouldNotReturnNull() {
		
		
		Assertions.assertNotNull(builderobj.withOptionalAddress("Street XYZ"));
		Assertions.assertNotNull(builderobj.buildEmployee());
		Assertions.assertEquals(builderobj.buildEmployee().getAddress(),"Street XYZ");
	
		
	}
	@Test//Provides the age as expected.
	public void withOptionalAgeOfEmployeeBuilderShouldNotReturnNull() {
		
		
		Assertions.assertNotNull(builderobj.withOptionalAge((short) 20));
		Assertions.assertNotNull(builderobj.buildEmployee());
		Assertions.assertEquals(builderobj.buildEmployee().getAge(),(short) 20);
	
		
	}
	

}
