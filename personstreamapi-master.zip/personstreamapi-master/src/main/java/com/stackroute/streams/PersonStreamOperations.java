package com.stackroute.streams;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * This class has various methods to do stream operations on person collection
 */
public class PersonStreamOperations {

    /**
     * sorts the person list alphabetically in uppercase
     * Returns Empty Optional if the given list is null or empty
     *
     * @param personList
     * @return
     */
	
    public Optional<List<String>> getPersonListSortedByNameInUpperCase(List<String> personList) {
    	
    	List<String> aslist = new ArrayList();
    	List<String> returnlist = new ArrayList();
    	//return optionalempty if the list is null or contains no elements
    	if(personList==null||personList.size()==0)
    		return Optional.empty();
    	else {
    		//filterto check if there's empty values, cut blank spaces and there's a string, map to convert the string to uppercase, sorted to sort default way, convert to list.
    			aslist = personList.stream().filter((person)->person.trim().length()>0).map((person)->person.toUpperCase()).sorted().collect(Collectors.toList());
    		    returnlist.addAll(aslist);
    		   
    		 
    	}
    	Optional<List<String>> opt = Optional.of(returnlist);
    	if(opt.isPresent())
    		return opt;
    	else
    		//if optional string is not present
    		return Optional.empty();
    			
        
    }
    	
    /**
     * Sorts the distinct person names in descending order
     * Returns empty set if the given list is empty or null
     *
     * @param personList
     * @return
     */

    public Set<String> getDistinctPersonNamesSortedInDescendingOrder(List<String> personList) {
    	Set<String> setlist = new HashSet();
    	List<String> list = new ArrayList<>();
    	//if the list has no elements, listsize is zero or null, returns empty set.
    	if(personList==null||personList.size()==0)
        return setlist;
    	else {
    		//filter to check if there's a string without blank spaces, sorted.reverseorder to change in descending order, distinct to avoid duplicate strings added, then convert to list.
    	list = personList.stream().filter((person)->person.trim().length()>0).sorted(Comparator.reverseOrder()).distinct().collect(Collectors.toList());
    	setlist = new LinkedHashSet<String>(list);
    	
    	return setlist;
    	}
    
    	
    }

    /**
     * Returns "Person found" if the person searched is available in the list or else returns "Person not found"
     * Returns "Give proper input not null" if the given list or name to search is null
     *
     * @param personList
     * @return
     */
    //changed the return type to String to match the test case.
    public String searchPerson(List<String> personList, String nameToSearch) {
    	
    	//Predicate<List> listobj = (list) -> list.contains(nameToSearch);
    	//if search string or list is null, return the string as mentioned.
    	if(personList==null||nameToSearch==null)
         return "Give proper input not null";
    	else	{
    	List<String> search = personList.stream().filter((list)->list.equalsIgnoreCase(nameToSearch)).collect(Collectors.toList());
    	//search - list, first checks if list has the string given, convert to list.
    	if(search.size()> 0)//if the searchlist size is greater than zero, means string is found.
    		return "Person found";
    	else
    		return "Person not found";
    	
         }
    }

    /**
     * Filters the list whose name length is greater than five and sorts by name length
     * Returns empty list if the given list is empty or null
     *
     * @param personList
     * @return
     */

    public List<String> getPersonListSortedByLengthWithNameLengthGreaterThanFive(List<String> personList) {
    	List<String> getlist = new ArrayList();
    	
    	//if no elements or list is null, empty list returned.
    	if(personList==null||personList.size()==0)
    		return getlist;
    	else {
    		//using filter to check if the string length is greater than 5, remove blank spaces, sort using the string length to make in order of the length, then convert to list.
    	getlist = personList.stream().filter((person)->person.strip().length()>5).sorted(Comparator.comparing((person)->person.length())).collect(Collectors.toList());
        return getlist;
    	}
    }

    /**
     * Returns the person name having maximum age from the given Map<String,Integer> having name as key and age as value
     * Returns "Give proper input not null" if the given map is empty or null
     *
     * @param personMap
     * @return
     */

    public String getPersonByMaxAge(Map<String, Integer> personMap) {
    	//if Map given is null or no elements found.
    	if(personMap==null||personMap.size()==0)
    		return "Give proper input not null";
    	else {
    		//returns a string using a set view of map with entrySet, then max(Map's first k,v comparing by value) - to get maximum age as age is value.
    		String maxname =personMap.entrySet().stream().max(Map.Entry.comparingByValue()).get().getKey();
    		return maxname;
    	}
        
    }

}
